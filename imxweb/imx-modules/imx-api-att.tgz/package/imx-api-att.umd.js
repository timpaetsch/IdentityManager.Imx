(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    (function (AuthPropType) {
        AuthPropType[AuthPropType["Info"] = 0] = "Info";
        AuthPropType[AuthPropType["Edit"] = 1] = "Edit";
        AuthPropType[AuthPropType["Password"] = 2] = "Password";
        AuthPropType[AuthPropType["Hidden"] = 3] = "Hidden";
        AuthPropType[AuthPropType["Checkbox"] = 4] = "Checkbox";
        AuthPropType[AuthPropType["OAuth2Code"] = 5] = "OAuth2Code";
        AuthPropType[AuthPropType["NewPassword"] = 6] = "NewPassword";
    })(exports.AuthPropType || (exports.AuthPropType = {}));
    (function (AuthType) {
        AuthType[AuthType["Default"] = 0] = "Default";
        AuthType[AuthType["AllManualModules"] = 1] = "AllManualModules";
        AuthType[AuthType["FixedCredentials"] = 2] = "FixedCredentials";
    })(exports.AuthType || (exports.AuthType = {}));
    (function (RecommendationEnum) {
        RecommendationEnum[RecommendationEnum["None"] = 0] = "None";
        RecommendationEnum[RecommendationEnum["Deny"] = 1] = "Deny";
        RecommendationEnum[RecommendationEnum["Approve"] = 2] = "Approve";
    })(exports.RecommendationEnum || (exports.RecommendationEnum = {}));
    (function (ViolationState) {
        ViolationState[ViolationState["Pending"] = 0] = "Pending";
        ViolationState[ViolationState["ExceptionApproved"] = 1] = "ExceptionApproved";
        ViolationState[ViolationState["ExceptionDenied"] = 2] = "ExceptionDenied";
    })(exports.ViolationState || (exports.ViolationState = {}));
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.OpsupportCandidatesDialogtimezone = new OpsupportCandidatesDialogtimezoneWrapper(client, translationProvider);
            this.PasswordresetCandidatesDialogtimezone = new PasswordresetCandidatesDialogtimezoneWrapper(client, translationProvider);
            this.PortalAttestationApprove = new PortalAttestationApproveWrapper(client, translationProvider);
            this.PortalAttestationApproveParameterCandidates = new PortalAttestationApproveParameterCandidatesWrapper(client, translationProvider);
            this.PortalAttestationCase = new PortalAttestationCaseWrapper(client, translationProvider);
            this.PortalAttestationCaseHistory = new PortalAttestationCaseHistoryWrapper(client, translationProvider);
            this.PortalAttestationCaseParameterCandidates = new PortalAttestationCaseParameterCandidatesWrapper(client, translationProvider);
            this.PortalAttestationFilterCandidates = new PortalAttestationFilterCandidatesWrapper(client, translationProvider);
            this.PortalAttestationFilterMatchingobjects = new PortalAttestationFilterMatchingobjectsWrapper(client, translationProvider);
            this.PortalAttestationObject = new PortalAttestationObjectWrapper(client, translationProvider);
            this.PortalAttestationPersondecision = new PortalAttestationPersondecisionWrapper(client, translationProvider);
            this.PortalAttestationPolicy = new PortalAttestationPolicyWrapper(client, translationProvider);
            this.PortalAttestationPolicyEdit = new PortalAttestationPolicyEditWrapper(client, translationProvider);
            this.PortalAttestationPolicyEditInteractive = new PortalAttestationPolicyEditInteractiveWrapper(client, translationProvider);
            this.PortalAttestationPolicygroups = new PortalAttestationPolicygroupsWrapper(client, translationProvider);
            this.PortalAttestationPolicygroupsInteractive = new PortalAttestationPolicygroupsInteractiveWrapper(client, translationProvider);
            this.PortalAttestationRun = new PortalAttestationRunWrapper(client, translationProvider);
            this.PortalAttestationRunApprovers = new PortalAttestationRunApproversWrapper(client, translationProvider);
            this.PortalAttestationSchedules = new PortalAttestationSchedulesWrapper(client, translationProvider);
            this.PortalAttestationWorkflow = new PortalAttestationWorkflowWrapper(client, translationProvider);
            this.PortalCandidatesAerole = new PortalCandidatesAeroleWrapper(client, translationProvider);
            this.PortalCandidatesAttestationpolicygroup = new PortalCandidatesAttestationpolicygroupWrapper(client, translationProvider);
            this.PortalCandidatesCompliancearea = new PortalCandidatesComplianceareaWrapper(client, translationProvider);
            this.PortalCandidatesDialogtimezone = new PortalCandidatesDialogtimezoneWrapper(client, translationProvider);
            this.PortalCandidatesMitigatingcontrol = new PortalCandidatesMitigatingcontrolWrapper(client, translationProvider);
            this.PortalCandidatesPerson = new PortalCandidatesPersonWrapper(client, translationProvider);
            this.PortalCandidatesQbmculture = new PortalCandidatesQbmcultureWrapper(client, translationProvider);
            this.PortalCandidatesQertermsofuse = new PortalCandidatesQertermsofuseWrapper(client, translationProvider);
            this.PortalClaimdeviceDevices = new PortalClaimdeviceDevicesWrapper(client, translationProvider);
            this.RegisterPerson = new RegisterPersonWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var OpsupportCandidatesDialogtimezone = /** @class */ (function (_super) {
        __extends(OpsupportCandidatesDialogtimezone, _super);
        function OpsupportCandidatesDialogtimezone() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_DialogTimeZone = _this.GetEntityValue('UID_DialogTimeZone');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportCandidatesDialogtimezone.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DialogTimeZone': {
                    ColumnName: 'UID_DialogTimeZone',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DialogTimeZone', Columns: columns };
        };
        return OpsupportCandidatesDialogtimezone;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportCandidatesDialogtimezone type. */
    var OpsupportCandidatesDialogtimezoneInteractive = /** @class */ (function (_super) {
        __extends(OpsupportCandidatesDialogtimezoneInteractive, _super);
        function OpsupportCandidatesDialogtimezoneInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportCandidatesDialogtimezoneInteractive;
    }(OpsupportCandidatesDialogtimezone));
    var PasswordresetCandidatesDialogtimezone = /** @class */ (function (_super) {
        __extends(PasswordresetCandidatesDialogtimezone, _super);
        function PasswordresetCandidatesDialogtimezone() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_DialogTimeZone = _this.GetEntityValue('UID_DialogTimeZone');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PasswordresetCandidatesDialogtimezone.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DialogTimeZone': {
                    ColumnName: 'UID_DialogTimeZone',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DialogTimeZone', Columns: columns };
        };
        return PasswordresetCandidatesDialogtimezone;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PasswordresetCandidatesDialogtimezone type. */
    var PasswordresetCandidatesDialogtimezoneInteractive = /** @class */ (function (_super) {
        __extends(PasswordresetCandidatesDialogtimezoneInteractive, _super);
        function PasswordresetCandidatesDialogtimezoneInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PasswordresetCandidatesDialogtimezoneInteractive;
    }(PasswordresetCandidatesDialogtimezone));
    var PortalAttestationApprove = /** @class */ (function (_super) {
        __extends(PortalAttestationApprove, _super);
        function PortalAttestationApprove() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.IsReserved = _this.GetEntityValue('IsReserved');
            _this.PeerGroupFactor = _this.GetEntityValue('PeerGroupFactor');
            _this.IsCrossFunctional = _this.GetEntityValue('IsCrossFunctional');
            _this.DecisionLevel = _this.GetEntityValue('DecisionLevel');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.PropertyInfo1 = _this.GetEntityValue('PropertyInfo1');
            _this.PropertyInfo2 = _this.GetEntityValue('PropertyInfo2');
            _this.PropertyInfo3 = _this.GetEntityValue('PropertyInfo3');
            _this.PropertyInfo4 = _this.GetEntityValue('PropertyInfo4');
            _this.ReportType = _this.GetEntityValue('ReportType');
            _this.RiskIndex = _this.GetEntityValue('RiskIndex');
            _this.StructureDisplay1 = _this.GetEntityValue('StructureDisplay1');
            _this.StructureDisplay2 = _this.GetEntityValue('StructureDisplay2');
            _this.StructureDisplay3 = _this.GetEntityValue('StructureDisplay3');
            _this.ToSolveTill = _this.GetEntityValue('ToSolveTill');
            _this.UID_AttestationPolicy = _this.GetEntityValue('UID_AttestationPolicy');
            _this.IsNotApprovedBefore = _this.GetEntityValue('IsNotApprovedBefore');
            _this.UID_QERWorkingMethod = _this.GetEntityValue('UID_QERWorkingMethod');
            _this.UID_AttestationRun = _this.GetEntityValue('UID_AttestationRun');
            _this.UID_PersonHead = _this.GetEntityValue('UID_PersonHead');
            _this.ObjectKeyBase = _this.GetEntityValue('ObjectKeyBase');
            _this.IsApproveRequiresMfa = _this.GetEntityValue('IsApproveRequiresMfa');
            _this.SupportsAssignmentAnalysis = _this.GetEntityValue('SupportsAssignmentAnalysis');
            _this.UID_QERTermsOfUse = _this.GetEntityValue('UID_QERTermsOfUse');
            _this.DisplayType = _this.GetEntityValue('DisplayType');
            _this.AttestationState = _this.GetEntityValue('AttestationState');
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ApproveReasonType = _this.GetEntityValue('ApproveReasonType');
            _this.DenyReasonType = _this.GetEntityValue('DenyReasonType');
            _this.MControls = _this.GetEntityValue('MControls');
            _this.UiText = _this.GetEntityValue('UiText');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationApprove.GetEntitySchema = function () {
            var columns = {
                'IsReserved': {
                    ColumnName: 'IsReserved',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'PeerGroupFactor': {
                    ColumnName: 'PeerGroupFactor',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'IsCrossFunctional': {
                    ColumnName: 'IsCrossFunctional',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'DecisionLevel': {
                    ColumnName: 'DecisionLevel',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'PropertyInfo1': {
                    ColumnName: 'PropertyInfo1',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PropertyInfo2': {
                    ColumnName: 'PropertyInfo2',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PropertyInfo3': {
                    ColumnName: 'PropertyInfo3',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PropertyInfo4': {
                    ColumnName: 'PropertyInfo4',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ReportType': {
                    ColumnName: 'ReportType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'RiskIndex': {
                    ColumnName: 'RiskIndex',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'StructureDisplay1': {
                    ColumnName: 'StructureDisplay1',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'StructureDisplay2': {
                    ColumnName: 'StructureDisplay2',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'StructureDisplay3': {
                    ColumnName: 'StructureDisplay3',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ToSolveTill': {
                    ColumnName: 'ToSolveTill',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_AttestationPolicy': {
                    ColumnName: 'UID_AttestationPolicy',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsNotApprovedBefore': {
                    ColumnName: 'IsNotApprovedBefore',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'UID_QERWorkingMethod': {
                    ColumnName: 'UID_QERWorkingMethod',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AttestationRun': {
                    ColumnName: 'UID_AttestationRun',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_PersonHead': {
                    ColumnName: 'UID_PersonHead',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyBase': {
                    ColumnName: 'ObjectKeyBase',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsApproveRequiresMfa': {
                    ColumnName: 'IsApproveRequiresMfa',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'SupportsAssignmentAnalysis': {
                    ColumnName: 'SupportsAssignmentAnalysis',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'UID_QERTermsOfUse': {
                    ColumnName: 'UID_QERTermsOfUse',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DisplayType': {
                    ColumnName: 'DisplayType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'AttestationState': {
                    ColumnName: 'AttestationState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ApproveReasonType': {
                    ColumnName: 'ApproveReasonType',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'DenyReasonType': {
                    ColumnName: 'DenyReasonType',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'MControls': {
                    ColumnName: 'MControls',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UiText': {
                    ColumnName: 'UiText',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AttestationCase', Columns: columns };
        };
        return PortalAttestationApprove;
    }(imxQbmDbts.ReadWriteExtTypedEntity));
    /** @deprecated Use the PortalAttestationApprove type. */
    var PortalAttestationApproveInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationApproveInteractive, _super);
        function PortalAttestationApproveInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationApproveInteractive;
    }(PortalAttestationApprove));
    var PortalAttestationApproveParameterCandidates = /** @class */ (function (_super) {
        __extends(PortalAttestationApproveParameterCandidates, _super);
        function PortalAttestationApproveParameterCandidates() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationApproveParameterCandidates.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'non_static_table', Columns: columns };
        };
        return PortalAttestationApproveParameterCandidates;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationApproveParameterCandidates type. */
    var PortalAttestationApproveParameterCandidatesInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationApproveParameterCandidatesInteractive, _super);
        function PortalAttestationApproveParameterCandidatesInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationApproveParameterCandidatesInteractive;
    }(PortalAttestationApproveParameterCandidates));
    var PortalAttestationCase = /** @class */ (function (_super) {
        __extends(PortalAttestationCase, _super);
        function PortalAttestationCase() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.IsReserved = _this.GetEntityValue('IsReserved');
            _this.ObjectKeyBase = _this.GetEntityValue('ObjectKeyBase');
            _this.DecisionLevel = _this.GetEntityValue('DecisionLevel');
            _this.PropertyInfo1 = _this.GetEntityValue('PropertyInfo1');
            _this.PropertyInfo2 = _this.GetEntityValue('PropertyInfo2');
            _this.PropertyInfo3 = _this.GetEntityValue('PropertyInfo3');
            _this.PropertyInfo4 = _this.GetEntityValue('PropertyInfo4');
            _this.ReportType = _this.GetEntityValue('ReportType');
            _this.RiskIndex = _this.GetEntityValue('RiskIndex');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.StructureDisplay1 = _this.GetEntityValue('StructureDisplay1');
            _this.StructureDisplay2 = _this.GetEntityValue('StructureDisplay2');
            _this.StructureDisplay3 = _this.GetEntityValue('StructureDisplay3');
            _this.ToSolveTill = _this.GetEntityValue('ToSolveTill');
            _this.UID_AttestationPolicy = _this.GetEntityValue('UID_AttestationPolicy');
            _this.IsNotApprovedBefore = _this.GetEntityValue('IsNotApprovedBefore');
            _this.UID_AttestationRun = _this.GetEntityValue('UID_AttestationRun');
            _this.UID_QERWorkingMethod = _this.GetEntityValue('UID_QERWorkingMethod');
            _this.IsApproveRequiresMfa = _this.GetEntityValue('IsApproveRequiresMfa');
            _this.AttestationState = _this.GetEntityValue('AttestationState');
            _this.MControls = _this.GetEntityValue('MControls');
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.SupportsAssignmentAnalysis = _this.GetEntityValue('SupportsAssignmentAnalysis');
            _this.UiText = _this.GetEntityValue('UiText');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationCase.GetEntitySchema = function () {
            var columns = {
                'IsReserved': {
                    ColumnName: 'IsReserved',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'ObjectKeyBase': {
                    ColumnName: 'ObjectKeyBase',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DecisionLevel': {
                    ColumnName: 'DecisionLevel',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'PropertyInfo1': {
                    ColumnName: 'PropertyInfo1',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PropertyInfo2': {
                    ColumnName: 'PropertyInfo2',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PropertyInfo3': {
                    ColumnName: 'PropertyInfo3',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PropertyInfo4': {
                    ColumnName: 'PropertyInfo4',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ReportType': {
                    ColumnName: 'ReportType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'RiskIndex': {
                    ColumnName: 'RiskIndex',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'StructureDisplay1': {
                    ColumnName: 'StructureDisplay1',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'StructureDisplay2': {
                    ColumnName: 'StructureDisplay2',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'StructureDisplay3': {
                    ColumnName: 'StructureDisplay3',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ToSolveTill': {
                    ColumnName: 'ToSolveTill',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_AttestationPolicy': {
                    ColumnName: 'UID_AttestationPolicy',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsNotApprovedBefore': {
                    ColumnName: 'IsNotApprovedBefore',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'UID_AttestationRun': {
                    ColumnName: 'UID_AttestationRun',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QERWorkingMethod': {
                    ColumnName: 'UID_QERWorkingMethod',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsApproveRequiresMfa': {
                    ColumnName: 'IsApproveRequiresMfa',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'AttestationState': {
                    ColumnName: 'AttestationState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'MControls': {
                    ColumnName: 'MControls',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'SupportsAssignmentAnalysis': {
                    ColumnName: 'SupportsAssignmentAnalysis',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'UiText': {
                    ColumnName: 'UiText',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AttestationCase', Columns: columns };
        };
        return PortalAttestationCase;
    }(imxQbmDbts.ReadWriteExtTypedEntity));
    /** @deprecated Use the PortalAttestationCase type. */
    var PortalAttestationCaseInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationCaseInteractive, _super);
        function PortalAttestationCaseInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationCaseInteractive;
    }(PortalAttestationCase));
    var PortalAttestationCaseHistory = /** @class */ (function (_super) {
        __extends(PortalAttestationCaseHistory, _super);
        function PortalAttestationCaseHistory() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.DateHead = _this.GetEntityValue('DateHead');
            _this.DecisionType = _this.GetEntityValue('DecisionType');
            _this.DisplayPersonHead = _this.GetEntityValue('DisplayPersonHead');
            _this.Ident_PWODecisionStep = _this.GetEntityValue('Ident_PWODecisionStep');
            _this.IsDecisionBySystem = _this.GetEntityValue('IsDecisionBySystem');
            _this.IsToHideInHistory = _this.GetEntityValue('IsToHideInHistory');
            _this.ReasonHead = _this.GetEntityValue('ReasonHead');
            _this.RulerLevel = _this.GetEntityValue('RulerLevel');
            _this.UID_PersonHead = _this.GetEntityValue('UID_PersonHead');
            _this.UID_PersonRelated = _this.GetEntityValue('UID_PersonRelated');
            _this.UID_PWODecisionRule = _this.GetEntityValue('UID_PWODecisionRule');
            _this.UID_QERJustification = _this.GetEntityValue('UID_QERJustification');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationCaseHistory.GetEntitySchema = function () {
            var columns = {
                'DateHead': {
                    ColumnName: 'DateHead',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'DecisionType': {
                    ColumnName: 'DecisionType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DisplayPersonHead': {
                    ColumnName: 'DisplayPersonHead',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Ident_PWODecisionStep': {
                    ColumnName: 'Ident_PWODecisionStep',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsDecisionBySystem': {
                    ColumnName: 'IsDecisionBySystem',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsToHideInHistory': {
                    ColumnName: 'IsToHideInHistory',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'ReasonHead': {
                    ColumnName: 'ReasonHead',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'RulerLevel': {
                    ColumnName: 'RulerLevel',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'UID_PersonHead': {
                    ColumnName: 'UID_PersonHead',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_PersonRelated': {
                    ColumnName: 'UID_PersonRelated',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_PWODecisionRule': {
                    ColumnName: 'UID_PWODecisionRule',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QERJustification': {
                    ColumnName: 'UID_QERJustification',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AttestationHistory', Columns: columns };
        };
        return PortalAttestationCaseHistory;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationCaseHistory type. */
    var PortalAttestationCaseHistoryInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationCaseHistoryInteractive, _super);
        function PortalAttestationCaseHistoryInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationCaseHistoryInteractive;
    }(PortalAttestationCaseHistory));
    var PortalAttestationCaseParameterCandidates = /** @class */ (function (_super) {
        __extends(PortalAttestationCaseParameterCandidates, _super);
        function PortalAttestationCaseParameterCandidates() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationCaseParameterCandidates.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'non_static_table', Columns: columns };
        };
        return PortalAttestationCaseParameterCandidates;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationCaseParameterCandidates type. */
    var PortalAttestationCaseParameterCandidatesInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationCaseParameterCandidatesInteractive, _super);
        function PortalAttestationCaseParameterCandidatesInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationCaseParameterCandidatesInteractive;
    }(PortalAttestationCaseParameterCandidates));
    var PortalAttestationFilterCandidates = /** @class */ (function (_super) {
        __extends(PortalAttestationFilterCandidates, _super);
        function PortalAttestationFilterCandidates() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationFilterCandidates.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'non_static_table', Columns: columns };
        };
        return PortalAttestationFilterCandidates;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationFilterCandidates type. */
    var PortalAttestationFilterCandidatesInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationFilterCandidatesInteractive, _super);
        function PortalAttestationFilterCandidatesInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationFilterCandidatesInteractive;
    }(PortalAttestationFilterCandidates));
    var PortalAttestationFilterMatchingobjects = /** @class */ (function (_super) {
        __extends(PortalAttestationFilterMatchingobjects, _super);
        function PortalAttestationFilterMatchingobjects() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Key = _this.GetEntityValue('Key');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationFilterMatchingobjects.GetEntitySchema = function () {
            var columns = {
                'Key': {
                    ColumnName: 'Key',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'non_static_table', Columns: columns };
        };
        return PortalAttestationFilterMatchingobjects;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationFilterMatchingobjects type. */
    var PortalAttestationFilterMatchingobjectsInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationFilterMatchingobjectsInteractive, _super);
        function PortalAttestationFilterMatchingobjectsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationFilterMatchingobjectsInteractive;
    }(PortalAttestationFilterMatchingobjects));
    var PortalAttestationObject = /** @class */ (function (_super) {
        __extends(PortalAttestationObject, _super);
        function PortalAttestationObject() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Description = _this.GetEntityValue('Description');
            _this.UID_AttestationType = _this.GetEntityValue('UID_AttestationType');
            _this.UID_DialogTable = _this.GetEntityValue('UID_DialogTable');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationObject.GetEntitySchema = function () {
            var columns = {
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AttestationType': {
                    ColumnName: 'UID_AttestationType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DialogTable': {
                    ColumnName: 'UID_DialogTable',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AttestationObject', Columns: columns };
        };
        return PortalAttestationObject;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationObject type. */
    var PortalAttestationObjectInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationObjectInteractive, _super);
        function PortalAttestationObjectInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationObjectInteractive;
    }(PortalAttestationObject));
    var PortalAttestationPersondecision = /** @class */ (function (_super) {
        __extends(PortalAttestationPersondecision, _super);
        function PortalAttestationPersondecision() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.OrderNumber = _this.GetEntityValue('OrderNumber');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationPersondecision.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'OrderNumber': {
                    ColumnName: 'OrderNumber',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalAttestationPersondecision;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationPersondecision type. */
    var PortalAttestationPersondecisionInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationPersondecisionInteractive, _super);
        function PortalAttestationPersondecisionInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationPersondecisionInteractive;
    }(PortalAttestationPersondecision));
    var PortalAttestationPolicy = /** @class */ (function (_super) {
        __extends(PortalAttestationPolicy, _super);
        function PortalAttestationPolicy() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_PersonOwner = _this.GetEntityValue('UID_PersonOwner');
            _this.UID_AttestationObject = _this.GetEntityValue('UID_AttestationObject');
            _this.Description = _this.GetEntityValue('Description');
            _this.UID_DialogSchedule = _this.GetEntityValue('UID_DialogSchedule');
            _this.IsInActive = _this.GetEntityValue('IsInActive');
            _this.IsOob = _this.GetEntityValue('IsOob');
            _this.CountCases = _this.GetEntityValue('CountCases');
            _this.CountOpenCases = _this.GetEntityValue('CountOpenCases');
            _this.OverdueCases = _this.GetEntityValue('OverdueCases');
            _this.NextRun = _this.GetEntityValue('NextRun');
            _this.IsProcessing = _this.GetEntityValue('IsProcessing');
            _this.Attestators = _this.GetEntityValue('Attestators');
            _this.Areas = _this.GetEntityValue('Areas');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationPolicy.GetEntitySchema = function () {
            var columns = {
                'UID_PersonOwner': {
                    ColumnName: 'UID_PersonOwner',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AttestationObject': {
                    ColumnName: 'UID_AttestationObject',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'UID_DialogSchedule': {
                    ColumnName: 'UID_DialogSchedule',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsInActive': {
                    ColumnName: 'IsInActive',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsOob': {
                    ColumnName: 'IsOob',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'CountCases': {
                    ColumnName: 'CountCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountOpenCases': {
                    ColumnName: 'CountOpenCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'OverdueCases': {
                    ColumnName: 'OverdueCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'NextRun': {
                    ColumnName: 'NextRun',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'IsProcessing': {
                    ColumnName: 'IsProcessing',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Attestators': {
                    ColumnName: 'Attestators',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Areas': {
                    ColumnName: 'Areas',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AttestationPolicy', Columns: columns };
        };
        return PortalAttestationPolicy;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationPolicy type. */
    var PortalAttestationPolicyInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationPolicyInteractive, _super);
        function PortalAttestationPolicyInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationPolicyInteractive;
    }(PortalAttestationPolicy));
    var PortalAttestationPolicyEdit = /** @class */ (function (_super) {
        __extends(PortalAttestationPolicyEdit, _super);
        function PortalAttestationPolicyEdit() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_PersonOwner = _this.GetEntityValue('UID_PersonOwner');
            _this.Description = _this.GetEntityValue('Description');
            _this.Ident_AttestationPolicy = _this.GetEntityValue('Ident_AttestationPolicy');
            _this.IsApproveRequiresMfa = _this.GetEntityValue('IsApproveRequiresMfa');
            _this.IsAutoCloseOldCases = _this.GetEntityValue('IsAutoCloseOldCases');
            _this.IsInActive = _this.GetEntityValue('IsInActive');
            _this.IsShowElementsInvolved = _this.GetEntityValue('IsShowElementsInvolved');
            _this.LimitOfOldCases = _this.GetEntityValue('LimitOfOldCases');
            _this.RiskIndex = _this.GetEntityValue('RiskIndex');
            _this.SolutionDays = _this.GetEntityValue('SolutionDays');
            _this.UID_AttestationObject = _this.GetEntityValue('UID_AttestationObject');
            _this.UID_AttestationPolicyGroup = _this.GetEntityValue('UID_AttestationPolicyGroup');
            _this.UID_DialogCulture = _this.GetEntityValue('UID_DialogCulture');
            _this.UID_DialogSchedule = _this.GetEntityValue('UID_DialogSchedule');
            _this.UID_PWODecisionMethod = _this.GetEntityValue('UID_PWODecisionMethod');
            _this.UID_QERPickCategory = _this.GetEntityValue('UID_QERPickCategory');
            _this.UID_QERTermsOfUse = _this.GetEntityValue('UID_QERTermsOfUse');
            _this.NextRun = _this.GetEntityValue('NextRun');
            _this.IsPickCategoryMismatch = _this.GetEntityValue('IsPickCategoryMismatch');
            _this.IsOob = _this.GetEntityValue('IsOob');
            _this.CountOpenCases = _this.GetEntityValue('CountOpenCases');
            _this.IsPolicyWithRemove = _this.GetEntityValue('IsPolicyWithRemove');
            _this.Attestators = _this.GetEntityValue('Attestators');
            _this.Areas = _this.GetEntityValue('Areas');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationPolicyEdit.GetEntitySchema = function () {
            var columns = {
                'UID_PersonOwner': {
                    ColumnName: 'UID_PersonOwner',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: false,
                },
                'Ident_AttestationPolicy': {
                    ColumnName: 'Ident_AttestationPolicy',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'IsApproveRequiresMfa': {
                    ColumnName: 'IsApproveRequiresMfa',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: false,
                },
                'IsAutoCloseOldCases': {
                    ColumnName: 'IsAutoCloseOldCases',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: false,
                },
                'IsInActive': {
                    ColumnName: 'IsInActive',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: false,
                },
                'IsShowElementsInvolved': {
                    ColumnName: 'IsShowElementsInvolved',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: false,
                },
                'LimitOfOldCases': {
                    ColumnName: 'LimitOfOldCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: false,
                },
                'RiskIndex': {
                    ColumnName: 'RiskIndex',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: false,
                },
                'SolutionDays': {
                    ColumnName: 'SolutionDays',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: false,
                },
                'UID_AttestationObject': {
                    ColumnName: 'UID_AttestationObject',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_AttestationPolicyGroup': {
                    ColumnName: 'UID_AttestationPolicyGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_DialogCulture': {
                    ColumnName: 'UID_DialogCulture',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_DialogSchedule': {
                    ColumnName: 'UID_DialogSchedule',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_PWODecisionMethod': {
                    ColumnName: 'UID_PWODecisionMethod',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_QERPickCategory': {
                    ColumnName: 'UID_QERPickCategory',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_QERTermsOfUse': {
                    ColumnName: 'UID_QERTermsOfUse',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'NextRun': {
                    ColumnName: 'NextRun',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'IsPickCategoryMismatch': {
                    ColumnName: 'IsPickCategoryMismatch',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsOob': {
                    ColumnName: 'IsOob',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'CountOpenCases': {
                    ColumnName: 'CountOpenCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPolicyWithRemove': {
                    ColumnName: 'IsPolicyWithRemove',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Attestators': {
                    ColumnName: 'Attestators',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'Areas': {
                    ColumnName: 'Areas',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AttestationPolicy', Columns: columns };
        };
        return PortalAttestationPolicyEdit;
    }(imxQbmDbts.ReadWriteExtTypedEntity));
    /** @deprecated Use the PortalAttestationPolicyEdit type. */
    var PortalAttestationPolicyEditInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationPolicyEditInteractive, _super);
        function PortalAttestationPolicyEditInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationPolicyEditInteractive;
    }(PortalAttestationPolicyEdit));
    var PortalAttestationPolicygroups = /** @class */ (function (_super) {
        __extends(PortalAttestationPolicygroups, _super);
        function PortalAttestationPolicygroups() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Description = _this.GetEntityValue('Description');
            _this.Ident_AttestationPolicyGroup = _this.GetEntityValue('Ident_AttestationPolicyGroup');
            _this.IsInActive = _this.GetEntityValue('IsInActive');
            _this.UID_AERoleOwner = _this.GetEntityValue('UID_AERoleOwner');
            _this.UID_AttestationPolicyGroup = _this.GetEntityValue('UID_AttestationPolicyGroup');
            _this.UID_DialogSchedule = _this.GetEntityValue('UID_DialogSchedule');
            _this.UID_PersonOwner = _this.GetEntityValue('UID_PersonOwner');
            _this.UID_QERPickCategory = _this.GetEntityValue('UID_QERPickCategory');
            _this.XTouched = _this.GetEntityValue('XTouched');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationPolicygroups.GetEntitySchema = function () {
            var columns = {
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: false,
                },
                'Ident_AttestationPolicyGroup': {
                    ColumnName: 'Ident_AttestationPolicyGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'IsInActive': {
                    ColumnName: 'IsInActive',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: false,
                },
                'UID_AERoleOwner': {
                    ColumnName: 'UID_AERoleOwner',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_AttestationPolicyGroup': {
                    ColumnName: 'UID_AttestationPolicyGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_DialogSchedule': {
                    ColumnName: 'UID_DialogSchedule',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_PersonOwner': {
                    ColumnName: 'UID_PersonOwner',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_QERPickCategory': {
                    ColumnName: 'UID_QERPickCategory',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'XTouched': {
                    ColumnName: 'XTouched',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AttestationPolicyGroup', Columns: columns };
        };
        return PortalAttestationPolicygroups;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationPolicygroups type. */
    var PortalAttestationPolicygroupsInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationPolicygroupsInteractive, _super);
        function PortalAttestationPolicygroupsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationPolicygroupsInteractive;
    }(PortalAttestationPolicygroups));
    var PortalAttestationRun = /** @class */ (function (_super) {
        __extends(PortalAttestationRun, _super);
        function PortalAttestationRun() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AttestationPolicy = _this.GetEntityValue('UID_AttestationPolicy');
            _this.PolicyProcessed = _this.GetEntityValue('PolicyProcessed');
            _this.CountChunksUnderConstruction = _this.GetEntityValue('CountChunksUnderConstruction');
            _this.UID_AttestationPolicyGroup = _this.GetEntityValue('UID_AttestationPolicyGroup');
            _this.DueDate = _this.GetEntityValue('DueDate');
            _this.PendingCases = _this.GetEntityValue('PendingCases');
            _this.ClosedCases = _this.GetEntityValue('ClosedCases');
            _this.GrantedCases = _this.GetEntityValue('GrantedCases');
            _this.DeniedCases = _this.GetEntityValue('DeniedCases');
            _this.CasesAbortedBySystem = _this.GetEntityValue('CasesAbortedBySystem');
            _this.DelegatedCases = _this.GetEntityValue('DelegatedCases');
            _this.EscalatedCases = _this.GetEntityValue('EscalatedCases');
            _this.NewCases = _this.GetEntityValue('NewCases');
            _this.Speed = _this.GetEntityValue('Speed');
            _this.AbortedBySystem = _this.GetEntityValue('AbortedBySystem');
            _this.Delay = _this.GetEntityValue('Delay');
            _this.Progress = _this.GetEntityValue('Progress');
            _this.SecondsGone = _this.GetEntityValue('SecondsGone');
            _this.SecondsLeft = _this.GetEntityValue('SecondsLeft');
            _this.RunCategory = _this.GetEntityValue('RunCategory');
            _this.ForecastClosedCases = _this.GetEntityValue('ForecastClosedCases');
            _this.ForecastProgress = _this.GetEntityValue('ForecastProgress');
            _this.ForecastRemainingDays = _this.GetEntityValue('ForecastRemainingDays');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationRun.GetEntitySchema = function () {
            var columns = {
                'UID_AttestationPolicy': {
                    ColumnName: 'UID_AttestationPolicy',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PolicyProcessed': {
                    ColumnName: 'PolicyProcessed',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'CountChunksUnderConstruction': {
                    ColumnName: 'CountChunksUnderConstruction',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'UID_AttestationPolicyGroup': {
                    ColumnName: 'UID_AttestationPolicyGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DueDate': {
                    ColumnName: 'DueDate',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'PendingCases': {
                    ColumnName: 'PendingCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'ClosedCases': {
                    ColumnName: 'ClosedCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'GrantedCases': {
                    ColumnName: 'GrantedCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'DeniedCases': {
                    ColumnName: 'DeniedCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CasesAbortedBySystem': {
                    ColumnName: 'CasesAbortedBySystem',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'DelegatedCases': {
                    ColumnName: 'DelegatedCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'EscalatedCases': {
                    ColumnName: 'EscalatedCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'NewCases': {
                    ColumnName: 'NewCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'Speed': {
                    ColumnName: 'Speed',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'AbortedBySystem': {
                    ColumnName: 'AbortedBySystem',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'Delay': {
                    ColumnName: 'Delay',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'Progress': {
                    ColumnName: 'Progress',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'SecondsGone': {
                    ColumnName: 'SecondsGone',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'SecondsLeft': {
                    ColumnName: 'SecondsLeft',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'RunCategory': {
                    ColumnName: 'RunCategory',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ForecastClosedCases': {
                    ColumnName: 'ForecastClosedCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'ForecastProgress': {
                    ColumnName: 'ForecastProgress',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'ForecastRemainingDays': {
                    ColumnName: 'ForecastRemainingDays',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AttestationRun', Columns: columns };
        };
        return PortalAttestationRun;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationRun type. */
    var PortalAttestationRunInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationRunInteractive, _super);
        function PortalAttestationRunInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationRunInteractive;
    }(PortalAttestationRun));
    var PortalAttestationRunApprovers = /** @class */ (function (_super) {
        __extends(PortalAttestationRunApprovers, _super);
        function PortalAttestationRunApprovers() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_PersonHead = _this.GetEntityValue('UID_PersonHead');
            _this.PendingCases = _this.GetEntityValue('PendingCases');
            _this.ClosedCases = _this.GetEntityValue('ClosedCases');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationRunApprovers.GetEntitySchema = function () {
            var columns = {
                'UID_PersonHead': {
                    ColumnName: 'UID_PersonHead',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PendingCases': {
                    ColumnName: 'PendingCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'ClosedCases': {
                    ColumnName: 'ClosedCases',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalAttestationRunApprovers;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationRunApprovers type. */
    var PortalAttestationRunApproversInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationRunApproversInteractive, _super);
        function PortalAttestationRunApproversInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationRunApproversInteractive;
    }(PortalAttestationRunApprovers));
    var PortalAttestationSchedules = /** @class */ (function (_super) {
        __extends(PortalAttestationSchedules, _super);
        function PortalAttestationSchedules() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.LastRun = _this.GetEntityValue('LastRun');
            _this.NextRun = _this.GetEntityValue('NextRun');
            _this.Frequency = _this.GetEntityValue('Frequency');
            _this.FrequencyType = _this.GetEntityValue('FrequencyType');
            _this.Description = _this.GetEntityValue('Description');
            _this.Enabled = _this.GetEntityValue('Enabled');
            _this.FrequencySubType = _this.GetEntityValue('FrequencySubType');
            _this.StartTime = _this.GetEntityValue('StartTime');
            _this.UID_DialogTimeZone = _this.GetEntityValue('UID_DialogTimeZone');
            _this.DayOfYear = _this.GetEntityValue('DayOfYear');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationSchedules.GetEntitySchema = function () {
            var columns = {
                'LastRun': {
                    ColumnName: 'LastRun',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'NextRun': {
                    ColumnName: 'NextRun',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'Frequency': {
                    ColumnName: 'Frequency',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'FrequencyType': {
                    ColumnName: 'FrequencyType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Enabled': {
                    ColumnName: 'Enabled',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: false,
                },
                'FrequencySubType': {
                    ColumnName: 'FrequencySubType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'StartTime': {
                    ColumnName: 'StartTime',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_DialogTimeZone': {
                    ColumnName: 'UID_DialogTimeZone',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'DayOfYear': {
                    ColumnName: 'DayOfYear',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DialogSchedule', Columns: columns };
        };
        return PortalAttestationSchedules;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationSchedules type. */
    var PortalAttestationSchedulesInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationSchedulesInteractive, _super);
        function PortalAttestationSchedulesInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationSchedulesInteractive;
    }(PortalAttestationSchedules));
    var PortalAttestationWorkflow = /** @class */ (function (_super) {
        __extends(PortalAttestationWorkflow, _super);
        function PortalAttestationWorkflow() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.LevelNumber = _this.GetEntityValue('LevelNumber');
            _this.LevelDisplay = _this.GetEntityValue('LevelDisplay');
            _this.Ident_PWODecisionStep = _this.GetEntityValue('Ident_PWODecisionStep');
            _this.SubLevelNumber = _this.GetEntityValue('SubLevelNumber');
            _this.DirectSteps = _this.GetEntityValue('DirectSteps');
            _this.PositiveSteps = _this.GetEntityValue('PositiveSteps');
            _this.NegativeSteps = _this.GetEntityValue('NegativeSteps');
            _this.CountApprover = _this.GetEntityValue('CountApprover');
            _this.EscalationSteps = _this.GetEntityValue('EscalationSteps');
            _this.UID_PWODecisionRule = _this.GetEntityValue('UID_PWODecisionRule');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalAttestationWorkflow.GetEntitySchema = function () {
            var columns = {
                'LevelNumber': {
                    ColumnName: 'LevelNumber',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'LevelDisplay': {
                    ColumnName: 'LevelDisplay',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Ident_PWODecisionStep': {
                    ColumnName: 'Ident_PWODecisionStep',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'SubLevelNumber': {
                    ColumnName: 'SubLevelNumber',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'DirectSteps': {
                    ColumnName: 'DirectSteps',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PositiveSteps': {
                    ColumnName: 'PositiveSteps',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'NegativeSteps': {
                    ColumnName: 'NegativeSteps',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountApprover': {
                    ColumnName: 'CountApprover',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'EscalationSteps': {
                    ColumnName: 'EscalationSteps',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'UID_PWODecisionRule': {
                    ColumnName: 'UID_PWODecisionRule',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QERWorkingStep', Columns: columns };
        };
        return PortalAttestationWorkflow;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalAttestationWorkflow type. */
    var PortalAttestationWorkflowInteractive = /** @class */ (function (_super) {
        __extends(PortalAttestationWorkflowInteractive, _super);
        function PortalAttestationWorkflowInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalAttestationWorkflowInteractive;
    }(PortalAttestationWorkflow));
    var PortalCandidatesAerole = /** @class */ (function (_super) {
        __extends(PortalCandidatesAerole, _super);
        function PortalCandidatesAerole() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_AERole = _this.GetEntityValue('UID_AERole');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesAerole.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AERole': {
                    ColumnName: 'UID_AERole',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AERole', Columns: columns };
        };
        return PortalCandidatesAerole;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesAerole type. */
    var PortalCandidatesAeroleInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesAeroleInteractive, _super);
        function PortalCandidatesAeroleInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesAeroleInteractive;
    }(PortalCandidatesAerole));
    var PortalCandidatesAttestationpolicygroup = /** @class */ (function (_super) {
        __extends(PortalCandidatesAttestationpolicygroup, _super);
        function PortalCandidatesAttestationpolicygroup() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_AttestationPolicyGroup = _this.GetEntityValue('UID_AttestationPolicyGroup');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesAttestationpolicygroup.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AttestationPolicyGroup': {
                    ColumnName: 'UID_AttestationPolicyGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AttestationPolicyGroup', Columns: columns };
        };
        return PortalCandidatesAttestationpolicygroup;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesAttestationpolicygroup type. */
    var PortalCandidatesAttestationpolicygroupInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesAttestationpolicygroupInteractive, _super);
        function PortalCandidatesAttestationpolicygroupInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesAttestationpolicygroupInteractive;
    }(PortalCandidatesAttestationpolicygroup));
    var PortalCandidatesCompliancearea = /** @class */ (function (_super) {
        __extends(PortalCandidatesCompliancearea, _super);
        function PortalCandidatesCompliancearea() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_ComplianceArea = _this.GetEntityValue('UID_ComplianceArea');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesCompliancearea.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_ComplianceArea': {
                    ColumnName: 'UID_ComplianceArea',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ComplianceArea', Columns: columns };
        };
        return PortalCandidatesCompliancearea;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesCompliancearea type. */
    var PortalCandidatesComplianceareaInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesComplianceareaInteractive, _super);
        function PortalCandidatesComplianceareaInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesComplianceareaInteractive;
    }(PortalCandidatesCompliancearea));
    var PortalCandidatesDialogtimezone = /** @class */ (function (_super) {
        __extends(PortalCandidatesDialogtimezone, _super);
        function PortalCandidatesDialogtimezone() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_DialogTimeZone = _this.GetEntityValue('UID_DialogTimeZone');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesDialogtimezone.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DialogTimeZone': {
                    ColumnName: 'UID_DialogTimeZone',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DialogTimeZone', Columns: columns };
        };
        return PortalCandidatesDialogtimezone;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesDialogtimezone type. */
    var PortalCandidatesDialogtimezoneInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesDialogtimezoneInteractive, _super);
        function PortalCandidatesDialogtimezoneInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesDialogtimezoneInteractive;
    }(PortalCandidatesDialogtimezone));
    var PortalCandidatesMitigatingcontrol = /** @class */ (function (_super) {
        __extends(PortalCandidatesMitigatingcontrol, _super);
        function PortalCandidatesMitigatingcontrol() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_MitigatingControl = _this.GetEntityValue('UID_MitigatingControl');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesMitigatingcontrol.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_MitigatingControl': {
                    ColumnName: 'UID_MitigatingControl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'MitigatingControl', Columns: columns };
        };
        return PortalCandidatesMitigatingcontrol;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesMitigatingcontrol type. */
    var PortalCandidatesMitigatingcontrolInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesMitigatingcontrolInteractive, _super);
        function PortalCandidatesMitigatingcontrolInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesMitigatingcontrolInteractive;
    }(PortalCandidatesMitigatingcontrol));
    var PortalCandidatesPerson = /** @class */ (function (_super) {
        __extends(PortalCandidatesPerson, _super);
        function PortalCandidatesPerson() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.DefaultEmailAddress = _this.GetEntityValue('DefaultEmailAddress');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesPerson.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DefaultEmailAddress': {
                    ColumnName: 'DefaultEmailAddress',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'Person', Columns: columns };
        };
        return PortalCandidatesPerson;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesPerson type. */
    var PortalCandidatesPersonInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesPersonInteractive, _super);
        function PortalCandidatesPersonInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesPersonInteractive;
    }(PortalCandidatesPerson));
    var PortalCandidatesQbmculture = /** @class */ (function (_super) {
        __extends(PortalCandidatesQbmculture, _super);
        function PortalCandidatesQbmculture() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_DialogCulture = _this.GetEntityValue('UID_DialogCulture');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesQbmculture.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DialogCulture': {
                    ColumnName: 'UID_DialogCulture',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMCulture', Columns: columns };
        };
        return PortalCandidatesQbmculture;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesQbmculture type. */
    var PortalCandidatesQbmcultureInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesQbmcultureInteractive, _super);
        function PortalCandidatesQbmcultureInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesQbmcultureInteractive;
    }(PortalCandidatesQbmculture));
    var PortalCandidatesQertermsofuse = /** @class */ (function (_super) {
        __extends(PortalCandidatesQertermsofuse, _super);
        function PortalCandidatesQertermsofuse() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_QERTermsOfUse = _this.GetEntityValue('UID_QERTermsOfUse');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesQertermsofuse.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QERTermsOfUse': {
                    ColumnName: 'UID_QERTermsOfUse',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QERTermsOfUse', Columns: columns };
        };
        return PortalCandidatesQertermsofuse;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesQertermsofuse type. */
    var PortalCandidatesQertermsofuseInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesQertermsofuseInteractive, _super);
        function PortalCandidatesQertermsofuseInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesQertermsofuseInteractive;
    }(PortalCandidatesQertermsofuse));
    var PortalClaimdeviceDevices = /** @class */ (function (_super) {
        __extends(PortalClaimdeviceDevices, _super);
        function PortalClaimdeviceDevices() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalClaimdeviceDevices.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'Hardware', Columns: columns };
        };
        return PortalClaimdeviceDevices;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalClaimdeviceDevices type. */
    var PortalClaimdeviceDevicesInteractive = /** @class */ (function (_super) {
        __extends(PortalClaimdeviceDevicesInteractive, _super);
        function PortalClaimdeviceDevicesInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalClaimdeviceDevicesInteractive;
    }(PortalClaimdeviceDevices));
    var RegisterPerson = /** @class */ (function (_super) {
        __extends(RegisterPerson, _super);
        function RegisterPerson() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.CentralAccount = _this.GetEntityValue('CentralAccount');
            _this.DefaultEmailAddress = _this.GetEntityValue('DefaultEmailAddress');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        RegisterPerson.GetEntitySchema = function () {
            var columns = {
                'CentralAccount': {
                    ColumnName: 'CentralAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DefaultEmailAddress': {
                    ColumnName: 'DefaultEmailAddress',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'Person', Columns: columns };
        };
        return RegisterPerson;
    }(imxQbmDbts.WriteExtTypedEntity));
    /** @deprecated Use the RegisterPerson type. */
    var RegisterPersonInteractive = /** @class */ (function (_super) {
        __extends(RegisterPersonInteractive, _super);
        function RegisterPersonInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return RegisterPersonInteractive;
    }(RegisterPerson));
    var OpsupportCandidatesDialogtimezoneWrapper = /** @class */ (function () {
        function OpsupportCandidatesDialogtimezoneWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportCandidatesDialogtimezoneWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/candidates/DialogTimeZone');
        };
        OpsupportCandidatesDialogtimezoneWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/candidates/DialogTimeZone');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportCandidatesDialogtimezone, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportCandidatesDialogtimezoneWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_candidates_DialogTimeZone_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportCandidatesDialogtimezoneWrapper;
    }());
    var PasswordresetCandidatesDialogtimezoneWrapper = /** @class */ (function () {
        function PasswordresetCandidatesDialogtimezoneWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PasswordresetCandidatesDialogtimezoneWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('passwordreset/candidates/DialogTimeZone');
        };
        PasswordresetCandidatesDialogtimezoneWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('passwordreset/candidates/DialogTimeZone');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PasswordresetCandidatesDialogtimezone, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PasswordresetCandidatesDialogtimezoneWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.passwordreset_candidates_DialogTimeZone_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PasswordresetCandidatesDialogtimezoneWrapper;
    }());
    var PortalAttestationApproveWrapper = /** @class */ (function () {
        function PortalAttestationApproveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_attestation_approve_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationApproveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/approve');
        };
        PortalAttestationApproveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/approve');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationApprove, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationApproveWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_approve_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAttestationApproveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_approve_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationApproveWrapper;
    }());
    var PortalAttestationApproveParameterCandidatesWrapper = /** @class */ (function () {
        function PortalAttestationApproveParameterCandidatesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationApproveParameterCandidatesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/approve/parameter/{name}/candidates/{parenttable}');
        };
        PortalAttestationApproveParameterCandidatesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/approve/parameter/{name}/candidates/{parenttable}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationApproveParameterCandidates, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationApproveParameterCandidatesWrapper.prototype.Post = function (name, parenttable, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_approve_parameter_candidates_post(name, parenttable, inputParameterName.EntityKeysData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationApproveParameterCandidatesWrapper;
    }());
    var PortalAttestationCaseWrapper = /** @class */ (function () {
        function PortalAttestationCaseWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationCaseWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/case');
        };
        PortalAttestationCaseWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/case');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationCase, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationCaseWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_case_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationCaseWrapper;
    }());
    var PortalAttestationCaseHistoryWrapper = /** @class */ (function () {
        function PortalAttestationCaseHistoryWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationCaseHistoryWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/case/history/{uidcase}');
        };
        PortalAttestationCaseHistoryWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/case/history/{uidcase}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationCaseHistory, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationCaseHistoryWrapper.prototype.Get = function (uidcase, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_case_history_get(uidcase, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationCaseHistoryWrapper;
    }());
    var PortalAttestationCaseParameterCandidatesWrapper = /** @class */ (function () {
        function PortalAttestationCaseParameterCandidatesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationCaseParameterCandidatesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/case/parameter/{name}/candidates/{parenttable}');
        };
        PortalAttestationCaseParameterCandidatesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/case/parameter/{name}/candidates/{parenttable}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationCaseParameterCandidates, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationCaseParameterCandidatesWrapper.prototype.Post = function (name, parenttable, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_case_parameter_candidates_post(name, parenttable, inputParameterName.EntityKeysData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationCaseParameterCandidatesWrapper;
    }());
    var PortalAttestationFilterCandidatesWrapper = /** @class */ (function () {
        function PortalAttestationFilterCandidatesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationFilterCandidatesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/filter/candidates/{uidattestationparm}');
        };
        PortalAttestationFilterCandidatesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/filter/candidates/{uidattestationparm}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationFilterCandidates, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationFilterCandidatesWrapper.prototype.Get = function (uidattestationparm, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_filter_candidates_get(uidattestationparm, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationFilterCandidatesWrapper;
    }());
    var PortalAttestationFilterMatchingobjectsWrapper = /** @class */ (function () {
        function PortalAttestationFilterMatchingobjectsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationFilterMatchingobjectsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/filter/matchingobjects/{uidattestationobject}');
        };
        PortalAttestationFilterMatchingobjectsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/filter/matchingobjects/{uidattestationobject}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationFilterMatchingobjects, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationFilterMatchingobjectsWrapper.prototype.Get = function (uidattestationobject, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_filter_matchingobjects_get(uidattestationobject, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationFilterMatchingobjectsWrapper;
    }());
    var PortalAttestationObjectWrapper = /** @class */ (function () {
        function PortalAttestationObjectWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationObjectWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/object');
        };
        PortalAttestationObjectWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/object');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationObject, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationObjectWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_object_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationObjectWrapper;
    }());
    var PortalAttestationPersondecisionWrapper = /** @class */ (function () {
        function PortalAttestationPersondecisionWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationPersondecisionWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/persondecision/{uidattestationcase}');
        };
        PortalAttestationPersondecisionWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/persondecision/{uidattestationcase}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationPersondecision, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationPersondecisionWrapper.prototype.Get = function (uidattestationcase, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_persondecision_get(uidattestationcase, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationPersondecisionWrapper;
    }());
    var PortalAttestationPolicyWrapper = /** @class */ (function () {
        function PortalAttestationPolicyWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationPolicyWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/policy');
        };
        PortalAttestationPolicyWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/policy');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationPolicy, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationPolicyWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policy_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationPolicyWrapper;
    }());
    var PortalAttestationPolicyEditWrapper = /** @class */ (function () {
        function PortalAttestationPolicyEditWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.deleteMethod = function (entity) {
                return _this.client.portal_attestation_policy_edit_delete(entity.GetColumn('UID_AttestationPolicy').GetValue());
            };
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationPolicyEditWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/policy/edit');
        };
        PortalAttestationPolicyEditWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/policy/edit');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationPolicyEdit, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationPolicyEditWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policy_edit_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAttestationPolicyEditWrapper.prototype.Delete = function (UID_AttestationPolicy, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policy_edit_delete(UID_AttestationPolicy, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationPolicyEditWrapper;
    }());
    var PortalAttestationPolicyEditInteractiveWrapper = /** @class */ (function () {
        function PortalAttestationPolicyEditInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_attestation_policy_edit_interactive_put(writeData);
            };
            this.deleteMethod = function (entity, deleteData) {
                return _this.client.portal_attestation_policy_edit_interactive_delete(deleteData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationPolicyEditInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/policy/edit/interactive');
        };
        PortalAttestationPolicyEditInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/policy/edit/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalAttestationPolicyEdit, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationPolicyEditInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policy_edit_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAttestationPolicyEditInteractiveWrapper.prototype.Delete = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policy_edit_interactive_delete(inputParameterName.InteractiveEntityDeleteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAttestationPolicyEditInteractiveWrapper.prototype.Get_byid = function (UID_AttestationPolicy, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policy_edit_interactive_byid_get(UID_AttestationPolicy, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAttestationPolicyEditInteractiveWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policy_edit_interactive_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationPolicyEditInteractiveWrapper;
    }());
    var PortalAttestationPolicygroupsWrapper = /** @class */ (function () {
        function PortalAttestationPolicygroupsWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.deleteMethod = function (entity) {
                return _this.client.portal_attestation_policygroups_delete(entity.GetColumn('UID_AttestationPolicyGroup').GetValue());
            };
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationPolicygroupsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/policygroups');
        };
        PortalAttestationPolicygroupsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/policygroups');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationPolicygroups, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationPolicygroupsWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policygroups_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAttestationPolicygroupsWrapper.prototype.Delete = function (UID_AttestationPolicyGroup, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policygroups_delete(UID_AttestationPolicyGroup, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationPolicygroupsWrapper;
    }());
    var PortalAttestationPolicygroupsInteractiveWrapper = /** @class */ (function () {
        function PortalAttestationPolicygroupsInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_attestation_policygroups_interactive_put(writeData);
            };
            this.deleteMethod = function (entity, deleteData) {
                return _this.client.portal_attestation_policygroups_interactive_delete(deleteData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationPolicygroupsInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/policygroups/interactive');
        };
        PortalAttestationPolicygroupsInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/policygroups/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalAttestationPolicygroups, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationPolicygroupsInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policygroups_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAttestationPolicygroupsInteractiveWrapper.prototype.Delete = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policygroups_interactive_delete(inputParameterName.InteractiveEntityDeleteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAttestationPolicygroupsInteractiveWrapper.prototype.Get_byid = function (UID_AttestationPolicyGroup, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policygroups_interactive_byid_get(UID_AttestationPolicyGroup, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAttestationPolicygroupsInteractiveWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_policygroups_interactive_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationPolicygroupsInteractiveWrapper;
    }());
    var PortalAttestationRunWrapper = /** @class */ (function () {
        function PortalAttestationRunWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationRunWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/run');
        };
        PortalAttestationRunWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/run');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationRun, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationRunWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_run_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationRunWrapper;
    }());
    var PortalAttestationRunApproversWrapper = /** @class */ (function () {
        function PortalAttestationRunApproversWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationRunApproversWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/run/{uidrun}/approvers');
        };
        PortalAttestationRunApproversWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/run/{uidrun}/approvers');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationRunApprovers, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationRunApproversWrapper.prototype.Get = function (uidrun, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_run_approvers_get(uidrun, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationRunApproversWrapper;
    }());
    var PortalAttestationSchedulesWrapper = /** @class */ (function () {
        function PortalAttestationSchedulesWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_attestation_schedules_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationSchedulesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/schedules');
        };
        PortalAttestationSchedulesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/schedules');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationSchedules, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationSchedulesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_schedules_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalAttestationSchedulesWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_schedules_put(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationSchedulesWrapper;
    }());
    var PortalAttestationWorkflowWrapper = /** @class */ (function () {
        function PortalAttestationWorkflowWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalAttestationWorkflowWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/attestation/workflow/{uidattestationcase}');
        };
        PortalAttestationWorkflowWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/attestation/workflow/{uidattestationcase}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalAttestationWorkflow, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalAttestationWorkflowWrapper.prototype.Get = function (uidattestationcase, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_attestation_workflow_get(uidattestationcase, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalAttestationWorkflowWrapper;
    }());
    var PortalCandidatesAeroleWrapper = /** @class */ (function () {
        function PortalCandidatesAeroleWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesAeroleWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/AERole');
        };
        PortalCandidatesAeroleWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/AERole');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesAerole, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesAeroleWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_AERole_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesAeroleWrapper;
    }());
    var PortalCandidatesAttestationpolicygroupWrapper = /** @class */ (function () {
        function PortalCandidatesAttestationpolicygroupWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesAttestationpolicygroupWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/AttestationPolicyGroup');
        };
        PortalCandidatesAttestationpolicygroupWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/AttestationPolicyGroup');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesAttestationpolicygroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesAttestationpolicygroupWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_AttestationPolicyGroup_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesAttestationpolicygroupWrapper;
    }());
    var PortalCandidatesComplianceareaWrapper = /** @class */ (function () {
        function PortalCandidatesComplianceareaWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesComplianceareaWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/ComplianceArea');
        };
        PortalCandidatesComplianceareaWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/ComplianceArea');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesCompliancearea, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesComplianceareaWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_ComplianceArea_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesComplianceareaWrapper;
    }());
    var PortalCandidatesDialogtimezoneWrapper = /** @class */ (function () {
        function PortalCandidatesDialogtimezoneWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesDialogtimezoneWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/DialogTimeZone');
        };
        PortalCandidatesDialogtimezoneWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/DialogTimeZone');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesDialogtimezone, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesDialogtimezoneWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_DialogTimeZone_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesDialogtimezoneWrapper;
    }());
    var PortalCandidatesMitigatingcontrolWrapper = /** @class */ (function () {
        function PortalCandidatesMitigatingcontrolWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesMitigatingcontrolWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/MitigatingControl');
        };
        PortalCandidatesMitigatingcontrolWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/MitigatingControl');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesMitigatingcontrol, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesMitigatingcontrolWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_MitigatingControl_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesMitigatingcontrolWrapper;
    }());
    var PortalCandidatesPersonWrapper = /** @class */ (function () {
        function PortalCandidatesPersonWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesPersonWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/Person');
        };
        PortalCandidatesPersonWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/Person');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesPerson, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesPersonWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_Person_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesPersonWrapper;
    }());
    var PortalCandidatesQbmcultureWrapper = /** @class */ (function () {
        function PortalCandidatesQbmcultureWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesQbmcultureWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/QBMCulture');
        };
        PortalCandidatesQbmcultureWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/QBMCulture');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesQbmculture, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesQbmcultureWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_QBMCulture_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesQbmcultureWrapper;
    }());
    var PortalCandidatesQertermsofuseWrapper = /** @class */ (function () {
        function PortalCandidatesQertermsofuseWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesQertermsofuseWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/QERTermsOfUse');
        };
        PortalCandidatesQertermsofuseWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/QERTermsOfUse');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesQertermsofuse, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesQertermsofuseWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_QERTermsOfUse_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesQertermsofuseWrapper;
    }());
    var PortalClaimdeviceDevicesWrapper = /** @class */ (function () {
        function PortalClaimdeviceDevicesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalClaimdeviceDevicesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/claimdevice/devices');
        };
        PortalClaimdeviceDevicesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/claimdevice/devices');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalClaimdeviceDevices, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalClaimdeviceDevicesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_claimdevice_devices_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalClaimdeviceDevicesWrapper;
    }());
    var RegisterPersonWrapper = /** @class */ (function () {
        function RegisterPersonWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.register_person_post(writeData);
                }
            };
        }
        RegisterPersonWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        RegisterPersonWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('register/person');
        };
        RegisterPersonWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('register/person');
                this.builder = new imxQbmDbts.TypedEntityBuilder(RegisterPerson, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        RegisterPersonWrapper.prototype.Post = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.register_person_post(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return RegisterPersonWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.admin_config_get = function () {
            return {
                path: '/admin/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_config_post = function (inputParameterName) {
            return {
                path: '/admin/config',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_config_get = function () {
            return {
                path: '/imx/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_candidates_DialogTimeZone_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/candidates/DialogTimeZone',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_candidates_DialogTimeZone_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/opsupport/candidates/DialogTimeZone/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_config_get = function () {
            return {
                path: '/opsupport/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_featureconfig_get = function () {
            return {
                path: '/opsupport/featureconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.passwordreset_activation_confirm_post = function (inputParameterName) {
            return {
                path: '/passwordreset/activation/confirm',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.passwordreset_activation_init_post = function (uidcase) {
            return {
                path: '/passwordreset/activation/init/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.passwordreset_activation_resendemail_post = function () {
            return {
                path: '/passwordreset/activation/resendemail',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.passwordreset_candidates_DialogTimeZone_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/passwordreset/candidates/DialogTimeZone',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.passwordreset_candidates_DialogTimeZone_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/passwordreset/candidates/DialogTimeZone/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.passwordreset_config_get = function () {
            return {
                path: '/passwordreset/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_additional_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/additional/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_answerquery_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/answerquery/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_approve_get = function (Escalation, objecttable, objectuid, uid_attestationcase, uid_attestationhelper, forinquiry, OrderBy, StartIndex, PageSize, filter, withProperties, search, attestationtype, uidpolicy, type, risk) {
            return {
                path: '/portal/attestation/approve',
                parameters: [
                    {
                        name: 'Escalation',
                        value: Escalation,
                        in: 'query'
                    },
                    {
                        name: 'objecttable',
                        value: objecttable,
                        in: 'query'
                    },
                    {
                        name: 'objectuid',
                        value: objectuid,
                        in: 'query'
                    },
                    {
                        name: 'uid_attestationcase',
                        value: uid_attestationcase,
                        in: 'query'
                    },
                    {
                        name: 'uid_attestationhelper',
                        value: uid_attestationhelper,
                        in: 'query'
                    },
                    {
                        name: 'forinquiry',
                        value: forinquiry,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'attestationtype',
                        value: attestationtype,
                        in: 'query'
                    },
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        in: 'query'
                    },
                    {
                        name: 'type',
                        value: type,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_approve_put = function (inputParameterName) {
            return {
                path: '/portal/attestation/approve',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_approve_losspreview_get = function (uid_case) {
            return {
                path: '/portal/attestation/approve/{uid_case}/losspreview',
                parameters: [
                    {
                        name: 'uid_case',
                        value: uid_case,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_approve_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/attestation/approve/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_approve_datamodel_get = function (Escalation, objecttable, filter) {
            return {
                path: '/portal/attestation/approve/datamodel',
                parameters: [
                    {
                        name: 'Escalation',
                        value: Escalation,
                        in: 'query'
                    },
                    {
                        name: 'objecttable',
                        value: objecttable,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_approve_group_get = function (by, def, filter, StartIndex, PageSize, withcount, attestationtype, uidpolicy, type, risk, Escalation) {
            return {
                path: '/portal/attestation/approve/group',
                parameters: [
                    {
                        name: 'by',
                        value: by,
                        in: 'query'
                    },
                    {
                        name: 'def',
                        value: def,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'withcount',
                        value: withcount,
                        in: 'query'
                    },
                    {
                        name: 'attestationtype',
                        value: attestationtype,
                        in: 'query'
                    },
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        in: 'query'
                    },
                    {
                        name: 'type',
                        value: type,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                    {
                        name: 'Escalation',
                        value: Escalation,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_approve_parameter_candidates_post = function (name, parenttable, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName) {
            return {
                path: '/portal/attestation/approve/parameter/{name}/candidates/{parenttable}',
                parameters: [
                    {
                        name: 'name',
                        value: name,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'parenttable',
                        value: parenttable,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_approve_parameter_candidates_filtertree_post = function (name, parenttable, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/attestation/approve/parameter/{name}/candidates/{parenttable}/filtertree',
                parameters: [
                    {
                        name: 'name',
                        value: name,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'parenttable',
                        value: parenttable,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_case_get = function (objecttable, objectuid, uid_persondecision, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, attestationtype, uidpolicy, type, risk) {
            return {
                path: '/portal/attestation/case',
                parameters: [
                    {
                        name: 'objecttable',
                        value: objecttable,
                        in: 'query'
                    },
                    {
                        name: 'objectuid',
                        value: objectuid,
                        in: 'query'
                    },
                    {
                        name: 'uid_persondecision',
                        value: uid_persondecision,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'state',
                        value: state,
                        in: 'query'
                    },
                    {
                        name: 'attestationtype',
                        value: attestationtype,
                        in: 'query'
                    },
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        in: 'query'
                    },
                    {
                        name: 'type',
                        value: type,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_case_datamodel_get = function (objecttable, objectuid, filter) {
            return {
                path: '/portal/attestation/case/datamodel',
                parameters: [
                    {
                        name: 'objecttable',
                        value: objecttable,
                        in: 'query'
                    },
                    {
                        name: 'objectuid',
                        value: objectuid,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_case_group_get = function (by, def, filter, StartIndex, PageSize, withcount, state, attestationtype, uidpolicy, type, risk, objecttable, objectuid) {
            return {
                path: '/portal/attestation/case/group',
                parameters: [
                    {
                        name: 'by',
                        value: by,
                        in: 'query'
                    },
                    {
                        name: 'def',
                        value: def,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'withcount',
                        value: withcount,
                        in: 'query'
                    },
                    {
                        name: 'state',
                        value: state,
                        in: 'query'
                    },
                    {
                        name: 'attestationtype',
                        value: attestationtype,
                        in: 'query'
                    },
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        in: 'query'
                    },
                    {
                        name: 'type',
                        value: type,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                    {
                        name: 'objecttable',
                        value: objecttable,
                        in: 'query'
                    },
                    {
                        name: 'objectuid',
                        value: objectuid,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_case_history_get = function (uidcase, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/attestation/case/history/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_case_parameter_candidates_post = function (name, parenttable, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName) {
            return {
                path: '/portal/attestation/case/parameter/{name}/candidates/{parenttable}',
                parameters: [
                    {
                        name: 'name',
                        value: name,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'parenttable',
                        value: parenttable,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_case_parameter_candidates_filtertree_post = function (name, parenttable, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/attestation/case/parameter/{name}/candidates/{parenttable}/filtertree',
                parameters: [
                    {
                        name: 'name',
                        value: name,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'parenttable',
                        value: parenttable,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_config_get = function () {
            return {
                path: '/portal/attestation/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_decide_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/decide/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_denydecision_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/denydecision/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_directdecision_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/directdecision/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_escalate_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/escalate/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_filter_candidates_get = function (uidattestationparm, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/attestation/filter/candidates/{uidattestationparm}',
                parameters: [
                    {
                        name: 'uidattestationparm',
                        value: uidattestationparm,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_filter_matchingobjects_get = function (policyfilter, uidpickcategory, uidattestationobject, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/attestation/filter/matchingobjects/{uidattestationobject}',
                parameters: [
                    {
                        name: 'policyfilter',
                        value: policyfilter,
                        in: 'query'
                    },
                    {
                        name: 'uidpickcategory',
                        value: uidpickcategory,
                        in: 'query'
                    },
                    {
                        name: 'uidattestationobject',
                        value: uidattestationobject,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_filter_model_get = function (uidobject) {
            return {
                path: '/portal/attestation/filter/model/{uidobject}',
                parameters: [
                    {
                        name: 'uidobject',
                        value: uidobject,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_insteadof_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/insteadof/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_managerattestation_post = function () {
            return {
                path: '/portal/attestation/managerattestation',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_object_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/attestation/object',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_persondecision_get = function (uidattestationcase) {
            return {
                path: '/portal/attestation/persondecision/{uidattestationcase}',
                parameters: [
                    {
                        name: 'uidattestationcase',
                        value: uidattestationcase,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, OnlyActivePolicies, ScheduleType, mypolicies) {
            return {
                path: '/portal/attestation/policy',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'OnlyActivePolicies',
                        value: OnlyActivePolicies,
                        in: 'query'
                    },
                    {
                        name: 'ScheduleType',
                        value: ScheduleType,
                        in: 'query'
                    },
                    {
                        name: 'mypolicies',
                        value: mypolicies,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_report_get = function (uidpolicy, uidrun) {
            return {
                path: '/portal/attestation/policy/{uidpolicy}/{uidrun}/report',
                parameters: [
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidrun',
                        value: uidrun,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_reportbypolicy_get = function (uidpolicy) {
            return {
                path: '/portal/attestation/policy/{uidpolicy}/report',
                parameters: [
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_run_post = function (uidpolicy, inputParameterName) {
            return {
                path: '/portal/attestation/policy/{uidpolicy}/run',
                parameters: [
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_datamodel_get = function (filter) {
            return {
                path: '/portal/attestation/policy/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, mypolicies) {
            return {
                path: '/portal/attestation/policy/edit',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'mypolicies',
                        value: mypolicies,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_delete = function (UID_AttestationPolicy) {
            return {
                path: '/portal/attestation/policy/edit/{UID_AttestationPolicy}',
                parameters: [
                    {
                        name: 'UID_AttestationPolicy',
                        value: UID_AttestationPolicy,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_datamodel_get = function (filter) {
            return {
                path: '/portal/attestation/policy/edit/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_get = function () {
            return {
                path: '/portal/attestation/policy/edit/interactive',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/attestation/policy/edit/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_delete = function (inputParameterName) {
            return {
                path: '/portal/attestation/policy/edit/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_byid_get = function (UID_AttestationPolicy) {
            return {
                path: '/portal/attestation/policy/edit/interactive/{UID_AttestationPolicy}',
                parameters: [
                    {
                        name: 'UID_AttestationPolicy',
                        value: UID_AttestationPolicy,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_AttestationObject/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_datamodel_get = function (filter) {
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_AttestationObject/candidates/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_AttestationObject/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_DialogSchedule/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_DialogSchedule/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_post = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName) {
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_PWODecisionMethod/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_PWODecisionMethod/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_post = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName) {
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_QERPickCategory/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_QERPickCategory/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policy_group_get = function (by, def, filter, StartIndex, PageSize, withcount, OnlyActivePolicies, ScheduleType, mypolicies) {
            return {
                path: '/portal/attestation/policy/group',
                parameters: [
                    {
                        name: 'by',
                        value: by,
                        in: 'query'
                    },
                    {
                        name: 'def',
                        value: def,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'withcount',
                        value: withcount,
                        in: 'query'
                    },
                    {
                        name: 'OnlyActivePolicies',
                        value: OnlyActivePolicies,
                        in: 'query'
                    },
                    {
                        name: 'ScheduleType',
                        value: ScheduleType,
                        in: 'query'
                    },
                    {
                        name: 'mypolicies',
                        value: mypolicies,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policygroups_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/attestation/policygroups',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policygroups_delete = function (UID_AttestationPolicyGroup) {
            return {
                path: '/portal/attestation/policygroups/{UID_AttestationPolicyGroup}',
                parameters: [
                    {
                        name: 'UID_AttestationPolicyGroup',
                        value: UID_AttestationPolicyGroup,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_get = function () {
            return {
                path: '/portal/attestation/policygroups/interactive',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/attestation/policygroups/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_delete = function (inputParameterName) {
            return {
                path: '/portal/attestation/policygroups/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_byid_get = function (UID_AttestationPolicyGroup) {
            return {
                path: '/portal/attestation/policygroups/interactive/{UID_AttestationPolicyGroup}',
                parameters: [
                    {
                        name: 'UID_AttestationPolicyGroup',
                        value: UID_AttestationPolicyGroup,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/attestation/policygroups/interactive/UID_DialogSchedule/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/attestation/policygroups/interactive/UID_DialogSchedule/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_post = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName) {
            return {
                path: '/portal/attestation/policygroups/interactive/UID_QERPickCategory/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/attestation/policygroups/interactive/UID_QERPickCategory/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_query_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/query/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_recalldecision_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/recalldecision/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_recallquery_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/recallquery/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_report_get = function (uidcase) {
            return {
                path: '/portal/attestation/report/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'blob'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_resetreservation_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/resetreservation/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_revokeadditional_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/revokeadditional/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_revokedelegation_post = function (uidcase, inputParameterName) {
            return {
                path: '/portal/attestation/revokedelegation/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_run_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, withpendingcases) {
            return {
                path: '/portal/attestation/run',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'withpendingcases',
                        value: withpendingcases,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_run_approvers_get = function (uidrun) {
            return {
                path: '/portal/attestation/run/{uidrun}/approvers',
                parameters: [
                    {
                        name: 'uidrun',
                        value: uidrun,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_run_extend_post = function (uidrun, inputParameterName) {
            return {
                path: '/portal/attestation/run/{uidrun}/extend',
                parameters: [
                    {
                        name: 'uidrun',
                        value: uidrun,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_run_datamodel_get = function (filter) {
            return {
                path: '/portal/attestation/run/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_run_group_get = function (by, def, filter, StartIndex, PageSize, withcount, withpendingcases) {
            return {
                path: '/portal/attestation/run/group',
                parameters: [
                    {
                        name: 'by',
                        value: by,
                        in: 'query'
                    },
                    {
                        name: 'def',
                        value: def,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'withcount',
                        value: withcount,
                        in: 'query'
                    },
                    {
                        name: 'withpendingcases',
                        value: withpendingcases,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_run_sendreminder_post = function (inputParameterName) {
            return {
                path: '/portal/attestation/run/sendreminder',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_schedules_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/attestation/schedules',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_schedules_put = function (inputParameterName) {
            return {
                path: '/portal/attestation/schedules',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_schedules_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/attestation/schedules/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_snapshot_get = function (uidcase) {
            return {
                path: '/portal/attestation/snapshot/{uidcase}',
                parameters: [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_stepup_post = function (inputParameterName) {
            return {
                path: '/portal/attestation/stepup',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_userconfig_get = function () {
            return {
                path: '/portal/attestation/userconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_attestation_workflow_get = function (uidattestationcase, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/attestation/workflow/{uidattestationcase}',
                parameters: [
                    {
                        name: 'uidattestationcase',
                        value: uidattestationcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_AERole_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/candidates/AERole',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_AERole_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/AERole/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_AttestationPolicyGroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/candidates/AttestationPolicyGroup',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_AttestationPolicyGroup_datamodel_get = function (filter) {
            return {
                path: '/portal/candidates/AttestationPolicyGroup/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_AttestationPolicyGroup_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/AttestationPolicyGroup/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_ComplianceArea_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/candidates/ComplianceArea',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_ComplianceArea_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/ComplianceArea/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_DialogTimeZone_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/candidates/DialogTimeZone',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_DialogTimeZone_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/DialogTimeZone/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/candidates/MitigatingControl',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/MitigatingControl/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_Person_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/candidates/Person',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_Person_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/Person/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_QBMCulture_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/candidates/QBMCulture',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_QBMCulture_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/QBMCulture/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_QERTermsOfUse_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/candidates/QERTermsOfUse',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_QERTermsOfUse_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/QERTermsOfUse/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_claimdevice_post = function (uidperson, uiddevice) {
            return {
                path: '/portal/claimdevice/{uidperson}/{uiddevice}',
                parameters: [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uiddevice',
                        value: uiddevice,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_claimdevice_devices_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/claimdevice/devices',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_config_get = function () {
            return {
                path: '/portal/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_featureconfig_get = function () {
            return {
                path: '/portal/featureconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.register_config_get = function () {
            return {
                path: '/register/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.register_featureconfig_get = function () {
            return {
                path: '/register/featureconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.register_person_post = function (inputParameterName) {
            return {
                path: '/register/person',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        Client.prototype.admin_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_config_get(), requestOptions);
        };
        Client.prototype.admin_config_post = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_config_post(inputParameterName), requestOptions);
        };
        Client.prototype.imx_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_config_get(), requestOptions);
        };
        /** Returns a list of candidate objects from the table DialogTimeZone. */
        Client.prototype.opsupport_candidates_DialogTimeZone_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_candidates_DialogTimeZone_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the candidates/DialogTimeZone endpoint. */
        Client.prototype.opsupport_candidates_DialogTimeZone_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_candidates_DialogTimeZone_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.opsupport_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_config_get(), requestOptions);
        };
        Client.prototype.opsupport_featureconfig_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_featureconfig_get(), requestOptions);
        };
        Client.prototype.passwordreset_activation_confirm_post = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_activation_confirm_post(inputParameterName), requestOptions);
        };
        Client.prototype.passwordreset_activation_init_post = function (uidcase, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_activation_init_post(uidcase), requestOptions);
        };
        Client.prototype.passwordreset_activation_resendemail_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_activation_resendemail_post(), requestOptions);
        };
        /** Returns a list of candidate objects from the table DialogTimeZone. */
        Client.prototype.passwordreset_candidates_DialogTimeZone_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_candidates_DialogTimeZone_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the candidates/DialogTimeZone endpoint. */
        Client.prototype.passwordreset_candidates_DialogTimeZone_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_candidates_DialogTimeZone_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.passwordreset_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_config_get(), requestOptions);
        };
        Client.prototype.portal_attestation_additional_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_additional_post(uidcase, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_answerquery_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_answerquery_post(uidcase, inputParameterName), requestOptions);
        };
        /** Returns attestation cases which the current user can decide. */
        Client.prototype.portal_attestation_approve_get = function (Escalation, objecttable, objectuid, uid_attestationcase, uid_attestationhelper, forinquiry, OrderBy, StartIndex, PageSize, filter, withProperties, search, attestationtype, uidpolicy, type, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_get(Escalation, objecttable, objectuid, uid_attestationcase, uid_attestationhelper, forinquiry, OrderBy, StartIndex, PageSize, filter, withProperties, search, attestationtype, uidpolicy, type, risk), requestOptions);
        };
        /** Returns attestation cases which the current user can decide. */
        Client.prototype.portal_attestation_approve_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_put(inputParameterName), requestOptions);
        };
        /** Returns the entitlements that a user will lose if the specified attestation case is denied. */
        Client.prototype.portal_attestation_approve_losspreview_get = function (uid_case, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_losspreview_get(uid_case), requestOptions);
        };
        /** Returns attestation cases which the current user can decide. */
        Client.prototype.portal_attestation_approve_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the attestation/approve endpoint. */
        Client.prototype.portal_attestation_approve_datamodel_get = function (Escalation, objecttable, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_datamodel_get(Escalation, objecttable, filter), requestOptions);
        };
        /** Returns attestation cases which the current user can decide. */
        Client.prototype.portal_attestation_approve_group_get = function (by, def, filter, StartIndex, PageSize, withcount, attestationtype, uidpolicy, type, risk, Escalation, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_group_get(by, def, filter, StartIndex, PageSize, withcount, attestationtype, uidpolicy, type, risk, Escalation), requestOptions);
        };
        /** Returns a list of objects that can be assigned as a parameter value. */
        Client.prototype.portal_attestation_approve_parameter_candidates_post = function (name, parenttable, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_parameter_candidates_post(name, parenttable, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName), requestOptions);
        };
        /** Returns filter tree information for the attestation/approve/parameter/{name}/candidates/{parenttable} endpoint. */
        Client.prototype.portal_attestation_approve_parameter_candidates_filtertree_post = function (name, parenttable, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_parameter_candidates_filtertree_post(name, parenttable, filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_case_get = function (objecttable, objectuid, uid_persondecision, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, attestationtype, uidpolicy, type, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_get(objecttable, objectuid, uid_persondecision, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, attestationtype, uidpolicy, type, risk), requestOptions);
        };
        /** Returns data model information about query options for the attestation/case endpoint. */
        Client.prototype.portal_attestation_case_datamodel_get = function (objecttable, objectuid, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_datamodel_get(objecttable, objectuid, filter), requestOptions);
        };
        Client.prototype.portal_attestation_case_group_get = function (by, def, filter, StartIndex, PageSize, withcount, state, attestationtype, uidpolicy, type, risk, objecttable, objectuid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_group_get(by, def, filter, StartIndex, PageSize, withcount, state, attestationtype, uidpolicy, type, risk, objecttable, objectuid), requestOptions);
        };
        /** Returns the workflow history for the specified attestation case. */
        Client.prototype.portal_attestation_case_history_get = function (uidcase, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_history_get(uidcase, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns a list of objects that can be assigned as a parameter value. */
        Client.prototype.portal_attestation_case_parameter_candidates_post = function (name, parenttable, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_parameter_candidates_post(name, parenttable, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName), requestOptions);
        };
        /** Returns filter tree information for the attestation/case/parameter/{name}/candidates/{parenttable} endpoint. */
        Client.prototype.portal_attestation_case_parameter_candidates_filtertree_post = function (name, parenttable, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_parameter_candidates_filtertree_post(name, parenttable, filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_config_get(), requestOptions);
        };
        Client.prototype.portal_attestation_decide_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_decide_post(uidcase, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_denydecision_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_denydecision_post(uidcase, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_directdecision_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_directdecision_post(uidcase, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_escalate_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_escalate_post(uidcase, inputParameterName), requestOptions);
        };
        /** Returns candidate objects for a filter definition. */
        Client.prototype.portal_attestation_filter_candidates_get = function (uidattestationparm, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_filter_candidates_get(uidattestationparm, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        /** Returns objects matching the filter. */
        Client.prototype.portal_attestation_filter_matchingobjects_get = function (policyfilter, uidpickcategory, uidattestationobject, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_filter_matchingobjects_get(policyfilter, uidpickcategory, uidattestationobject, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        /** Returns configuration information for the specified parameter object. */
        Client.prototype.portal_attestation_filter_model_get = function (uidobject, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_filter_model_get(uidobject), requestOptions);
        };
        Client.prototype.portal_attestation_insteadof_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_insteadof_post(uidcase, inputParameterName), requestOptions);
        };
        /** Starts the attestation policy to define missing manager assignments for identities. The attestation cases are created asynchronously. */
        Client.prototype.portal_attestation_managerattestation_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_managerattestation_post(), requestOptions);
        };
        Client.prototype.portal_attestation_object_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_object_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns identities allowed to make approvals for the specified attestation case. */
        Client.prototype.portal_attestation_persondecision_get = function (uidattestationcase, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_persondecision_get(uidattestationcase), requestOptions);
        };
        Client.prototype.portal_attestation_policy_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, OnlyActivePolicies, ScheduleType, mypolicies, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, OnlyActivePolicies, ScheduleType, mypolicies), requestOptions);
        };
        /** Creates a report containing information about the attestation run and its progress. */
        Client.prototype.portal_attestation_policy_report_get = function (uidpolicy, uidrun, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_report_get(uidpolicy, uidrun), requestOptions);
        };
        /** Creates a report containing information about the attestation policy and its progress. */
        Client.prototype.portal_attestation_policy_reportbypolicy_get = function (uidpolicy, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_reportbypolicy_get(uidpolicy), requestOptions);
        };
        /** Creates attestation cases for the specified policy and objects */
        Client.prototype.portal_attestation_policy_run_post = function (uidpolicy, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_run_post(uidpolicy, inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the attestation/policy endpoint. */
        Client.prototype.portal_attestation_policy_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_attestation_policy_edit_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, mypolicies, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, mypolicies), requestOptions);
        };
        Client.prototype.portal_attestation_policy_edit_delete = function (UID_AttestationPolicy, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_delete(UID_AttestationPolicy), requestOptions);
        };
        /** Returns data model information about query options for the attestation/policy/edit endpoint. */
        Client.prototype.portal_attestation_policy_edit_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_attestation_policy_edit_interactive_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_get(), requestOptions);
        };
        Client.prototype.portal_attestation_policy_edit_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_policy_edit_interactive_delete = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_delete(inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_policy_edit_interactive_byid_get = function (UID_AttestationPolicy, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_byid_get(UID_AttestationPolicy), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_AttestationObject. */
        Client.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the attestation/policy/edit/interactive/UID_AttestationObject/candidates endpoint. */
        Client.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_datamodel_get(filter), requestOptions);
        };
        /** Returns filter tree information for the attestation/policy/edit/interactive/UID_AttestationObject/candidates endpoint. */
        Client.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
        Client.prototype.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the attestation/policy/edit/interactive/UID_DialogSchedule/candidates endpoint. */
        Client.prototype.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
        Client.prototype.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_post = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_post(OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName), requestOptions);
        };
        /** Returns filter tree information for the attestation/policy/edit/interactive/UID_PWODecisionMethod/candidates endpoint. */
        Client.prototype.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_QERPickCategory. */
        Client.prototype.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_post = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_post(OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName), requestOptions);
        };
        /** Returns filter tree information for the attestation/policy/edit/interactive/UID_QERPickCategory/candidates endpoint. */
        Client.prototype.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_policy_group_get = function (by, def, filter, StartIndex, PageSize, withcount, OnlyActivePolicies, ScheduleType, mypolicies, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_group_get(by, def, filter, StartIndex, PageSize, withcount, OnlyActivePolicies, ScheduleType, mypolicies), requestOptions);
        };
        Client.prototype.portal_attestation_policygroups_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_attestation_policygroups_delete = function (UID_AttestationPolicyGroup, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_delete(UID_AttestationPolicyGroup), requestOptions);
        };
        Client.prototype.portal_attestation_policygroups_interactive_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_get(), requestOptions);
        };
        Client.prototype.portal_attestation_policygroups_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_policygroups_interactive_delete = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_delete(inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_policygroups_interactive_byid_get = function (UID_AttestationPolicyGroup, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_byid_get(UID_AttestationPolicyGroup), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
        Client.prototype.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the attestation/policygroups/interactive/UID_DialogSchedule/candidates endpoint. */
        Client.prototype.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_QERPickCategory. */
        Client.prototype.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_post = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_post(OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName), requestOptions);
        };
        /** Returns filter tree information for the attestation/policygroups/interactive/UID_QERPickCategory/candidates endpoint. */
        Client.prototype.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_query_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_query_post(uidcase, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_recalldecision_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_recalldecision_post(uidcase, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_recallquery_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_recallquery_post(uidcase, inputParameterName), requestOptions);
        };
        /** Returns the PDF file associated with the specified attestation case. */
        Client.prototype.portal_attestation_report_get = function (uidcase, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_report_get(uidcase), requestOptions);
        };
        Client.prototype.portal_attestation_resetreservation_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_resetreservation_post(uidcase, inputParameterName), requestOptions);
        };
        /** Removes a previously added additional approver. */
        Client.prototype.portal_attestation_revokeadditional_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_revokeadditional_post(uidcase, inputParameterName), requestOptions);
        };
        /** Revokes an approval delegation. */
        Client.prototype.portal_attestation_revokedelegation_post = function (uidcase, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_revokedelegation_post(uidcase, inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_run_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, withpendingcases, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, withpendingcases), requestOptions);
        };
        Client.prototype.portal_attestation_run_approvers_get = function (uidrun, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_approvers_get(uidrun), requestOptions);
        };
        Client.prototype.portal_attestation_run_extend_post = function (uidrun, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_extend_post(uidrun, inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the attestation/run endpoint. */
        Client.prototype.portal_attestation_run_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_attestation_run_group_get = function (by, def, filter, StartIndex, PageSize, withcount, withpendingcases, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_group_get(by, def, filter, StartIndex, PageSize, withcount, withpendingcases), requestOptions);
        };
        Client.prototype.portal_attestation_run_sendreminder_post = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_sendreminder_post(inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_schedules_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_schedules_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_attestation_schedules_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_schedules_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_schedules_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_schedules_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns the object state snapshot associated with the specified attestation case. */
        Client.prototype.portal_attestation_snapshot_get = function (uidcase, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_snapshot_get(uidcase), requestOptions);
        };
        /** Initiates step-up authentication for the specified request. */
        Client.prototype.portal_attestation_stepup_post = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_stepup_post(inputParameterName), requestOptions);
        };
        Client.prototype.portal_attestation_userconfig_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_userconfig_get(), requestOptions);
        };
        Client.prototype.portal_attestation_workflow_get = function (uidattestationcase, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_workflow_get(uidattestationcase, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns a list of candidate objects from the table AERole. */
        Client.prototype.portal_candidates_AERole_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AERole_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        /** Returns filter tree information for the candidates/AERole endpoint. */
        Client.prototype.portal_candidates_AERole_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AERole_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of candidate objects from the table AttestationPolicyGroup. */
        Client.prototype.portal_candidates_AttestationPolicyGroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AttestationPolicyGroup_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the candidates/AttestationPolicyGroup endpoint. */
        Client.prototype.portal_candidates_AttestationPolicyGroup_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AttestationPolicyGroup_datamodel_get(filter), requestOptions);
        };
        /** Returns filter tree information for the candidates/AttestationPolicyGroup endpoint. */
        Client.prototype.portal_candidates_AttestationPolicyGroup_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AttestationPolicyGroup_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of candidate objects from the table ComplianceArea. */
        Client.prototype.portal_candidates_ComplianceArea_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_ComplianceArea_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        /** Returns filter tree information for the candidates/ComplianceArea endpoint. */
        Client.prototype.portal_candidates_ComplianceArea_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_ComplianceArea_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of candidate objects from the table DialogTimeZone. */
        Client.prototype.portal_candidates_DialogTimeZone_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_DialogTimeZone_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the candidates/DialogTimeZone endpoint. */
        Client.prototype.portal_candidates_DialogTimeZone_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_DialogTimeZone_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of candidate objects from the table MitigatingControl. */
        Client.prototype.portal_candidates_MitigatingControl_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
        Client.prototype.portal_candidates_MitigatingControl_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of candidate objects from the table Person. */
        Client.prototype.portal_candidates_Person_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the candidates/Person endpoint. */
        Client.prototype.portal_candidates_Person_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of candidate objects from the table QBMCulture. */
        Client.prototype.portal_candidates_QBMCulture_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_QBMCulture_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the candidates/QBMCulture endpoint. */
        Client.prototype.portal_candidates_QBMCulture_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_QBMCulture_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of candidate objects from the table QERTermsOfUse. */
        Client.prototype.portal_candidates_QERTermsOfUse_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERTermsOfUse_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the candidates/QERTermsOfUse endpoint. */
        Client.prototype.portal_candidates_QERTermsOfUse_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERTermsOfUse_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Triggers an ownership attestation for the specified device. */
        Client.prototype.portal_claimdevice_post = function (uidperson, uiddevice, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimdevice_post(uidperson, uiddevice), requestOptions);
        };
        /** Returns the list of devices for which the user can trigger an ownership attestation. */
        Client.prototype.portal_claimdevice_devices_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimdevice_devices_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        Client.prototype.portal_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_config_get(), requestOptions);
        };
        Client.prototype.portal_featureconfig_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_featureconfig_get(), requestOptions);
        };
        Client.prototype.register_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.register_config_get(), requestOptions);
        };
        Client.prototype.register_featureconfig_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.register_featureconfig_get(), requestOptions);
        };
        Client.prototype.register_person_post = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.register_person_post(inputParameterName), requestOptions);
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.admin_config_get = function (options, requestOptions) {
            return {
                path: '/admin/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_config_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/config',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_config_get = function (options, requestOptions) {
            return {
                path: '/imx/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_candidates_DialogTimeZone_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/candidates/DialogTimeZone',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_candidates_DialogTimeZone_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/candidates/DialogTimeZone/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_config_get = function (options, requestOptions) {
            return {
                path: '/opsupport/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_featureconfig_get = function (options, requestOptions) {
            return {
                path: '/opsupport/featureconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.passwordreset_activation_confirm_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/passwordreset/activation/confirm',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.passwordreset_activation_init_post = function (/** Unique identifier of the attestation case */ uidcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/passwordreset/activation/init/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.passwordreset_activation_resendemail_post = function (options, requestOptions) {
            return {
                path: '/passwordreset/activation/resendemail',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.passwordreset_candidates_DialogTimeZone_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/passwordreset/candidates/DialogTimeZone',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.passwordreset_candidates_DialogTimeZone_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/passwordreset/candidates/DialogTimeZone/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.passwordreset_config_get = function (options, requestOptions) {
            return {
                path: '/passwordreset/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_additional_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/additional/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_answerquery_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/answerquery/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_approve_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/approve',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_approve_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/approve',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_approve_losspreview_get = function (/** Comma-separated list of unique attestation case identifiers */ uid_case, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/approve/{uid_case}/losspreview',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid_case',
                        value: uid_case,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_approve_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/approve/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_approve_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/approve/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_approve_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/approve/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_approve_parameter_candidates_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/approve/parameter/{name}/candidates/{parenttable}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'name',
                        value: name,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'parenttable',
                        value: parenttable,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_approve_parameter_candidates_filtertree_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/approve/parameter/{name}/candidates/{parenttable}/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'name',
                        value: name,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'parenttable',
                        value: parenttable,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_case_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/case',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_case_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/case/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_case_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/case/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_case_history_get = function (/** Unique attestation case identifier */ uidcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/case/history/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_case_parameter_candidates_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/case/parameter/{name}/candidates/{parenttable}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'name',
                        value: name,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'parenttable',
                        value: parenttable,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_case_parameter_candidates_filtertree_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/case/parameter/{name}/candidates/{parenttable}/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'name',
                        value: name,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'parenttable',
                        value: parenttable,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_config_get = function (options, requestOptions) {
            return {
                path: '/portal/attestation/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_decide_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/decide/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_denydecision_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/denydecision/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_directdecision_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/directdecision/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_escalate_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/escalate/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_filter_candidates_get = function (/** Unique attestation parameter identifier */ uidattestationparm, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/filter/candidates/{uidattestationparm}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidattestationparm',
                        value: uidattestationparm,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_filter_matchingobjects_get = function (/** Unique attestation procedure identifier */ uidattestationobject, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/filter/matchingobjects/{uidattestationobject}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidattestationobject',
                        value: uidattestationobject,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_filter_model_get = function (/** Unique identifier of the attestation object */ uidobject, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/filter/model/{uidobject}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidobject',
                        value: uidobject,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_insteadof_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/insteadof/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_managerattestation_post = function (options, requestOptions) {
            return {
                path: '/portal/attestation/managerattestation',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_object_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/object',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_persondecision_get = function (/** Unique request identifier */ uidattestationcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/persondecision/{uidattestationcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidattestationcase',
                        value: uidattestationcase,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_report_get = function (/** Unique policy identifier */ uidpolicy, /** Unique attestation run identifier */ uidrun, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/{uidpolicy}/{uidrun}/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidrun',
                        value: uidrun,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_reportbypolicy_get = function (/** Unique policy identifier */ uidpolicy, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/{uidpolicy}/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_run_post = function (/** Unique policy identifier */ uidpolicy, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/{uidpolicy}/run',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidpolicy',
                        value: uidpolicy,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_delete = function (/** Attestation policy */ UID_AttestationPolicy, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/{UID_AttestationPolicy}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AttestationPolicy',
                        value: UID_AttestationPolicy,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_get = function (options, requestOptions) {
            return {
                path: '/portal/attestation/policy/edit/interactive',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_delete = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_byid_get = function (/** Primary key value UID_AttestationPolicy */ UID_AttestationPolicy, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive/{UID_AttestationPolicy}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AttestationPolicy',
                        value: UID_AttestationPolicy,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_AttestationObject/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_AttestationObject/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_AttestationObject/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_DialogSchedule/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_DialogSchedule/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_PWODecisionMethod/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_PWODecisionMethod/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_QERPickCategory/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/edit/interactive/UID_QERPickCategory/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policy_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policy/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policygroups_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policygroups',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policygroups_delete = function (/** Policy collection */ UID_AttestationPolicyGroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policygroups/{UID_AttestationPolicyGroup}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AttestationPolicyGroup',
                        value: UID_AttestationPolicyGroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_get = function (options, requestOptions) {
            return {
                path: '/portal/attestation/policygroups/interactive',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policygroups/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_delete = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policygroups/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_byid_get = function (/** Primary key value UID_AttestationPolicyGroup */ UID_AttestationPolicyGroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policygroups/interactive/{UID_AttestationPolicyGroup}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AttestationPolicyGroup',
                        value: UID_AttestationPolicyGroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policygroups/interactive/UID_DialogSchedule/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policygroups/interactive/UID_DialogSchedule/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policygroups/interactive/UID_QERPickCategory/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/policygroups/interactive/UID_QERPickCategory/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_query_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/query/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_recalldecision_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/recalldecision/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_recallquery_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/recallquery/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_report_get = function (uidcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/report/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'blob'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_resetreservation_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/resetreservation/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_revokeadditional_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/revokeadditional/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_revokedelegation_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/revokedelegation/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_run_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/run',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_run_approvers_get = function (/** Unique identifier of the attestation run */ uidrun, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/run/{uidrun}/approvers',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidrun',
                        value: uidrun,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_run_extend_post = function (uidrun, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/run/{uidrun}/extend',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidrun',
                        value: uidrun,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_run_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/run/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_run_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/run/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_run_sendreminder_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/run/sendreminder',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_schedules_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/schedules',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_schedules_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/schedules',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_schedules_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/schedules/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_snapshot_get = function (uidcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/snapshot/{uidcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcase',
                        value: uidcase,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_stepup_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/stepup',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_userconfig_get = function (options, requestOptions) {
            return {
                path: '/portal/attestation/userconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_attestation_workflow_get = function (/** Unique attestation case identifier */ uidattestationcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/attestation/workflow/{uidattestationcase}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidattestationcase',
                        value: uidattestationcase,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_AERole_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/AERole',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_AERole_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/AERole/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_AttestationPolicyGroup_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/AttestationPolicyGroup',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_AttestationPolicyGroup_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/AttestationPolicyGroup/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_AttestationPolicyGroup_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/AttestationPolicyGroup/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_ComplianceArea_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/ComplianceArea',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_ComplianceArea_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/ComplianceArea/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_DialogTimeZone_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/DialogTimeZone',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_DialogTimeZone_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/DialogTimeZone/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/MitigatingControl',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/MitigatingControl/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_Person_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/Person',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_Person_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/Person/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_QBMCulture_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/QBMCulture',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_QBMCulture_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/QBMCulture/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_QERTermsOfUse_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/QERTermsOfUse',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_QERTermsOfUse_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/QERTermsOfUse/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_claimdevice_post = function (/** Identity claiming the ownership */ uidperson, /** Identifier of the device */ uiddevice, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/claimdevice/{uidperson}/{uiddevice}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uiddevice',
                        value: uiddevice,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_claimdevice_devices_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/claimdevice/devices',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_config_get = function (options, requestOptions) {
            return {
                path: '/portal/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_featureconfig_get = function (options, requestOptions) {
            return {
                path: '/portal/featureconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.register_config_get = function (options, requestOptions) {
            return {
                path: '/register/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.register_featureconfig_get = function (options, requestOptions) {
            return {
                path: '/register/featureconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.register_person_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/register/person',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        V2Client.prototype.admin_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_config_get(options), requestOptions);
        };
        V2Client.prototype.admin_config_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_config_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.imx_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_config_get(options), requestOptions);
        };
        /** Returns a list of candidate objects from the table DialogTimeZone. */
        V2Client.prototype.opsupport_candidates_DialogTimeZone_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_candidates_DialogTimeZone_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/DialogTimeZone endpoint. */
        V2Client.prototype.opsupport_candidates_DialogTimeZone_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_candidates_DialogTimeZone_filtertree_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.opsupport_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_config_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_featureconfig_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_featureconfig_get(options), requestOptions);
        };
        V2Client.prototype.passwordreset_activation_confirm_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_activation_confirm_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.passwordreset_activation_init_post = function (/** Unique identifier of the attestation case */ uidcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_activation_init_post(uidcase, options), requestOptions);
        };
        V2Client.prototype.passwordreset_activation_resendemail_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_activation_resendemail_post(options), requestOptions);
        };
        /** Returns a list of candidate objects from the table DialogTimeZone. */
        V2Client.prototype.passwordreset_candidates_DialogTimeZone_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_candidates_DialogTimeZone_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/DialogTimeZone endpoint. */
        V2Client.prototype.passwordreset_candidates_DialogTimeZone_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_candidates_DialogTimeZone_filtertree_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.passwordreset_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.passwordreset_config_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_additional_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_additional_post(uidcase, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_answerquery_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_answerquery_post(uidcase, inputParameterName, options), requestOptions);
        };
        /** Returns attestation cases which the current user can decide. */
        V2Client.prototype.portal_attestation_approve_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_get(options), requestOptions);
        };
        /** Returns attestation cases which the current user can decide. */
        V2Client.prototype.portal_attestation_approve_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_put(inputParameterName, options), requestOptions);
        };
        /** Returns the entitlements that a user will lose if the specified attestation case is denied. */
        V2Client.prototype.portal_attestation_approve_losspreview_get = function (/** Comma-separated list of unique attestation case identifiers */ uid_case, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_losspreview_get(uid_case, options), requestOptions);
        };
        /** Returns attestation cases which the current user can decide. */
        V2Client.prototype.portal_attestation_approve_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the attestation/approve endpoint. */
        V2Client.prototype.portal_attestation_approve_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_datamodel_get(options), requestOptions);
        };
        /** Returns attestation cases which the current user can decide. */
        V2Client.prototype.portal_attestation_approve_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_group_get(options), requestOptions);
        };
        /** Returns a list of objects that can be assigned as a parameter value. */
        V2Client.prototype.portal_attestation_approve_parameter_candidates_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_parameter_candidates_post(name, parenttable, inputParameterName, options), requestOptions);
        };
        /** Returns filter tree information for the attestation/approve/parameter/{name}/candidates/{parenttable} endpoint. */
        V2Client.prototype.portal_attestation_approve_parameter_candidates_filtertree_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_approve_parameter_candidates_filtertree_post(name, parenttable, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_case_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_get(options), requestOptions);
        };
        /** Returns data model information about query options for the attestation/case endpoint. */
        V2Client.prototype.portal_attestation_case_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_case_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_group_get(options), requestOptions);
        };
        /** Returns the workflow history for the specified attestation case. */
        V2Client.prototype.portal_attestation_case_history_get = function (/** Unique attestation case identifier */ uidcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_history_get(uidcase, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned as a parameter value. */
        V2Client.prototype.portal_attestation_case_parameter_candidates_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_parameter_candidates_post(name, parenttable, inputParameterName, options), requestOptions);
        };
        /** Returns filter tree information for the attestation/case/parameter/{name}/candidates/{parenttable} endpoint. */
        V2Client.prototype.portal_attestation_case_parameter_candidates_filtertree_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_case_parameter_candidates_filtertree_post(name, parenttable, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_config_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_decide_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_decide_post(uidcase, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_denydecision_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_denydecision_post(uidcase, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_directdecision_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_directdecision_post(uidcase, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_escalate_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_escalate_post(uidcase, inputParameterName, options), requestOptions);
        };
        /** Returns candidate objects for a filter definition. */
        V2Client.prototype.portal_attestation_filter_candidates_get = function (/** Unique attestation parameter identifier */ uidattestationparm, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_filter_candidates_get(uidattestationparm, options), requestOptions);
        };
        /** Returns objects matching the filter. */
        V2Client.prototype.portal_attestation_filter_matchingobjects_get = function (/** Unique attestation procedure identifier */ uidattestationobject, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_filter_matchingobjects_get(uidattestationobject, options), requestOptions);
        };
        /** Returns configuration information for the specified parameter object. */
        V2Client.prototype.portal_attestation_filter_model_get = function (/** Unique identifier of the attestation object */ uidobject, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_filter_model_get(uidobject, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_insteadof_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_insteadof_post(uidcase, inputParameterName, options), requestOptions);
        };
        /** Starts the attestation policy to define missing manager assignments for identities. The attestation cases are created asynchronously. */
        V2Client.prototype.portal_attestation_managerattestation_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_managerattestation_post(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_object_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_object_get(options), requestOptions);
        };
        /** Returns identities allowed to make approvals for the specified attestation case. */
        V2Client.prototype.portal_attestation_persondecision_get = function (/** Unique request identifier */ uidattestationcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_persondecision_get(uidattestationcase, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policy_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_get(options), requestOptions);
        };
        /** Creates a report containing information about the attestation run and its progress. */
        V2Client.prototype.portal_attestation_policy_report_get = function (/** Unique policy identifier */ uidpolicy, /** Unique attestation run identifier */ uidrun, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_report_get(uidpolicy, uidrun, options), requestOptions);
        };
        /** Creates a report containing information about the attestation policy and its progress. */
        V2Client.prototype.portal_attestation_policy_reportbypolicy_get = function (/** Unique policy identifier */ uidpolicy, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_reportbypolicy_get(uidpolicy, options), requestOptions);
        };
        /** Creates attestation cases for the specified policy and objects */
        V2Client.prototype.portal_attestation_policy_run_post = function (/** Unique policy identifier */ uidpolicy, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_run_post(uidpolicy, inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the attestation/policy endpoint. */
        V2Client.prototype.portal_attestation_policy_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policy_edit_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policy_edit_delete = function (/** Attestation policy */ UID_AttestationPolicy, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_delete(UID_AttestationPolicy, options), requestOptions);
        };
        /** Returns data model information about query options for the attestation/policy/edit endpoint. */
        V2Client.prototype.portal_attestation_policy_edit_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policy_edit_interactive_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policy_edit_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policy_edit_interactive_delete = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_delete(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policy_edit_interactive_byid_get = function (/** Primary key value UID_AttestationPolicy */ UID_AttestationPolicy, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_byid_get(UID_AttestationPolicy, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_AttestationObject. */
        V2Client.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_get(options), requestOptions);
        };
        /** Returns data model information about query options for the attestation/policy/edit/interactive/UID_AttestationObject/candidates endpoint. */
        V2Client.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_datamodel_get(options), requestOptions);
        };
        /** Returns filter tree information for the attestation/policy/edit/interactive/UID_AttestationObject/candidates endpoint. */
        V2Client.prototype.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_AttestationObject_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
        V2Client.prototype.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_get(options), requestOptions);
        };
        /** Returns filter tree information for the attestation/policy/edit/interactive/UID_DialogSchedule/candidates endpoint. */
        V2Client.prototype.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_DialogSchedule_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
        V2Client.prototype.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_post(inputParameterName, options), requestOptions);
        };
        /** Returns filter tree information for the attestation/policy/edit/interactive/UID_PWODecisionMethod/candidates endpoint. */
        V2Client.prototype.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_QERPickCategory. */
        V2Client.prototype.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_post(inputParameterName, options), requestOptions);
        };
        /** Returns filter tree information for the attestation/policy/edit/interactive/UID_QERPickCategory/candidates endpoint. */
        V2Client.prototype.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_edit_interactive_UID_QERPickCategory_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policy_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policy_group_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policygroups_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policygroups_delete = function (/** Policy collection */ UID_AttestationPolicyGroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_delete(UID_AttestationPolicyGroup, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policygroups_interactive_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policygroups_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policygroups_interactive_delete = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_delete(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_policygroups_interactive_byid_get = function (/** Primary key value UID_AttestationPolicyGroup */ UID_AttestationPolicyGroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_byid_get(UID_AttestationPolicyGroup, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
        V2Client.prototype.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_get(options), requestOptions);
        };
        /** Returns filter tree information for the attestation/policygroups/interactive/UID_DialogSchedule/candidates endpoint. */
        V2Client.prototype.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_UID_DialogSchedule_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_QERPickCategory. */
        V2Client.prototype.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_post(inputParameterName, options), requestOptions);
        };
        /** Returns filter tree information for the attestation/policygroups/interactive/UID_QERPickCategory/candidates endpoint. */
        V2Client.prototype.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_policygroups_interactive_UID_QERPickCategory_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_query_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_query_post(uidcase, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_recalldecision_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_recalldecision_post(uidcase, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_recallquery_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_recallquery_post(uidcase, inputParameterName, options), requestOptions);
        };
        /** Returns the PDF file associated with the specified attestation case. */
        V2Client.prototype.portal_attestation_report_get = function (uidcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_report_get(uidcase, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_resetreservation_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_resetreservation_post(uidcase, inputParameterName, options), requestOptions);
        };
        /** Removes a previously added additional approver. */
        V2Client.prototype.portal_attestation_revokeadditional_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_revokeadditional_post(uidcase, inputParameterName, options), requestOptions);
        };
        /** Revokes an approval delegation. */
        V2Client.prototype.portal_attestation_revokedelegation_post = function (/** Unique attestation case identifier */ uidcase, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_revokedelegation_post(uidcase, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_run_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_run_approvers_get = function (/** Unique identifier of the attestation run */ uidrun, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_approvers_get(uidrun, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_run_extend_post = function (uidrun, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_extend_post(uidrun, inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the attestation/run endpoint. */
        V2Client.prototype.portal_attestation_run_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_run_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_group_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_run_sendreminder_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_run_sendreminder_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_schedules_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_schedules_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_schedules_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_schedules_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_schedules_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_schedules_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns the object state snapshot associated with the specified attestation case. */
        V2Client.prototype.portal_attestation_snapshot_get = function (uidcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_snapshot_get(uidcase, options), requestOptions);
        };
        /** Initiates step-up authentication for the specified request. */
        V2Client.prototype.portal_attestation_stepup_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_stepup_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_attestation_userconfig_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_userconfig_get(options), requestOptions);
        };
        V2Client.prototype.portal_attestation_workflow_get = function (/** Unique attestation case identifier */ uidattestationcase, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_attestation_workflow_get(uidattestationcase, options), requestOptions);
        };
        /** Returns a list of candidate objects from the table AERole. */
        V2Client.prototype.portal_candidates_AERole_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AERole_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/AERole endpoint. */
        V2Client.prototype.portal_candidates_AERole_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AERole_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of candidate objects from the table AttestationPolicyGroup. */
        V2Client.prototype.portal_candidates_AttestationPolicyGroup_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AttestationPolicyGroup_get(options), requestOptions);
        };
        /** Returns data model information about query options for the candidates/AttestationPolicyGroup endpoint. */
        V2Client.prototype.portal_candidates_AttestationPolicyGroup_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AttestationPolicyGroup_datamodel_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/AttestationPolicyGroup endpoint. */
        V2Client.prototype.portal_candidates_AttestationPolicyGroup_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AttestationPolicyGroup_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of candidate objects from the table ComplianceArea. */
        V2Client.prototype.portal_candidates_ComplianceArea_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_ComplianceArea_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/ComplianceArea endpoint. */
        V2Client.prototype.portal_candidates_ComplianceArea_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_ComplianceArea_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of candidate objects from the table DialogTimeZone. */
        V2Client.prototype.portal_candidates_DialogTimeZone_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_DialogTimeZone_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/DialogTimeZone endpoint. */
        V2Client.prototype.portal_candidates_DialogTimeZone_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_DialogTimeZone_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of candidate objects from the table MitigatingControl. */
        V2Client.prototype.portal_candidates_MitigatingControl_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
        V2Client.prototype.portal_candidates_MitigatingControl_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of candidate objects from the table Person. */
        V2Client.prototype.portal_candidates_Person_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/Person endpoint. */
        V2Client.prototype.portal_candidates_Person_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of candidate objects from the table QBMCulture. */
        V2Client.prototype.portal_candidates_QBMCulture_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_QBMCulture_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/QBMCulture endpoint. */
        V2Client.prototype.portal_candidates_QBMCulture_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_QBMCulture_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of candidate objects from the table QERTermsOfUse. */
        V2Client.prototype.portal_candidates_QERTermsOfUse_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERTermsOfUse_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/QERTermsOfUse endpoint. */
        V2Client.prototype.portal_candidates_QERTermsOfUse_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERTermsOfUse_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Triggers an ownership attestation for the specified device. */
        V2Client.prototype.portal_claimdevice_post = function (/** Identity claiming the ownership */ uidperson, /** Identifier of the device */ uiddevice, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimdevice_post(uidperson, uiddevice, options), requestOptions);
        };
        /** Returns the list of devices for which the user can trigger an ownership attestation. */
        V2Client.prototype.portal_claimdevice_devices_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimdevice_devices_get(options), requestOptions);
        };
        V2Client.prototype.portal_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_config_get(options), requestOptions);
        };
        V2Client.prototype.portal_featureconfig_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_featureconfig_get(options), requestOptions);
        };
        V2Client.prototype.register_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.register_config_get(options), requestOptions);
        };
        V2Client.prototype.register_featureconfig_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.register_featureconfig_get(options), requestOptions);
        };
        V2Client.prototype.register_person_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.register_person_post(inputParameterName, options), requestOptions);
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.OpsupportCandidatesDialogtimezone = OpsupportCandidatesDialogtimezone;
    exports.OpsupportCandidatesDialogtimezoneInteractive = OpsupportCandidatesDialogtimezoneInteractive;
    exports.OpsupportCandidatesDialogtimezoneWrapper = OpsupportCandidatesDialogtimezoneWrapper;
    exports.PasswordresetCandidatesDialogtimezone = PasswordresetCandidatesDialogtimezone;
    exports.PasswordresetCandidatesDialogtimezoneInteractive = PasswordresetCandidatesDialogtimezoneInteractive;
    exports.PasswordresetCandidatesDialogtimezoneWrapper = PasswordresetCandidatesDialogtimezoneWrapper;
    exports.PortalAttestationApprove = PortalAttestationApprove;
    exports.PortalAttestationApproveInteractive = PortalAttestationApproveInteractive;
    exports.PortalAttestationApproveParameterCandidates = PortalAttestationApproveParameterCandidates;
    exports.PortalAttestationApproveParameterCandidatesInteractive = PortalAttestationApproveParameterCandidatesInteractive;
    exports.PortalAttestationApproveParameterCandidatesWrapper = PortalAttestationApproveParameterCandidatesWrapper;
    exports.PortalAttestationApproveWrapper = PortalAttestationApproveWrapper;
    exports.PortalAttestationCase = PortalAttestationCase;
    exports.PortalAttestationCaseHistory = PortalAttestationCaseHistory;
    exports.PortalAttestationCaseHistoryInteractive = PortalAttestationCaseHistoryInteractive;
    exports.PortalAttestationCaseHistoryWrapper = PortalAttestationCaseHistoryWrapper;
    exports.PortalAttestationCaseInteractive = PortalAttestationCaseInteractive;
    exports.PortalAttestationCaseParameterCandidates = PortalAttestationCaseParameterCandidates;
    exports.PortalAttestationCaseParameterCandidatesInteractive = PortalAttestationCaseParameterCandidatesInteractive;
    exports.PortalAttestationCaseParameterCandidatesWrapper = PortalAttestationCaseParameterCandidatesWrapper;
    exports.PortalAttestationCaseWrapper = PortalAttestationCaseWrapper;
    exports.PortalAttestationFilterCandidates = PortalAttestationFilterCandidates;
    exports.PortalAttestationFilterCandidatesInteractive = PortalAttestationFilterCandidatesInteractive;
    exports.PortalAttestationFilterCandidatesWrapper = PortalAttestationFilterCandidatesWrapper;
    exports.PortalAttestationFilterMatchingobjects = PortalAttestationFilterMatchingobjects;
    exports.PortalAttestationFilterMatchingobjectsInteractive = PortalAttestationFilterMatchingobjectsInteractive;
    exports.PortalAttestationFilterMatchingobjectsWrapper = PortalAttestationFilterMatchingobjectsWrapper;
    exports.PortalAttestationObject = PortalAttestationObject;
    exports.PortalAttestationObjectInteractive = PortalAttestationObjectInteractive;
    exports.PortalAttestationObjectWrapper = PortalAttestationObjectWrapper;
    exports.PortalAttestationPersondecision = PortalAttestationPersondecision;
    exports.PortalAttestationPersondecisionInteractive = PortalAttestationPersondecisionInteractive;
    exports.PortalAttestationPersondecisionWrapper = PortalAttestationPersondecisionWrapper;
    exports.PortalAttestationPolicy = PortalAttestationPolicy;
    exports.PortalAttestationPolicyEdit = PortalAttestationPolicyEdit;
    exports.PortalAttestationPolicyEditInteractive = PortalAttestationPolicyEditInteractive;
    exports.PortalAttestationPolicyEditInteractiveWrapper = PortalAttestationPolicyEditInteractiveWrapper;
    exports.PortalAttestationPolicyEditWrapper = PortalAttestationPolicyEditWrapper;
    exports.PortalAttestationPolicyInteractive = PortalAttestationPolicyInteractive;
    exports.PortalAttestationPolicyWrapper = PortalAttestationPolicyWrapper;
    exports.PortalAttestationPolicygroups = PortalAttestationPolicygroups;
    exports.PortalAttestationPolicygroupsInteractive = PortalAttestationPolicygroupsInteractive;
    exports.PortalAttestationPolicygroupsInteractiveWrapper = PortalAttestationPolicygroupsInteractiveWrapper;
    exports.PortalAttestationPolicygroupsWrapper = PortalAttestationPolicygroupsWrapper;
    exports.PortalAttestationRun = PortalAttestationRun;
    exports.PortalAttestationRunApprovers = PortalAttestationRunApprovers;
    exports.PortalAttestationRunApproversInteractive = PortalAttestationRunApproversInteractive;
    exports.PortalAttestationRunApproversWrapper = PortalAttestationRunApproversWrapper;
    exports.PortalAttestationRunInteractive = PortalAttestationRunInteractive;
    exports.PortalAttestationRunWrapper = PortalAttestationRunWrapper;
    exports.PortalAttestationSchedules = PortalAttestationSchedules;
    exports.PortalAttestationSchedulesInteractive = PortalAttestationSchedulesInteractive;
    exports.PortalAttestationSchedulesWrapper = PortalAttestationSchedulesWrapper;
    exports.PortalAttestationWorkflow = PortalAttestationWorkflow;
    exports.PortalAttestationWorkflowInteractive = PortalAttestationWorkflowInteractive;
    exports.PortalAttestationWorkflowWrapper = PortalAttestationWorkflowWrapper;
    exports.PortalCandidatesAerole = PortalCandidatesAerole;
    exports.PortalCandidatesAeroleInteractive = PortalCandidatesAeroleInteractive;
    exports.PortalCandidatesAeroleWrapper = PortalCandidatesAeroleWrapper;
    exports.PortalCandidatesAttestationpolicygroup = PortalCandidatesAttestationpolicygroup;
    exports.PortalCandidatesAttestationpolicygroupInteractive = PortalCandidatesAttestationpolicygroupInteractive;
    exports.PortalCandidatesAttestationpolicygroupWrapper = PortalCandidatesAttestationpolicygroupWrapper;
    exports.PortalCandidatesCompliancearea = PortalCandidatesCompliancearea;
    exports.PortalCandidatesComplianceareaInteractive = PortalCandidatesComplianceareaInteractive;
    exports.PortalCandidatesComplianceareaWrapper = PortalCandidatesComplianceareaWrapper;
    exports.PortalCandidatesDialogtimezone = PortalCandidatesDialogtimezone;
    exports.PortalCandidatesDialogtimezoneInteractive = PortalCandidatesDialogtimezoneInteractive;
    exports.PortalCandidatesDialogtimezoneWrapper = PortalCandidatesDialogtimezoneWrapper;
    exports.PortalCandidatesMitigatingcontrol = PortalCandidatesMitigatingcontrol;
    exports.PortalCandidatesMitigatingcontrolInteractive = PortalCandidatesMitigatingcontrolInteractive;
    exports.PortalCandidatesMitigatingcontrolWrapper = PortalCandidatesMitigatingcontrolWrapper;
    exports.PortalCandidatesPerson = PortalCandidatesPerson;
    exports.PortalCandidatesPersonInteractive = PortalCandidatesPersonInteractive;
    exports.PortalCandidatesPersonWrapper = PortalCandidatesPersonWrapper;
    exports.PortalCandidatesQbmculture = PortalCandidatesQbmculture;
    exports.PortalCandidatesQbmcultureInteractive = PortalCandidatesQbmcultureInteractive;
    exports.PortalCandidatesQbmcultureWrapper = PortalCandidatesQbmcultureWrapper;
    exports.PortalCandidatesQertermsofuse = PortalCandidatesQertermsofuse;
    exports.PortalCandidatesQertermsofuseInteractive = PortalCandidatesQertermsofuseInteractive;
    exports.PortalCandidatesQertermsofuseWrapper = PortalCandidatesQertermsofuseWrapper;
    exports.PortalClaimdeviceDevices = PortalClaimdeviceDevices;
    exports.PortalClaimdeviceDevicesInteractive = PortalClaimdeviceDevicesInteractive;
    exports.PortalClaimdeviceDevicesWrapper = PortalClaimdeviceDevicesWrapper;
    exports.RegisterPerson = RegisterPerson;
    exports.RegisterPersonInteractive = RegisterPersonInteractive;
    exports.RegisterPersonWrapper = RegisterPersonWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
