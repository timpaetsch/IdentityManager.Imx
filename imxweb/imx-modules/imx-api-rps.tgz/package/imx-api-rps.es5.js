import { ValType, DisplayColumns, TypedEntity, ReadExtTypedEntity, ReadWriteExtTypedEntity, TypedEntityBuilder, InteractiveTypedEntityBuilder, EntityState, TimeZoneInfo, DisplayPattern, FkCandidateBuilder, MethodDefinition } from 'imx-qbm-dbts';

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var TypedClient = /** @class */ (function () {
    function TypedClient(client, translationProvider) {
        this.PortalCandidatesPerson = new PortalCandidatesPersonWrapper(client, translationProvider);
        this.PortalReportData = new PortalReportDataWrapper(client, translationProvider);
        this.PortalReports = new PortalReportsWrapper(client, translationProvider);
        this.PortalReportsEdit = new PortalReportsEditWrapper(client, translationProvider);
        this.PortalReportsEditInteractive = new PortalReportsEditInteractiveWrapper(client, translationProvider);
        this.PortalReportsSqlwizardCandidates = new PortalReportsSqlwizardCandidatesWrapper(client, translationProvider);
        this.PortalReportsTables = new PortalReportsTablesWrapper(client, translationProvider);
        this.PortalShopConfigEntitlementsRpsreport = new PortalShopConfigEntitlementsRpsreportWrapper(client, translationProvider);
        this.PortalStatisticsData = new PortalStatisticsDataWrapper(client, translationProvider);
        this.PortalSubscription = new PortalSubscriptionWrapper(client, translationProvider);
        this.PortalSubscriptionInteractive = new PortalSubscriptionInteractiveWrapper(client, translationProvider);
        this.PortalSubscriptionInteractiveParameterCandidates = new PortalSubscriptionInteractiveParameterCandidatesWrapper(client, translationProvider);
    }
    return TypedClient;
}());
var PortalCandidatesPerson = /** @class */ (function (_super) {
    __extends(PortalCandidatesPerson, _super);
    function PortalCandidatesPerson() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.DefaultEmailAddress = _this.GetEntityValue('DefaultEmailAddress');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesPerson.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'DefaultEmailAddress': {
                ColumnName: 'DefaultEmailAddress',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Person', Columns: columns };
    };
    return PortalCandidatesPerson;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesPerson type. */
var PortalCandidatesPersonInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesPersonInteractive, _super);
    function PortalCandidatesPersonInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesPersonInteractive;
}(PortalCandidatesPerson));
var PortalReportData = /** @class */ (function (_super) {
    __extends(PortalReportData, _super);
    function PortalReportData() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** Returns the static compile time schema for this type. */
    PortalReportData.GetEntitySchema = function () {
        var columns = {};
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'non_static_table', Columns: columns };
    };
    return PortalReportData;
}(ReadExtTypedEntity));
/** @deprecated Use the PortalReportData type. */
var PortalReportDataInteractive = /** @class */ (function (_super) {
    __extends(PortalReportDataInteractive, _super);
    function PortalReportDataInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalReportDataInteractive;
}(PortalReportData));
var PortalReports = /** @class */ (function (_super) {
    __extends(PortalReports, _super);
    function PortalReports() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Description = _this.GetEntityValue('Description');
        _this.IsListReport = _this.GetEntityValue('IsListReport');
        _this.IsOob = _this.GetEntityValue('IsOob');
        _this.Subscriptions = _this.GetEntityValue('Subscriptions');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalReports.GetEntitySchema = function () {
        var columns = {
            'Description': {
                ColumnName: 'Description',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'IsListReport': {
                ColumnName: 'IsListReport',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsOob': {
                ColumnName: 'IsOob',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Subscriptions': {
                ColumnName: 'Subscriptions',
                Type: ValType.Int,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'RPSReport', Columns: columns };
    };
    return PortalReports;
}(TypedEntity));
/** @deprecated Use the PortalReports type. */
var PortalReportsInteractive = /** @class */ (function (_super) {
    __extends(PortalReportsInteractive, _super);
    function PortalReportsInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalReportsInteractive;
}(PortalReports));
var PortalReportsEdit = /** @class */ (function (_super) {
    __extends(PortalReportsEdit, _super);
    function PortalReportsEdit() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Description = _this.GetEntityValue('Description');
        _this.IsListReport = _this.GetEntityValue('IsListReport');
        _this.Ident_RPSReport = _this.GetEntityValue('Ident_RPSReport');
        _this.AvailableTo = _this.GetEntityValue('AvailableTo');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalReportsEdit.GetEntitySchema = function () {
        var columns = {
            'Description': {
                ColumnName: 'Description',
                Type: ValType.Text,
                IsReadOnly: false,
            },
            'IsListReport': {
                ColumnName: 'IsListReport',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Ident_RPSReport': {
                ColumnName: 'Ident_RPSReport',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'AvailableTo': {
                ColumnName: 'AvailableTo',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'RPSReport', Columns: columns };
    };
    return PortalReportsEdit;
}(ReadWriteExtTypedEntity));
/** @deprecated Use the PortalReportsEdit type. */
var PortalReportsEditInteractive = /** @class */ (function (_super) {
    __extends(PortalReportsEditInteractive, _super);
    function PortalReportsEditInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalReportsEditInteractive;
}(PortalReportsEdit));
var PortalReportsSqlwizardCandidates = /** @class */ (function (_super) {
    __extends(PortalReportsSqlwizardCandidates, _super);
    function PortalReportsSqlwizardCandidates() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** Returns the static compile time schema for this type. */
    PortalReportsSqlwizardCandidates.GetEntitySchema = function () {
        var columns = {};
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'non_static_table', Columns: columns };
    };
    return PortalReportsSqlwizardCandidates;
}(TypedEntity));
/** @deprecated Use the PortalReportsSqlwizardCandidates type. */
var PortalReportsSqlwizardCandidatesInteractive = /** @class */ (function (_super) {
    __extends(PortalReportsSqlwizardCandidatesInteractive, _super);
    function PortalReportsSqlwizardCandidatesInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalReportsSqlwizardCandidatesInteractive;
}(PortalReportsSqlwizardCandidates));
var PortalReportsTables = /** @class */ (function (_super) {
    __extends(PortalReportsTables, _super);
    function PortalReportsTables() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.TableName = _this.GetEntityValue('TableName');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalReportsTables.GetEntitySchema = function () {
        var columns = {
            'TableName': {
                ColumnName: 'TableName',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'DialogTable', Columns: columns };
    };
    return PortalReportsTables;
}(TypedEntity));
/** @deprecated Use the PortalReportsTables type. */
var PortalReportsTablesInteractive = /** @class */ (function (_super) {
    __extends(PortalReportsTablesInteractive, _super);
    function PortalReportsTablesInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalReportsTablesInteractive;
}(PortalReportsTables));
var PortalShopConfigEntitlementsRpsreport = /** @class */ (function (_super) {
    __extends(PortalShopConfigEntitlementsRpsreport, _super);
    function PortalShopConfigEntitlementsRpsreport() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
        _this.UID_RPSReport = _this.GetEntityValue('UID_RPSReport');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalShopConfigEntitlementsRpsreport.GetEntitySchema = function () {
        var columns = {
            'UID_ITShopOrg': {
                ColumnName: 'UID_ITShopOrg',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_RPSReport': {
                ColumnName: 'UID_RPSReport',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'ITShopOrgHasRPSReport', Columns: columns };
    };
    return PortalShopConfigEntitlementsRpsreport;
}(TypedEntity));
/** @deprecated Use the PortalShopConfigEntitlementsRpsreport type. */
var PortalShopConfigEntitlementsRpsreportInteractive = /** @class */ (function (_super) {
    __extends(PortalShopConfigEntitlementsRpsreportInteractive, _super);
    function PortalShopConfigEntitlementsRpsreportInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalShopConfigEntitlementsRpsreportInteractive;
}(PortalShopConfigEntitlementsRpsreport));
var PortalStatisticsData = /** @class */ (function (_super) {
    __extends(PortalStatisticsData, _super);
    function PortalStatisticsData() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** Returns the static compile time schema for this type. */
    PortalStatisticsData.GetEntitySchema = function () {
        var columns = {};
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'non_static_table', Columns: columns };
    };
    return PortalStatisticsData;
}(ReadExtTypedEntity));
/** @deprecated Use the PortalStatisticsData type. */
var PortalStatisticsDataInteractive = /** @class */ (function (_super) {
    __extends(PortalStatisticsDataInteractive, _super);
    function PortalStatisticsDataInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalStatisticsDataInteractive;
}(PortalStatisticsData));
var PortalSubscription = /** @class */ (function (_super) {
    __extends(PortalSubscription, _super);
    function PortalSubscription() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_RPSReport = _this.GetEntityValue('UID_RPSReport');
        _this.UID_DialogSchedule = _this.GetEntityValue('UID_DialogSchedule');
        _this.ExportFormat = _this.GetEntityValue('ExportFormat');
        _this.Ident_RPSSubscription = _this.GetEntityValue('Ident_RPSSubscription');
        _this.IsListReport = _this.GetEntityValue('IsListReport');
        _this.AddtlSubscribers = _this.GetEntityValue('AddtlSubscribers');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalSubscription.GetEntitySchema = function () {
        var columns = {
            'UID_RPSReport': {
                ColumnName: 'UID_RPSReport',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_DialogSchedule': {
                ColumnName: 'UID_DialogSchedule',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'ExportFormat': {
                ColumnName: 'ExportFormat',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'Ident_RPSSubscription': {
                ColumnName: 'Ident_RPSSubscription',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'IsListReport': {
                ColumnName: 'IsListReport',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'AddtlSubscribers': {
                ColumnName: 'AddtlSubscribers',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'RPSSubscription', Columns: columns };
    };
    return PortalSubscription;
}(ReadWriteExtTypedEntity));
/** @deprecated Use the PortalSubscription type. */
var PortalSubscriptionInteractive = /** @class */ (function (_super) {
    __extends(PortalSubscriptionInteractive, _super);
    function PortalSubscriptionInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalSubscriptionInteractive;
}(PortalSubscription));
var PortalSubscriptionInteractiveParameterCandidates = /** @class */ (function (_super) {
    __extends(PortalSubscriptionInteractiveParameterCandidates, _super);
    function PortalSubscriptionInteractiveParameterCandidates() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** Returns the static compile time schema for this type. */
    PortalSubscriptionInteractiveParameterCandidates.GetEntitySchema = function () {
        var columns = {};
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'non_static_table', Columns: columns };
    };
    return PortalSubscriptionInteractiveParameterCandidates;
}(TypedEntity));
/** @deprecated Use the PortalSubscriptionInteractiveParameterCandidates type. */
var PortalSubscriptionInteractiveParameterCandidatesInteractive = /** @class */ (function (_super) {
    __extends(PortalSubscriptionInteractiveParameterCandidatesInteractive, _super);
    function PortalSubscriptionInteractiveParameterCandidatesInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalSubscriptionInteractiveParameterCandidatesInteractive;
}(PortalSubscriptionInteractiveParameterCandidates));
var PortalCandidatesPersonWrapper = /** @class */ (function () {
    function PortalCandidatesPersonWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesPersonWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/Person');
    };
    PortalCandidatesPersonWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/Person');
            this.builder = new TypedEntityBuilder(PortalCandidatesPerson, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesPersonWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_Person_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesPersonWrapper;
}());
var PortalReportDataWrapper = /** @class */ (function () {
    function PortalReportDataWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalReportDataWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/report/data/{UID_RPSReport}');
    };
    PortalReportDataWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/report/data/{UID_RPSReport}');
            this.builder = new TypedEntityBuilder(PortalReportData, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalReportDataWrapper.prototype.Get = function (UID_RPSReport, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_report_data_get(UID_RPSReport, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalReportDataWrapper;
}());
var PortalReportsWrapper = /** @class */ (function () {
    function PortalReportsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalReportsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/reports');
    };
    PortalReportsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/reports');
            this.builder = new TypedEntityBuilder(PortalReports, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalReportsWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_reports_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalReportsWrapper;
}());
var PortalReportsEditWrapper = /** @class */ (function () {
    function PortalReportsEditWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.deleteMethod = function (entity) {
            return _this.client.portal_reports_edit_delete(entity.GetColumn('UID_RPSReport').GetValue());
        };
    }
    /** Returns the runtime schema for this method. */
    PortalReportsEditWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/reports/edit');
    };
    PortalReportsEditWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/reports/edit');
            this.builder = new TypedEntityBuilder(PortalReportsEdit, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalReportsEditWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_reports_edit_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalReportsEditWrapper.prototype.Delete = function (UID_RPSReport, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_reports_edit_delete(UID_RPSReport, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalReportsEditWrapper;
}());
var PortalReportsEditInteractiveWrapper = /** @class */ (function () {
    function PortalReportsEditInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_reports_edit_interactive_put(writeData);
        };
        this.deleteMethod = function (entity, deleteData) {
            return _this.client.portal_reports_edit_interactive_delete(deleteData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalReportsEditInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/reports/edit/interactive');
    };
    PortalReportsEditInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/reports/edit/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalReportsEdit, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalReportsEditInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_reports_edit_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalReportsEditInteractiveWrapper.prototype.Delete = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_reports_edit_interactive_delete(inputParameterName.InteractiveEntityDeleteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalReportsEditInteractiveWrapper.prototype.Get_byid = function (UID_RPSReport, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_reports_edit_interactive_byid_get(UID_RPSReport, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalReportsEditInteractiveWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_reports_edit_interactive_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalReportsEditInteractiveWrapper;
}());
var PortalReportsSqlwizardCandidatesWrapper = /** @class */ (function () {
    function PortalReportsSqlwizardCandidatesWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalReportsSqlwizardCandidatesWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/reports/sqlwizard/candidates/{table}');
    };
    PortalReportsSqlwizardCandidatesWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/reports/sqlwizard/candidates/{table}');
            this.builder = new TypedEntityBuilder(PortalReportsSqlwizardCandidates, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalReportsSqlwizardCandidatesWrapper.prototype.Get = function (table, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_reports_sqlwizard_candidates_get(table, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalReportsSqlwizardCandidatesWrapper;
}());
var PortalReportsTablesWrapper = /** @class */ (function () {
    function PortalReportsTablesWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalReportsTablesWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/reports/tables');
    };
    PortalReportsTablesWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/reports/tables');
            this.builder = new TypedEntityBuilder(PortalReportsTables, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalReportsTablesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_reports_tables_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalReportsTablesWrapper;
}());
var PortalShopConfigEntitlementsRpsreportWrapper = /** @class */ (function () {
    function PortalShopConfigEntitlementsRpsreportWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            {
                return _this.client.portal_shop_config_entitlements_RPSReport_post(entity.GetColumn('UID_ITShopOrg').GetValue(), writeData);
            }
        };
        this.deleteMethod = function (entity) {
            return _this.client.portal_shop_config_entitlements_RPSReport_delete(entity.GetColumn('UID_ITShopOrg').GetValue(), entity.GetColumn('UID_RPSReport').GetValue());
        };
    }
    PortalShopConfigEntitlementsRpsreportWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalShopConfigEntitlementsRpsreportWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport');
    };
    PortalShopConfigEntitlementsRpsreportWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport');
            this.builder = new TypedEntityBuilder(PortalShopConfigEntitlementsRpsreport, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalShopConfigEntitlementsRpsreportWrapper.prototype.Get = function (UID_ITShopOrg, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_RPSReport_get(UID_ITShopOrg, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalShopConfigEntitlementsRpsreportWrapper.prototype.Post = function (UID_ITShopOrg, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_RPSReport_post(UID_ITShopOrg, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalShopConfigEntitlementsRpsreportWrapper.prototype.Delete = function (UID_ITShopOrg, UID_RPSReport, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_RPSReport_delete(UID_ITShopOrg, UID_RPSReport, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalShopConfigEntitlementsRpsreportWrapper;
}());
var PortalStatisticsDataWrapper = /** @class */ (function () {
    function PortalStatisticsDataWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalStatisticsDataWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/statistics/data/{id}');
    };
    PortalStatisticsDataWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/statistics/data/{id}');
            this.builder = new TypedEntityBuilder(PortalStatisticsData, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalStatisticsDataWrapper.prototype.Get = function (id, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_statistics_data_get(id, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalStatisticsDataWrapper;
}());
var PortalSubscriptionWrapper = /** @class */ (function () {
    function PortalSubscriptionWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.deleteMethod = function (entity) {
            return _this.client.portal_subscription_delete(entity.GetColumn('UID_RPSSubscription').GetValue());
        };
    }
    /** Returns the runtime schema for this method. */
    PortalSubscriptionWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/subscription');
    };
    PortalSubscriptionWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/subscription');
            this.builder = new TypedEntityBuilder(PortalSubscription, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalSubscriptionWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_subscription_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalSubscriptionWrapper.prototype.Delete = function (UID_RPSSubscription, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_subscription_delete(UID_RPSSubscription, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalSubscriptionWrapper;
}());
var PortalSubscriptionInteractiveWrapper = /** @class */ (function () {
    function PortalSubscriptionInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_subscription_interactive_put(writeData);
        };
        this.deleteMethod = function (entity, deleteData) {
            return _this.client.portal_subscription_interactive_delete(deleteData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalSubscriptionInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/subscription/interactive');
    };
    PortalSubscriptionInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/subscription/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalSubscription, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalSubscriptionInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_subscription_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalSubscriptionInteractiveWrapper.prototype.Delete = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_subscription_interactive_delete(inputParameterName.InteractiveEntityDeleteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalSubscriptionInteractiveWrapper.prototype.Get_byid = function (UID_RPSSubscription, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_subscription_interactive_byid_get(UID_RPSSubscription, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalSubscriptionInteractiveWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_subscription_interactive_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalSubscriptionInteractiveWrapper;
}());
var PortalSubscriptionInteractiveParameterCandidatesWrapper = /** @class */ (function () {
    function PortalSubscriptionInteractiveParameterCandidatesWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalSubscriptionInteractiveParameterCandidatesWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/subscription/interactive/parameter/{name}/candidates/{parenttable}');
    };
    PortalSubscriptionInteractiveParameterCandidatesWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/subscription/interactive/parameter/{name}/candidates/{parenttable}');
            this.builder = new TypedEntityBuilder(PortalSubscriptionInteractiveParameterCandidates, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalSubscriptionInteractiveParameterCandidatesWrapper.prototype.Post = function (name, parenttable, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_subscription_interactive_parameter_candidates_post(name, parenttable, inputParameterName.InteractiveEntityStateData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalSubscriptionInteractiveParameterCandidatesWrapper;
}());
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
var ApiClientMethodFactory = /** @class */ (function () {
    function ApiClientMethodFactory() {
    }
    ApiClientMethodFactory.prototype.portal_candidates_Person_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/Person',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_Person_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/Person/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_report_data_get = function (parameters, UID_RPSReport, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/report/data/{UID_RPSReport}',
            parameters: [
                {
                    name: 'parameters',
                    value: parameters,
                    in: 'query'
                },
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_report_data_datamodel_get = function (UID_RPSReport, filter) {
        return {
            path: '/portal/report/data/{UID_RPSReport}/datamodel',
            parameters: [
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_report_data_group_get = function (UID_RPSReport, by, def, filter, StartIndex, PageSize, withcount) {
        return {
            path: '/portal/report/data/{UID_RPSReport}/group',
            parameters: [
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'by',
                    value: by,
                    in: 'query'
                },
                {
                    name: 'def',
                    value: def,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'withcount',
                    value: withcount,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_reports_get = function (owned, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/reports',
            parameters: [
                {
                    name: 'owned',
                    value: owned,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_reports_edit_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/reports/edit',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_reports_edit_delete = function (UID_RPSReport) {
        return {
            path: '/portal/reports/edit/{UID_RPSReport}',
            parameters: [
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_reports_edit_interactive_get = function () {
        return {
            path: '/portal/reports/edit/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_reports_edit_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/reports/edit/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_reports_edit_interactive_delete = function (inputParameterName) {
        return {
            path: '/portal/reports/edit/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_reports_edit_interactive_byid_get = function (UID_RPSReport) {
        return {
            path: '/portal/reports/edit/interactive/{UID_RPSReport}',
            parameters: [
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_reports_sqlwizard_candidates_get = function (table, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/reports/sqlwizard/candidates/{table}',
            parameters: [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_reports_sqlwizard_tables_columns_get = function (table) {
        return {
            path: '/portal/reports/sqlwizard/tables/{table}/columns',
            parameters: [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_reports_tables_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/reports/tables',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_post = function (UID_ITShopOrg, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_delete = function (UID_ITShopOrg, UID_RPSReport) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport/{UID_RPSReport}',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_statistics_data_get = function (id, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/statistics/data/{id}',
            parameters: [
                {
                    name: 'id',
                    value: id,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_statistics_data_datamodel_get = function (id, filter) {
        return {
            path: '/portal/statistics/data/{id}/datamodel',
            parameters: [
                {
                    name: 'id',
                    value: id,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_statistics_data_group_get = function (id, by, def, filter, StartIndex, PageSize, withcount) {
        return {
            path: '/portal/statistics/data/{id}/group',
            parameters: [
                {
                    name: 'id',
                    value: id,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'by',
                    value: by,
                    in: 'query'
                },
                {
                    name: 'def',
                    value: def,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'withcount',
                    value: withcount,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/subscription',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_delete = function (UID_RPSSubscription) {
        return {
            path: '/portal/subscription/{UID_RPSSubscription}',
            parameters: [
                {
                    name: 'UID_RPSSubscription',
                    value: UID_RPSSubscription,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_sendmail_post = function (uid) {
        return {
            path: '/portal/subscription/{uid}/sendmail',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_sendmailcc_post = function (uid) {
        return {
            path: '/portal/subscription/{uid}/sendmailcc',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_get = function () {
        return {
            path: '/portal/subscription/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/subscription/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_delete = function (inputParameterName) {
        return {
            path: '/portal/subscription/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_report_get = function (entityid, keys, state, type) {
        return {
            path: '/portal/subscription/interactive/{entityid}/report',
            parameters: [
                {
                    name: 'entityid',
                    value: entityid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'keys',
                    value: keys,
                    in: 'query'
                },
                {
                    name: 'state',
                    value: state,
                    in: 'query'
                },
                {
                    name: 'type',
                    value: type,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'blob'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_byid_get = function (UID_RPSSubscription) {
        return {
            path: '/portal/subscription/interactive/{UID_RPSSubscription}',
            parameters: [
                {
                    name: 'UID_RPSSubscription',
                    value: UID_RPSSubscription,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_parameter_candidates_post = function (name, parenttable, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName) {
        return {
            path: '/portal/subscription/interactive/parameter/{name}/candidates/{parenttable}',
            parameters: [
                {
                    name: 'name',
                    value: name,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'parenttable',
                    value: parenttable,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_parameter_candidates_filtertree_post = function (name, parenttable, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/subscription/interactive/parameter/{name}/candidates/{parenttable}/filtertree',
            parameters: [
                {
                    name: 'name',
                    value: name,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'parenttable',
                    value: parenttable,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_UID_DialogSchedule_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/subscription/interactive/UID_DialogSchedule/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/subscription/interactive/UID_DialogSchedule/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_UID_RPSReport_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/subscription/interactive/UID_RPSReport/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get = function (filter) {
        return {
            path: '/portal/subscription/interactive/UID_RPSReport/candidates/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/subscription/interactive/UID_RPSReport/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return ApiClientMethodFactory;
}());
/** @deprecated Use the V2Client class for a stable method interface. */
var Client = /** @class */ (function () {
    function Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    /** Returns a list of candidate objects from the table Person. */
    Client.prototype.portal_candidates_Person_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/Person endpoint. */
    Client.prototype.portal_candidates_Person_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a data set corresponding to a subscribable report definition. */
    Client.prototype.portal_report_data_get = function (parameters, UID_RPSReport, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_report_data_get(parameters, UID_RPSReport, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns data model information about query options for the report/data/{UID_RPSReport} endpoint. */
    Client.prototype.portal_report_data_datamodel_get = function (UID_RPSReport, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_report_data_datamodel_get(UID_RPSReport, filter), requestOptions);
    };
    /** Returns a data set corresponding to a subscribable report definition. */
    Client.prototype.portal_report_data_group_get = function (UID_RPSReport, by, def, filter, StartIndex, PageSize, withcount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_report_data_group_get(UID_RPSReport, by, def, filter, StartIndex, PageSize, withcount), requestOptions);
    };
    /** Manages reports owned by the current user, or subscribable by the current user. */
    Client.prototype.portal_reports_get = function (owned, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_get(owned, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    Client.prototype.portal_reports_edit_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    Client.prototype.portal_reports_edit_delete = function (UID_RPSReport, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_delete(UID_RPSReport), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    Client.prototype.portal_reports_edit_interactive_get = function (requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_interactive_get(), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    Client.prototype.portal_reports_edit_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_interactive_put(inputParameterName), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    Client.prototype.portal_reports_edit_interactive_delete = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_interactive_delete(inputParameterName), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    Client.prototype.portal_reports_edit_interactive_byid_get = function (UID_RPSReport, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_interactive_byid_get(UID_RPSReport), requestOptions);
    };
    /** Returns a list of objects that can be assigned as a filter parameter. */
    Client.prototype.portal_reports_sqlwizard_candidates_get = function (table, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_sqlwizard_candidates_get(table, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns the filterable properties for the specified table. */
    Client.prototype.portal_reports_sqlwizard_tables_columns_get = function (table, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_sqlwizard_tables_columns_get(table), requestOptions);
    };
    Client.prototype.portal_reports_tables_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_tables_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_shop_config_entitlements_RPSReport_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_shop_config_entitlements_RPSReport_post = function (UID_ITShopOrg, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_post(UID_ITShopOrg, inputParameterName), requestOptions);
    };
    Client.prototype.portal_shop_config_entitlements_RPSReport_delete = function (UID_ITShopOrg, UID_RPSReport, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_delete(UID_ITShopOrg, UID_RPSReport), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    Client.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a data set corresponding to a statistic definition. */
    Client.prototype.portal_statistics_data_get = function (id, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_statistics_data_get(id, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns data model information about query options for the statistics/data/{id} endpoint. */
    Client.prototype.portal_statistics_data_datamodel_get = function (id, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_statistics_data_datamodel_get(id, filter), requestOptions);
    };
    /** Returns a data set corresponding to a statistic definition. */
    Client.prototype.portal_statistics_data_group_get = function (id, by, def, filter, StartIndex, PageSize, withcount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_statistics_data_group_get(id, by, def, filter, StartIndex, PageSize, withcount), requestOptions);
    };
    Client.prototype.portal_subscription_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_subscription_delete = function (UID_RPSSubscription, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_delete(UID_RPSSubscription), requestOptions);
    };
    /** Queues a job to e-mail the report to the subscriber. */
    Client.prototype.portal_subscription_sendmail_post = function (uid, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_sendmail_post(uid), requestOptions);
    };
    /** Queues a job to send one e-mail for each CC subscriber of the subscription. */
    Client.prototype.portal_subscription_sendmailcc_post = function (uid, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_sendmailcc_post(uid), requestOptions);
    };
    Client.prototype.portal_subscription_interactive_get = function (requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_get(), requestOptions);
    };
    Client.prototype.portal_subscription_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_subscription_interactive_delete = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_delete(inputParameterName), requestOptions);
    };
    Client.prototype.portal_subscription_interactive_report_get = function (entityid, keys, state, type, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_report_get(entityid, keys, state, type), requestOptions);
    };
    Client.prototype.portal_subscription_interactive_byid_get = function (UID_RPSSubscription, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_byid_get(UID_RPSSubscription), requestOptions);
    };
    /** Returns a list of objects that can be assigned as a parameter value. */
    Client.prototype.portal_subscription_interactive_parameter_candidates_post = function (name, parenttable, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_parameter_candidates_post(name, parenttable, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName), requestOptions);
    };
    /** Returns filter tree information for the subscription/interactive/parameter/{name}/candidates/{parenttable} endpoint. */
    Client.prototype.portal_subscription_interactive_parameter_candidates_filtertree_post = function (name, parenttable, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_parameter_candidates_filtertree_post(name, parenttable, filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
    Client.prototype.portal_subscription_interactive_UID_DialogSchedule_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_UID_DialogSchedule_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the subscription/interactive/UID_DialogSchedule/candidates endpoint. */
    Client.prototype.portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    Client.prototype.portal_subscription_interactive_UID_RPSReport_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_UID_RPSReport_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    Client.prototype.portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get(filter), requestOptions);
    };
    /** Returns filter tree information for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    Client.prototype.portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    return Client;
}());
var V2ApiClientMethodFactory = /** @class */ (function () {
    function V2ApiClientMethodFactory() {
    }
    V2ApiClientMethodFactory.prototype.portal_candidates_Person_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Person',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_Person_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Person/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_report_data_get = function (/** Unique identifier of the report definition */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/report/data/{UID_RPSReport}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_report_data_datamodel_get = function (/** Unique identifier of the report definition */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/report/data/{UID_RPSReport}/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_report_data_group_get = function (/** Unique identifier of the report definition */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/report/data/{UID_RPSReport}/group',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_reports_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/reports',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_reports_edit_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/reports/edit',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_reports_edit_delete = function (/** Predefined report */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/reports/edit/{UID_RPSReport}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_reports_edit_interactive_get = function (options, requestOptions) {
        return {
            path: '/portal/reports/edit/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_reports_edit_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/reports/edit/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_reports_edit_interactive_delete = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/reports/edit/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_reports_edit_interactive_byid_get = function (/** Primary key value UID_RPSReport */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/reports/edit/interactive/{UID_RPSReport}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_reports_sqlwizard_candidates_get = function (/** Name of the candidate table */ table, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/reports/sqlwizard/candidates/{table}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_reports_sqlwizard_tables_columns_get = function (/** Name of the filtered database table */ table, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/reports/sqlwizard/tables/{table}/columns',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_reports_tables_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/reports/tables',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** Predefined report */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport/{UID_RPSReport}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_RPSReport',
                    value: UID_RPSReport,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_statistics_data_get = function (/** Statistic identifier */ id, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/statistics/data/{id}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'id',
                    value: id,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_statistics_data_datamodel_get = function (/** Statistic identifier */ id, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/statistics/data/{id}/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'id',
                    value: id,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_statistics_data_group_get = function (/** Statistic identifier */ id, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/statistics/data/{id}/group',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'id',
                    value: id,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_delete = function (/** Subscription */ UID_RPSSubscription, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/{UID_RPSSubscription}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_RPSSubscription',
                    value: UID_RPSSubscription,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_sendmail_post = function (/** Unique identifier of the subscription. */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/{uid}/sendmail',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_sendmailcc_post = function (/** Unique identifier of the subscription. */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/{uid}/sendmailcc',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_get = function (options, requestOptions) {
        return {
            path: '/portal/subscription/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_delete = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_report_get = function (entityid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive/{entityid}/report',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'entityid',
                    value: entityid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'blob'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_byid_get = function (/** Primary key value UID_RPSSubscription */ UID_RPSSubscription, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive/{UID_RPSSubscription}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_RPSSubscription',
                    value: UID_RPSSubscription,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_parameter_candidates_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive/parameter/{name}/candidates/{parenttable}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'name',
                    value: name,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'parenttable',
                    value: parenttable,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_parameter_candidates_filtertree_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive/parameter/{name}/candidates/{parenttable}/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'name',
                    value: name,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'parenttable',
                    value: parenttable,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_UID_DialogSchedule_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive/UID_DialogSchedule/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive/UID_DialogSchedule/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_UID_RPSReport_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive/UID_RPSReport/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive/UID_RPSReport/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/subscription/interactive/UID_RPSReport/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return V2ApiClientMethodFactory;
}());
var V2Client = /** @class */ (function () {
    function V2Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new V2ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(V2Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    V2Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    V2Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    V2Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    /** Returns a list of candidate objects from the table Person. */
    V2Client.prototype.portal_candidates_Person_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/Person endpoint. */
    V2Client.prototype.portal_candidates_Person_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a data set corresponding to a subscribable report definition. */
    V2Client.prototype.portal_report_data_get = function (/** Unique identifier of the report definition */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_report_data_get(UID_RPSReport, options), requestOptions);
    };
    /** Returns data model information about query options for the report/data/{UID_RPSReport} endpoint. */
    V2Client.prototype.portal_report_data_datamodel_get = function (/** Unique identifier of the report definition */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_report_data_datamodel_get(UID_RPSReport, options), requestOptions);
    };
    /** Returns a data set corresponding to a subscribable report definition. */
    V2Client.prototype.portal_report_data_group_get = function (/** Unique identifier of the report definition */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_report_data_group_get(UID_RPSReport, options), requestOptions);
    };
    /** Manages reports owned by the current user, or subscribable by the current user. */
    V2Client.prototype.portal_reports_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_get(options), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    V2Client.prototype.portal_reports_edit_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_get(options), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    V2Client.prototype.portal_reports_edit_delete = function (/** Predefined report */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_delete(UID_RPSReport, options), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    V2Client.prototype.portal_reports_edit_interactive_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_interactive_get(options), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    V2Client.prototype.portal_reports_edit_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_interactive_put(inputParameterName, options), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    V2Client.prototype.portal_reports_edit_interactive_delete = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_interactive_delete(inputParameterName, options), requestOptions);
    };
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    V2Client.prototype.portal_reports_edit_interactive_byid_get = function (/** Primary key value UID_RPSReport */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_edit_interactive_byid_get(UID_RPSReport, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned as a filter parameter. */
    V2Client.prototype.portal_reports_sqlwizard_candidates_get = function (/** Name of the candidate table */ table, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_sqlwizard_candidates_get(table, options), requestOptions);
    };
    /** Returns the filterable properties for the specified table. */
    V2Client.prototype.portal_reports_sqlwizard_tables_columns_get = function (/** Name of the filtered database table */ table, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_sqlwizard_tables_columns_get(table, options), requestOptions);
    };
    V2Client.prototype.portal_reports_tables_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_reports_tables_get(options), requestOptions);
    };
    V2Client.prototype.portal_shop_config_entitlements_RPSReport_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_get(UID_ITShopOrg, options), requestOptions);
    };
    V2Client.prototype.portal_shop_config_entitlements_RPSReport_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_shop_config_entitlements_RPSReport_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** Predefined report */ UID_RPSReport, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_delete(UID_ITShopOrg, UID_RPSReport, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    V2Client.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    /** Returns a data set corresponding to a statistic definition. */
    V2Client.prototype.portal_statistics_data_get = function (/** Statistic identifier */ id, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_statistics_data_get(id, options), requestOptions);
    };
    /** Returns data model information about query options for the statistics/data/{id} endpoint. */
    V2Client.prototype.portal_statistics_data_datamodel_get = function (/** Statistic identifier */ id, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_statistics_data_datamodel_get(id, options), requestOptions);
    };
    /** Returns a data set corresponding to a statistic definition. */
    V2Client.prototype.portal_statistics_data_group_get = function (/** Statistic identifier */ id, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_statistics_data_group_get(id, options), requestOptions);
    };
    V2Client.prototype.portal_subscription_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_get(options), requestOptions);
    };
    V2Client.prototype.portal_subscription_delete = function (/** Subscription */ UID_RPSSubscription, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_delete(UID_RPSSubscription, options), requestOptions);
    };
    /** Queues a job to e-mail the report to the subscriber. */
    V2Client.prototype.portal_subscription_sendmail_post = function (/** Unique identifier of the subscription. */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_sendmail_post(uid, options), requestOptions);
    };
    /** Queues a job to send one e-mail for each CC subscriber of the subscription. */
    V2Client.prototype.portal_subscription_sendmailcc_post = function (/** Unique identifier of the subscription. */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_sendmailcc_post(uid, options), requestOptions);
    };
    V2Client.prototype.portal_subscription_interactive_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_get(options), requestOptions);
    };
    V2Client.prototype.portal_subscription_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_subscription_interactive_delete = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_delete(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_subscription_interactive_report_get = function (entityid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_report_get(entityid, options), requestOptions);
    };
    V2Client.prototype.portal_subscription_interactive_byid_get = function (/** Primary key value UID_RPSSubscription */ UID_RPSSubscription, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_byid_get(UID_RPSSubscription, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned as a parameter value. */
    V2Client.prototype.portal_subscription_interactive_parameter_candidates_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_parameter_candidates_post(name, parenttable, inputParameterName, options), requestOptions);
    };
    /** Returns filter tree information for the subscription/interactive/parameter/{name}/candidates/{parenttable} endpoint. */
    V2Client.prototype.portal_subscription_interactive_parameter_candidates_filtertree_post = function (/** Name of the parameter */ name, /** Name of the parent table of the foreign-key relation */ parenttable, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_parameter_candidates_filtertree_post(name, parenttable, inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
    V2Client.prototype.portal_subscription_interactive_UID_DialogSchedule_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_UID_DialogSchedule_candidates_get(options), requestOptions);
    };
    /** Returns filter tree information for the subscription/interactive/UID_DialogSchedule/candidates endpoint. */
    V2Client.prototype.portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    V2Client.prototype.portal_subscription_interactive_UID_RPSReport_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_UID_RPSReport_candidates_get(options), requestOptions);
    };
    /** Returns data model information about query options for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    V2Client.prototype.portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get(options), requestOptions);
    };
    /** Returns filter tree information for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    V2Client.prototype.portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    return V2Client;
}());

export { ApiClientMethodFactory, Client, PortalCandidatesPerson, PortalCandidatesPersonInteractive, PortalCandidatesPersonWrapper, PortalReportData, PortalReportDataInteractive, PortalReportDataWrapper, PortalReports, PortalReportsEdit, PortalReportsEditInteractive, PortalReportsEditInteractiveWrapper, PortalReportsEditWrapper, PortalReportsInteractive, PortalReportsSqlwizardCandidates, PortalReportsSqlwizardCandidatesInteractive, PortalReportsSqlwizardCandidatesWrapper, PortalReportsTables, PortalReportsTablesInteractive, PortalReportsTablesWrapper, PortalReportsWrapper, PortalShopConfigEntitlementsRpsreport, PortalShopConfigEntitlementsRpsreportInteractive, PortalShopConfigEntitlementsRpsreportWrapper, PortalStatisticsData, PortalStatisticsDataInteractive, PortalStatisticsDataWrapper, PortalSubscription, PortalSubscriptionInteractive, PortalSubscriptionInteractiveParameterCandidates, PortalSubscriptionInteractiveParameterCandidatesInteractive, PortalSubscriptionInteractiveParameterCandidatesWrapper, PortalSubscriptionInteractiveWrapper, PortalSubscriptionWrapper, TypedClient, V2ApiClientMethodFactory, V2Client };
