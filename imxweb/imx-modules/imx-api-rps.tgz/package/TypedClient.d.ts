import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityCollectionData, FilterData, FilterPropertyList, FilterTreeData, FkProviderItem, GroupInfoData, IClientProperty, InteractiveEntityData, InteractiveEntityDeleteData, InteractiveEntityStateData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, ParameterData, ReadExtTypedEntity, ReadWriteExtTypedEntity, SqlExpression, SqlWizardExpression, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityCollectionDataOfIReadOnlyListOfIReadOnlyListOfParameterData extends EntityCollectionData {
    ExtendedData?: ParameterData[][];
}
export interface ExtendedEntityCollectionDataOfListReportContentData extends EntityCollectionData {
    ExtendedData?: ListReportContentData;
}
export interface ExtendedEntityCollectionDataOfListReportDefinitionRead extends EntityCollectionData {
    ExtendedData?: ListReportDefinitionRead;
}
export interface ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData extends InteractiveEntityData {
    ExtendedData?: ParameterData[][];
}
export interface ExtendedInteractiveEntityDataOfListReportDefinitionRead extends InteractiveEntityData {
    ExtendedData?: ListReportDefinitionRead;
}
export interface ExtendedInteractiveEntityWriteDataOfIReadOnlyListOfIReadOnlyListOfEntityWriteDataColumn extends InteractiveEntityWriteData {
    ExtendedData?: EntityWriteDataColumn[][];
}
export interface ExtendedInteractiveEntityWriteDataOfListReportDefinitionWrite extends InteractiveEntityWriteData {
    ExtendedData?: ListReportDefinitionWrite;
}
export interface ListReportColumn {
    Name?: string;
    Display?: string;
}
export interface ListReportContentData {
    ReportDisplayName?: string;
    Columns?: string[];
    AdditionalProperties?: IClientProperty[];
}
export interface ListReportDefinitionDto {
    TableName?: string;
    TableNameDisplay?: string;
    AvailableColumns?: ListReportColumn[];
    SelectedColumns?: string[];
    Data?: SqlWizardExpression;
}
export interface ListReportDefinitionDtoWrite {
    TableName?: string;
    SelectedColumns?: string[];
    Data?: SqlWizardWrite;
}
export interface ListReportDefinitionRead {
    Definition?: ListReportDefinitionDto[];
}
export interface ListReportDefinitionWrite {
    Definition?: ListReportDefinitionDtoWrite[];
}
export interface SqlWizardWrite {
    Filters?: SqlExpression[];
}
export declare class TypedClient {
    readonly PortalCandidatesPerson: PortalCandidatesPersonWrapper;
    readonly PortalReportData: PortalReportDataWrapper;
    readonly PortalReports: PortalReportsWrapper;
    readonly PortalReportsEdit: PortalReportsEditWrapper;
    readonly PortalReportsEditInteractive: PortalReportsEditInteractiveWrapper;
    readonly PortalReportsSqlwizardCandidates: PortalReportsSqlwizardCandidatesWrapper;
    readonly PortalReportsTables: PortalReportsTablesWrapper;
    readonly PortalShopConfigEntitlementsRpsreport: PortalShopConfigEntitlementsRpsreportWrapper;
    readonly PortalStatisticsData: PortalStatisticsDataWrapper;
    readonly PortalSubscription: PortalSubscriptionWrapper;
    readonly PortalSubscriptionInteractive: PortalSubscriptionInteractiveWrapper;
    readonly PortalSubscriptionInteractiveParameterCandidates: PortalSubscriptionInteractiveParameterCandidatesWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalCandidatesPerson extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_Person' | 'DefaultEmailAddress'>;
}
/** @deprecated Use the PortalCandidatesPerson type. */
export declare class PortalCandidatesPersonInteractive extends PortalCandidatesPerson {
}
export declare class PortalReportData extends ReadExtTypedEntity<ListReportContentData> {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalReportData type. */
export declare class PortalReportDataInteractive extends PortalReportData {
}
export declare class PortalReports extends TypedEntity {
    readonly Description: IReadValue<string>;
    readonly IsListReport: IReadValue<boolean>;
    readonly IsOob: IReadValue<boolean>;
    readonly Subscriptions: IReadValue<number>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'Description' | 'IsListReport' | 'IsOob' | 'Subscriptions'>;
}
/** @deprecated Use the PortalReports type. */
export declare class PortalReportsInteractive extends PortalReports {
}
export declare class PortalReportsEdit extends ReadWriteExtTypedEntity<ListReportDefinitionRead, ListReportDefinitionWrite> {
    readonly Description: IWriteValue<string>;
    readonly IsListReport: IReadValue<boolean>;
    readonly Ident_RPSReport: IWriteValue<string>;
    readonly AvailableTo: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'Description' | 'IsListReport' | 'Ident_RPSReport' | 'AvailableTo'>;
}
/** @deprecated Use the PortalReportsEdit type. */
export declare class PortalReportsEditInteractive extends PortalReportsEdit {
}
export declare class PortalReportsSqlwizardCandidates extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalReportsSqlwizardCandidates type. */
export declare class PortalReportsSqlwizardCandidatesInteractive extends PortalReportsSqlwizardCandidates {
}
export declare class PortalReportsTables extends TypedEntity {
    readonly TableName: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'TableName'>;
}
/** @deprecated Use the PortalReportsTables type. */
export declare class PortalReportsTablesInteractive extends PortalReportsTables {
}
export declare class PortalShopConfigEntitlementsRpsreport extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_RPSReport: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_RPSReport'>;
}
/** @deprecated Use the PortalShopConfigEntitlementsRpsreport type. */
export declare class PortalShopConfigEntitlementsRpsreportInteractive extends PortalShopConfigEntitlementsRpsreport {
}
export declare class PortalStatisticsData extends ReadExtTypedEntity<ListReportContentData> {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalStatisticsData type. */
export declare class PortalStatisticsDataInteractive extends PortalStatisticsData {
}
export declare class PortalSubscription extends ReadWriteExtTypedEntity<ParameterData[][], EntityWriteDataColumn[][]> {
    readonly UID_RPSReport: IWriteValue<string>;
    readonly UID_DialogSchedule: IWriteValue<string>;
    readonly ExportFormat: IWriteValue<string>;
    readonly Ident_RPSSubscription: IWriteValue<string>;
    readonly IsListReport: IReadValue<boolean>;
    readonly AddtlSubscribers: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_RPSReport' | 'UID_DialogSchedule' | 'ExportFormat' | 'Ident_RPSSubscription' | 'IsListReport' | 'AddtlSubscribers'>;
}
/** @deprecated Use the PortalSubscription type. */
export declare class PortalSubscriptionInteractive extends PortalSubscription {
}
export declare class PortalSubscriptionInteractiveParameterCandidates extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalSubscriptionInteractiveParameterCandidates type. */
export declare class PortalSubscriptionInteractiveParameterCandidatesInteractive extends PortalSubscriptionInteractiveParameterCandidates {
}
export declare class PortalCandidatesPersonWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_Person_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesPerson, unknown>>;
}
export declare class PortalReportDataWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_RPSReport: string, parametersOptional?: portal_report_data_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportData, ListReportContentData>>;
}
export declare class PortalReportsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_reports_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReports, unknown>>;
}
export declare class PortalReportsEditWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_reports_edit_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEdit, ListReportDefinitionRead>>;
    Delete(UID_RPSReport: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEdit, ListReportDefinitionRead>>;
}
export declare class PortalReportsEditInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalReportsEdit, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEdit, ListReportDefinitionRead>>;
    Delete(inputParameterName: PortalReportsEdit, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEdit, ListReportDefinitionRead>>;
    Get_byid(UID_RPSReport: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEdit, ListReportDefinitionRead>>;
    Get(parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsEdit, ListReportDefinitionRead>>;
}
export declare class PortalReportsSqlwizardCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(table: string, parametersOptional?: portal_reports_sqlwizard_candidates_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsSqlwizardCandidates, unknown>>;
}
export declare class PortalReportsTablesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_reports_tables_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalReportsTables, unknown>>;
}
export declare class PortalShopConfigEntitlementsRpsreportWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsRpsreport;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: portal_shop_config_entitlements_RPSReport_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsRpsreport, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsRpsreport, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsRpsreport, unknown>>;
    Delete(UID_ITShopOrg: string, UID_RPSReport: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsRpsreport, unknown>>;
}
export declare class PortalStatisticsDataWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(id: string, parametersOptional?: portal_statistics_data_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalStatisticsData, ListReportContentData>>;
}
export declare class PortalSubscriptionWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_subscription_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscription, ParameterData[][]>>;
    Delete(UID_RPSSubscription: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscription, ParameterData[][]>>;
}
export declare class PortalSubscriptionInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalSubscription, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscription, ParameterData[][]>>;
    Delete(inputParameterName: PortalSubscription, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscription, ParameterData[][]>>;
    Get_byid(UID_RPSSubscription: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscription, ParameterData[][]>>;
    Get(parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscription, ParameterData[][]>>;
}
export declare class PortalSubscriptionInteractiveParameterCandidatesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Post(name: string, parenttable: string, inputParameterName: PortalSubscriptionInteractiveParameterCandidates, parametersOptional?: portal_subscription_interactive_parameter_candidates_post_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalSubscriptionInteractiveParameterCandidates, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_report_data_get(parameters: {
        [key: string]: any;
    }, UID_RPSReport: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<ExtendedEntityCollectionData<ListReportContentData>>;
    portal_report_data_datamodel_get(UID_RPSReport: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_report_data_group_get(UID_RPSReport: string, by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfoData>;
    portal_reports_get(owned: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_reports_edit_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    portal_reports_edit_delete(UID_RPSReport: string): MethodDescriptor<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    portal_reports_edit_interactive_get(): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_put(inputParameterName: any): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_byid_get(UID_RPSReport: string): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_sqlwizard_candidates_get(table: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_reports_sqlwizard_tables_columns_get(table: string): MethodDescriptor<FilterPropertyList>;
    portal_reports_tables_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_delete(UID_ITShopOrg: string, UID_RPSReport: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_statistics_data_get(id: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<ExtendedEntityCollectionData<ListReportContentData>>;
    portal_statistics_data_datamodel_get(id: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_statistics_data_group_get(id: string, by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean): MethodDescriptor<GroupInfoData>;
    portal_subscription_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_delete(UID_RPSSubscription: string): MethodDescriptor<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_sendmail_post(uid: string): MethodDescriptor<void>;
    portal_subscription_sendmailcc_post(uid: string): MethodDescriptor<void>;
    portal_subscription_interactive_get(): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_put(inputParameterName: any): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_delete(inputParameterName: InteractiveEntityDeleteData): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_report_get(entityid: string, keys: string[], state: string, type: string): MethodDescriptor<Blob>;
    portal_subscription_interactive_byid_get(UID_RPSSubscription: string): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: InteractiveEntityStateData): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_subscription_interactive_UID_DialogSchedule_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_subscription_interactive_UID_RPSReport_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a data set corresponding to a subscribable report definition. */
    portal_report_data_get(parameters: {
        [key: string]: any;
    }, UID_RPSReport: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportContentData>>;
    /** Returns data model information about query options for the report/data/{UID_RPSReport} endpoint. */
    portal_report_data_datamodel_get(UID_RPSReport: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns a data set corresponding to a subscribable report definition. */
    portal_report_data_group_get(UID_RPSReport: string, by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    /** Manages reports owned by the current user, or subscribable by the current user. */
    portal_reports_get(owned: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_delete(UID_RPSReport: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_interactive_get(requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_interactive_byid_get(UID_RPSReport: string, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Returns a list of objects that can be assigned as a filter parameter. */
    portal_reports_sqlwizard_candidates_get(table: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the filterable properties for the specified table. */
    portal_reports_sqlwizard_tables_columns_get(table: string, requestOptions?: ApiRequestOptions): Promise<FilterPropertyList>;
    portal_reports_tables_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_delete(UID_ITShopOrg: string, UID_RPSReport: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a data set corresponding to a statistic definition. */
    portal_statistics_data_get(id: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportContentData>>;
    /** Returns data model information about query options for the statistics/data/{id} endpoint. */
    portal_statistics_data_datamodel_get(id: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns a data set corresponding to a statistic definition. */
    portal_statistics_data_group_get(id: string, by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_subscription_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_delete(UID_RPSSubscription: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ParameterData[][]>>;
    /** Queues a job to e-mail the report to the subscriber. */
    portal_subscription_sendmail_post(uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Queues a job to send one e-mail for each CC subscriber of the subscription. */
    portal_subscription_sendmailcc_post(uid: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_subscription_interactive_get(requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_delete(inputParameterName: InteractiveEntityDeleteData, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_report_get(entityid: string, keys: string[], state: string, type: string, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_subscription_interactive_byid_get(UID_RPSSubscription: string, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_subscription_interactive_parameter_candidates_post(name: string, parenttable: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, inputParameterName: InteractiveEntityStateData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the subscription/interactive/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_subscription_interactive_parameter_candidates_filtertree_post(name: string, parenttable: string, filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
    portal_subscription_interactive_UID_DialogSchedule_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the subscription/interactive/UID_DialogSchedule/candidates endpoint. */
    portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    portal_subscription_interactive_UID_RPSReport_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
}
export interface portal_candidates_Person_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_Person_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_report_data_get_args {
    /** Report parameter values */ parameters?: {
        [key: string]: any;
    };
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (dynamic) */ ParentKey?: string;
}
export interface portal_report_data_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_report_data_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
}
export interface portal_reports_get_args {
    /** Filters reports owned by the current user. */ owned?: boolean;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_reports_edit_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_reports_sqlwizard_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (dynamic) */ ParentKey?: string;
}
export interface portal_reports_tables_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_RPSReport_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_statistics_data_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (dynamic) */ ParentKey?: string;
}
export interface portal_statistics_data_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_statistics_data_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
}
export interface portal_subscription_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_subscription_interactive_report_get_args {
    keys?: string[];
    state?: string;
    type?: string;
}
export interface portal_subscription_interactive_parameter_candidates_post_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (dynamic) */ ParentKey?: string;
}
export interface portal_subscription_interactive_parameter_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_subscription_interactive_UID_DialogSchedule_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_subscription_interactive_UID_RPSReport_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export declare class V2ApiClientMethodFactory {
    portal_candidates_Person_get(options?: portal_candidates_Person_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_Person_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_report_data_get(/** Unique identifier of the report definition */ UID_RPSReport: string, options?: portal_report_data_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ListReportContentData>>;
    portal_report_data_datamodel_get(/** Unique identifier of the report definition */ UID_RPSReport: string, options?: portal_report_data_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_report_data_group_get(/** Unique identifier of the report definition */ UID_RPSReport: string, options?: portal_report_data_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_reports_get(options?: portal_reports_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_reports_edit_get(options?: portal_reports_edit_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    portal_reports_edit_delete(/** Predefined report */ UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    portal_reports_edit_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_edit_interactive_byid_get(/** Primary key value UID_RPSReport */ UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    portal_reports_sqlwizard_candidates_get(/** Name of the candidate table */ table: string, options?: portal_reports_sqlwizard_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_reports_sqlwizard_tables_columns_get(/** Name of the filtered database table */ table: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterPropertyList>;
    portal_reports_tables_get(options?: portal_reports_tables_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_RPSReport_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** Predefined report */ UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_statistics_data_get(/** Statistic identifier */ id: string, options?: portal_statistics_data_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ListReportContentData>>;
    portal_statistics_data_datamodel_get(/** Statistic identifier */ id: string, options?: portal_statistics_data_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_statistics_data_group_get(/** Statistic identifier */ id: string, options?: portal_statistics_data_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_subscription_get(options?: portal_subscription_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_delete(/** Subscription */ UID_RPSSubscription: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_sendmail_post(/** Unique identifier of the subscription. */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_subscription_sendmailcc_post(/** Unique identifier of the subscription. */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_subscription_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_report_get(entityid: string, options?: portal_subscription_interactive_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<Blob>;
    portal_subscription_interactive_byid_get(/** Primary key value UID_RPSSubscription */ UID_RPSSubscription: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_parameter_candidates_post(/** Name of the parameter */ name: string, /** Name of the parent table of the foreign-key relation */ parenttable: string, inputParameterName: InteractiveEntityStateData, options?: portal_subscription_interactive_parameter_candidates_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_parameter_candidates_filtertree_post(/** Name of the parameter */ name: string, /** Name of the parent table of the foreign-key relation */ parenttable: string, inputParameterName: InteractiveEntityWriteData, options?: portal_subscription_interactive_parameter_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_subscription_interactive_UID_DialogSchedule_candidates_get(options?: portal_subscription_interactive_UID_DialogSchedule_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_subscription_interactive_UID_RPSReport_candidates_get(options?: portal_subscription_interactive_UID_RPSReport_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get(options?: portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns a list of candidate objects from the table Person. */
    portal_candidates_Person_get(options?: portal_candidates_Person_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/Person endpoint. */
    portal_candidates_Person_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_Person_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a data set corresponding to a subscribable report definition. */
    portal_report_data_get(/** Unique identifier of the report definition */ UID_RPSReport: string, options?: portal_report_data_get_args, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportContentData>>;
    /** Returns data model information about query options for the report/data/{UID_RPSReport} endpoint. */
    portal_report_data_datamodel_get(/** Unique identifier of the report definition */ UID_RPSReport: string, options?: portal_report_data_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns a data set corresponding to a subscribable report definition. */
    portal_report_data_group_get(/** Unique identifier of the report definition */ UID_RPSReport: string, options?: portal_report_data_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    /** Manages reports owned by the current user, or subscribable by the current user. */
    portal_reports_get(options?: portal_reports_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_get(options?: portal_reports_edit_get_args, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_delete(/** Predefined report */ UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportDefinitionRead>>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Manages reports owned by the current user. For report administrators, all reports are returned. */
    portal_reports_edit_interactive_byid_get(/** Primary key value UID_RPSReport */ UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfListReportDefinitionRead>;
    /** Returns a list of objects that can be assigned as a filter parameter. */
    portal_reports_sqlwizard_candidates_get(/** Name of the candidate table */ table: string, options?: portal_reports_sqlwizard_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns the filterable properties for the specified table. */
    portal_reports_sqlwizard_tables_columns_get(/** Name of the filtered database table */ table: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<FilterPropertyList>;
    portal_reports_tables_get(options?: portal_reports_tables_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_RPSReport_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_RPSReport_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** Predefined report */ UID_RPSReport: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/RPSReport/UID_RPSReport/candidates endpoint. */
    portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_RPSReport_UID_RPSReport_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a data set corresponding to a statistic definition. */
    portal_statistics_data_get(/** Statistic identifier */ id: string, options?: portal_statistics_data_get_args, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ListReportContentData>>;
    /** Returns data model information about query options for the statistics/data/{id} endpoint. */
    portal_statistics_data_datamodel_get(/** Statistic identifier */ id: string, options?: portal_statistics_data_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns a data set corresponding to a statistic definition. */
    portal_statistics_data_group_get(/** Statistic identifier */ id: string, options?: portal_statistics_data_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_subscription_get(options?: portal_subscription_get_args, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ParameterData[][]>>;
    portal_subscription_delete(/** Subscription */ UID_RPSSubscription: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<ParameterData[][]>>;
    /** Queues a job to e-mail the report to the subscriber. */
    portal_subscription_sendmail_post(/** Unique identifier of the subscription. */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Queues a job to send one e-mail for each CC subscriber of the subscription. */
    portal_subscription_sendmailcc_post(/** Unique identifier of the subscription. */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_subscription_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_delete(inputParameterName: InteractiveEntityDeleteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    portal_subscription_interactive_report_get(entityid: string, options?: portal_subscription_interactive_report_get_args, requestOptions?: ApiRequestOptions): Promise<Blob>;
    portal_subscription_interactive_byid_get(/** Primary key value UID_RPSSubscription */ UID_RPSSubscription: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ExtendedInteractiveEntityDataOfIReadOnlyListOfIReadOnlyListOfParameterData>;
    /** Returns a list of objects that can be assigned as a parameter value. */
    portal_subscription_interactive_parameter_candidates_post(/** Name of the parameter */ name: string, /** Name of the parent table of the foreign-key relation */ parenttable: string, inputParameterName: InteractiveEntityStateData, options?: portal_subscription_interactive_parameter_candidates_post_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the subscription/interactive/parameter/{name}/candidates/{parenttable} endpoint. */
    portal_subscription_interactive_parameter_candidates_filtertree_post(/** Name of the parameter */ name: string, /** Name of the parent table of the foreign-key relation */ parenttable: string, inputParameterName: InteractiveEntityWriteData, options?: portal_subscription_interactive_parameter_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_DialogSchedule. */
    portal_subscription_interactive_UID_DialogSchedule_candidates_get(options?: portal_subscription_interactive_UID_DialogSchedule_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the subscription/interactive/UID_DialogSchedule/candidates endpoint. */
    portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_subscription_interactive_UID_DialogSchedule_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_RPSReport. */
    portal_subscription_interactive_UID_RPSReport_candidates_get(options?: portal_subscription_interactive_UID_RPSReport_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get(options?: portal_subscription_interactive_UID_RPSReport_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the subscription/interactive/UID_RPSReport/candidates endpoint. */
    portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_subscription_interactive_UID_RPSReport_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
}
