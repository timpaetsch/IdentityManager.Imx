import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityWriteData, FilterData, FilterTreeData, FkProviderItem, InteractiveEntityData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
export interface AccProductOwnershipInput {
    UidPerson?: string;
    CopyAllMembers: boolean;
}
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityWriteDataOfAccProductOwnershipInput extends EntityWriteData {
    ExtendedData?: AccProductOwnershipInput;
}
export interface ExtendedInteractiveEntityWriteDataOfAccProductOwnershipInput extends InteractiveEntityWriteData {
    ExtendedData?: AccProductOwnershipInput;
}
export declare class TypedClient {
    readonly PortalResourcesApplicationServiceitem: PortalResourcesApplicationServiceitemWrapper;
    readonly PortalResourcesApplicationServiceitemInteractive: PortalResourcesApplicationServiceitemInteractiveWrapper;
    readonly PortalResourcesApplicationsMembership: PortalResourcesApplicationsMembershipWrapper;
    readonly PortalRespApplication: PortalRespApplicationWrapper;
    readonly PortalRespApplicationInteractive: PortalRespApplicationInteractiveWrapper;
    readonly PortalShopConfigEntitlementsApplication: PortalShopConfigEntitlementsApplicationWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalResourcesApplicationServiceitem extends WriteExtTypedEntity<AccProductOwnershipInput> {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalResourcesApplicationServiceitem type. */
export declare class PortalResourcesApplicationServiceitemInteractive extends PortalResourcesApplicationServiceitem {
}
export declare class PortalResourcesApplicationsMembership extends TypedEntity {
    readonly UID_Application: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XIsInEffect: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly UID_Person: IWriteValue<string>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Application' | 'XObjectKey' | 'XOrigin' | 'XDateInserted' | 'XIsInEffect' | 'XMarkedForDeletion' | 'UID_Person' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
/** @deprecated Use the PortalResourcesApplicationsMembership type. */
export declare class PortalResourcesApplicationsMembershipInteractive extends PortalResourcesApplicationsMembership {
}
export declare class PortalRespApplication extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'Requestable'>;
}
/** @deprecated Use the PortalRespApplication type. */
export declare class PortalRespApplicationInteractive extends PortalRespApplication {
}
export declare class PortalShopConfigEntitlementsApplication extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_Application: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_Application'>;
}
/** @deprecated Use the PortalShopConfigEntitlementsApplication type. */
export declare class PortalShopConfigEntitlementsApplicationInteractive extends PortalShopConfigEntitlementsApplication {
}
export declare class PortalResourcesApplicationServiceitemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_resources_application_serviceitem_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesApplicationServiceitem, unknown>>;
    Put(inputParameterName: PortalResourcesApplicationServiceitem, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesApplicationServiceitem, unknown>>;
}
export declare class PortalResourcesApplicationServiceitemInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalResourcesApplicationServiceitem, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesApplicationServiceitem, unknown>>;
    Get_byid(UID_AccProduct: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesApplicationServiceitem, unknown>>;
}
export declare class PortalResourcesApplicationsMembershipWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalResourcesApplicationsMembership;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_Application: string, parametersOptional?: portal_resources_applications_membership_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesApplicationsMembership, unknown>>;
    Post(UID_Application: string, inputParameterName: PortalResourcesApplicationsMembership, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesApplicationsMembership, unknown>>;
    Delete(UID_Application: string, UID_Person: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalResourcesApplicationsMembership, unknown>>;
}
export declare class PortalRespApplicationWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_resp_application_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespApplication, unknown>>;
}
export declare class PortalRespApplicationInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespApplication, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespApplication, unknown>>;
    Get_byid(UID_Application: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespApplication, unknown>>;
}
export declare class PortalShopConfigEntitlementsApplicationWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsApplication;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: portal_shop_config_entitlements_Application_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsApplication, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsApplication, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsApplication, unknown>>;
    Delete(UID_ITShopOrg: string, UID_Application: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsApplication, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_resources_application_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_application_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): MethodDescriptor<EntityCollectionData>;
    portal_resources_application_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_resources_application_serviceitem_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resources_application_serviceitem_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_resources_application_serviceitem_interactive_byid_get(UID_AccProduct: string): MethodDescriptor<InteractiveEntityData>;
    portal_resources_applications_membership_get(UID_Application: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_applications_membership_post(UID_Application: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_resources_applications_membership_delete(UID_Application: string, UID_Person: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_applications_membership_UID_Person_candidates_get(UID_Application: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resources_applications_membership_UID_Person_candidates_filtertree_post(UID_Application: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_resp_application_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_application_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_application_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_resp_application_interactive_byid_get(UID_Application: string): MethodDescriptor<InteractiveEntityData>;
    portal_shop_config_entitlements_Application_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_Application_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_Application_delete(UID_ITShopOrg: string, UID_Application: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_Application_UID_Application_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_resources_application_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resources_application_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resources_application_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the resources/application/serviceitem endpoint. */
    portal_resources_application_serviceitem_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resources_application_serviceitem_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resources_application_serviceitem_interactive_byid_get(UID_AccProduct: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resources_applications_membership_get(UID_Application: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resources_applications_membership_post(UID_Application: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resources_applications_membership_delete(UID_Application: string, UID_Person: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_resources_applications_membership_UID_Person_candidates_get(UID_Application: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the resources/applications/membership/{UID_Application}/UID_Person/candidates endpoint. */
    portal_resources_applications_membership_UID_Person_candidates_filtertree_post(UID_Application: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_resp_application_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/application endpoint. */
    portal_resp_application_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_application_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_application_interactive_byid_get(UID_Application: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_shop_config_entitlements_Application_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_Application_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_Application_delete(UID_ITShopOrg: string, UID_Application: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Application. */
    portal_shop_config_entitlements_Application_UID_Application_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates endpoint. */
    portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates endpoint. */
    portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
}
export interface portal_resources_application_serviceitem_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_resources_application_serviceitem_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_resources_applications_membership_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_resources_applications_membership_UID_Person_candidates_get_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_resources_applications_membership_UID_Person_candidates_filtertree_post_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_resp_application_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable software */ published?: string;
}
export interface portal_resp_application_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_Application_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_Application_UID_Application_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export declare class V2ApiClientMethodFactory {
    portal_resources_application_serviceitem_get(options?: portal_resources_application_serviceitem_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resources_application_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resources_application_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_resources_application_serviceitem_datamodel_get(options?: portal_resources_application_serviceitem_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_resources_application_serviceitem_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resources_application_serviceitem_interactive_byid_get(/** Primary key value UID_AccProduct */ UID_AccProduct: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resources_applications_membership_get(/** Unique identifier of the application */ UID_Application: string, options?: portal_resources_applications_membership_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resources_applications_membership_post(/** Unique identifier of the application */ UID_Application: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resources_applications_membership_delete(/** Unique identifier of the application */ UID_Application: string, /** Identity */ UID_Person: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resources_applications_membership_UID_Person_candidates_get(/** Unique identifier of the application */ UID_Application: string, options?: portal_resources_applications_membership_UID_Person_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resources_applications_membership_UID_Person_candidates_filtertree_post(/** Unique identifier of the application */ UID_Application: string, inputParameterName: EntityWriteDataSingle, options?: portal_resources_applications_membership_UID_Person_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_resp_application_get(options?: portal_resp_application_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_application_datamodel_get(options?: portal_resp_application_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_resp_application_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_application_interactive_byid_get(/** Primary key value UID_Application */ UID_Application: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_shop_config_entitlements_Application_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_Application_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_Application_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_Application_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** Software */ UID_Application: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_Application_UID_Application_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_Application_UID_Application_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_resources_application_serviceitem_get(options?: portal_resources_application_serviceitem_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resources_application_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resources_application_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the resources/application/serviceitem endpoint. */
    portal_resources_application_serviceitem_datamodel_get(options?: portal_resources_application_serviceitem_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resources_application_serviceitem_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resources_application_serviceitem_interactive_byid_get(/** Primary key value UID_AccProduct */ UID_AccProduct: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resources_applications_membership_get(/** Unique identifier of the application */ UID_Application: string, options?: portal_resources_applications_membership_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resources_applications_membership_post(/** Unique identifier of the application */ UID_Application: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resources_applications_membership_delete(/** Unique identifier of the application */ UID_Application: string, /** Identity */ UID_Person: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    portal_resources_applications_membership_UID_Person_candidates_get(/** Unique identifier of the application */ UID_Application: string, options?: portal_resources_applications_membership_UID_Person_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the resources/applications/membership/{UID_Application}/UID_Person/candidates endpoint. */
    portal_resources_applications_membership_UID_Person_candidates_filtertree_post(/** Unique identifier of the application */ UID_Application: string, inputParameterName: EntityWriteDataSingle, options?: portal_resources_applications_membership_UID_Person_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_resp_application_get(options?: portal_resp_application_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/application endpoint. */
    portal_resp_application_datamodel_get(options?: portal_resp_application_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_application_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_application_interactive_byid_get(/** Primary key value UID_Application */ UID_Application: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_shop_config_entitlements_Application_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_Application_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_Application_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_Application_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** Software */ UID_Application: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_Application. */
    portal_shop_config_entitlements_Application_UID_Application_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_Application_UID_Application_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates endpoint. */
    portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates endpoint. */
    portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
}
