import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityWriteData, FilterData, FilterTreeData, FkProviderItem, InteractiveEntityData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityWriteDataOfGroupExtendedData extends EntityWriteData {
    ExtendedData?: GroupExtendedData;
}
export interface ExtendedInteractiveEntityWriteDataOfGroupExtendedData extends InteractiveEntityWriteData {
    ExtendedData?: GroupExtendedData;
}
export interface GroupExtendedData {
    CreateServiceItem: boolean;
}
export declare class TypedClient {
    readonly PortalAaddirectoryroleMemberships: PortalAaddirectoryroleMembershipsWrapper;
    readonly PortalAadgroupMemberships: PortalAadgroupMembershipsWrapper;
    readonly PortalAadscopedrlasgnMemberships: PortalAadscopedrlasgnMembershipsWrapper;
    readonly PortalAadscopedrlelgbMemberships: PortalAadscopedrlelgbMembershipsWrapper;
    readonly PortalAadsubskuMemberships: PortalAadsubskuMembershipsWrapper;
    readonly PortalShopConfigEntitlementsAaddeniedserviceplan: PortalShopConfigEntitlementsAaddeniedserviceplanWrapper;
    readonly PortalTargetsystemAaddirectoryrole: PortalTargetsystemAaddirectoryroleWrapper;
    readonly PortalTargetsystemAaddirectoryroleInteractive: PortalTargetsystemAaddirectoryroleInteractiveWrapper;
    readonly PortalTargetsystemAadgroup: PortalTargetsystemAadgroupWrapper;
    readonly PortalTargetsystemAadgroupChildren: PortalTargetsystemAadgroupChildrenWrapper;
    readonly PortalTargetsystemAadgroupDeniedserviceplans: PortalTargetsystemAadgroupDeniedserviceplansWrapper;
    readonly PortalTargetsystemAadgroupInteractive: PortalTargetsystemAadgroupInteractiveWrapper;
    readonly PortalTargetsystemAadgroupSubsku: PortalTargetsystemAadgroupSubskuWrapper;
    readonly PortalTargetsystemAadscopedrlasgn: PortalTargetsystemAadscopedrlasgnWrapper;
    readonly PortalTargetsystemAadscopedrlasgnInteractive: PortalTargetsystemAadscopedrlasgnInteractiveWrapper;
    readonly PortalTargetsystemAadscopedrlelgb: PortalTargetsystemAadscopedrlelgbWrapper;
    readonly PortalTargetsystemAadscopedrlelgbInteractive: PortalTargetsystemAadscopedrlelgbInteractiveWrapper;
    readonly PortalTargetsystemAadsubsku: PortalTargetsystemAadsubskuWrapper;
    readonly PortalTargetsystemAadsubskuInteractive: PortalTargetsystemAadsubskuInteractiveWrapper;
    readonly PortalTargetsystemAaduser: PortalTargetsystemAaduserWrapper;
    readonly PortalTargetsystemAaduserDeniedserviceplans: PortalTargetsystemAaduserDeniedserviceplansWrapper;
    readonly PortalTargetsystemAaduserInteractive: PortalTargetsystemAaduserInteractiveWrapper;
    readonly PortalTargetsystemAaduserSubsku: PortalTargetsystemAaduserSubskuWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalAaddirectoryroleMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalAaddirectoryroleMemberships type. */
export declare class PortalAaddirectoryroleMembershipsInteractive extends PortalAaddirectoryroleMemberships {
}
export declare class PortalAadgroupMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalAadgroupMemberships type. */
export declare class PortalAadgroupMembershipsInteractive extends PortalAadgroupMemberships {
}
export declare class PortalAadscopedrlasgnMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalAadscopedrlasgnMemberships type. */
export declare class PortalAadscopedrlasgnMembershipsInteractive extends PortalAadscopedrlasgnMemberships {
}
export declare class PortalAadscopedrlelgbMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalAadscopedrlelgbMemberships type. */
export declare class PortalAadscopedrlelgbMembershipsInteractive extends PortalAadscopedrlelgbMemberships {
}
export declare class PortalAadsubskuMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalAadsubskuMemberships type. */
export declare class PortalAadsubskuMembershipsInteractive extends PortalAadsubskuMemberships {
}
export declare class PortalShopConfigEntitlementsAaddeniedserviceplan extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_AADDeniedServicePlan: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_AADDeniedServicePlan'>;
}
/** @deprecated Use the PortalShopConfigEntitlementsAaddeniedserviceplan type. */
export declare class PortalShopConfigEntitlementsAaddeniedserviceplanInteractive extends PortalShopConfigEntitlementsAaddeniedserviceplan {
}
export declare class PortalTargetsystemAaddirectoryrole extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemAaddirectoryrole type. */
export declare class PortalTargetsystemAaddirectoryroleInteractive extends PortalTargetsystemAaddirectoryrole {
}
export declare class PortalTargetsystemAadgroup extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly HasReadOnlyMemberships: IReadValue<boolean>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'HasReadOnlyMemberships' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemAadgroup type. */
export declare class PortalTargetsystemAadgroupInteractive extends PortalTargetsystemAadgroup {
}
export declare class PortalTargetsystemAadgroupChildren extends TypedEntity {
    readonly UID_AADGroupContainer: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_AADGroupMember: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AADGroupContainer' | 'XObjectKey' | 'XMarkedForDeletion' | 'XDateInserted' | 'UID_AADGroupMember'>;
}
/** @deprecated Use the PortalTargetsystemAadgroupChildren type. */
export declare class PortalTargetsystemAadgroupChildrenInteractive extends PortalTargetsystemAadgroupChildren {
}
export declare class PortalTargetsystemAadgroupDeniedserviceplans extends TypedEntity {
    readonly UID_AADGroup: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XOrigin: IReadValue<number>;
    readonly UID_AADDeniedServicePlan: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AADGroup' | 'XObjectKey' | 'XMarkedForDeletion' | 'XDateInserted' | 'XOrigin' | 'UID_AADDeniedServicePlan'>;
}
/** @deprecated Use the PortalTargetsystemAadgroupDeniedserviceplans type. */
export declare class PortalTargetsystemAadgroupDeniedserviceplansInteractive extends PortalTargetsystemAadgroupDeniedserviceplans {
}
export declare class PortalTargetsystemAadgroupSubsku extends TypedEntity {
    readonly UID_AADGroup: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XOrigin: IReadValue<number>;
    readonly UID_AADSubSku: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AADGroup' | 'XObjectKey' | 'XMarkedForDeletion' | 'XDateInserted' | 'XOrigin' | 'UID_AADSubSku'>;
}
/** @deprecated Use the PortalTargetsystemAadgroupSubsku type. */
export declare class PortalTargetsystemAadgroupSubskuInteractive extends PortalTargetsystemAadgroupSubsku {
}
export declare class PortalTargetsystemAadscopedrlasgn extends WriteExtTypedEntity<GroupExtendedData> {
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemAadscopedrlasgn type. */
export declare class PortalTargetsystemAadscopedrlasgnInteractive extends PortalTargetsystemAadscopedrlasgn {
}
export declare class PortalTargetsystemAadscopedrlelgb extends WriteExtTypedEntity<GroupExtendedData> {
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemAadscopedrlelgb type. */
export declare class PortalTargetsystemAadscopedrlelgbInteractive extends PortalTargetsystemAadscopedrlelgb {
}
export declare class PortalTargetsystemAadsubsku extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemAadsubsku type. */
export declare class PortalTargetsystemAadsubskuInteractive extends PortalTargetsystemAadsubsku {
}
export declare class PortalTargetsystemAaduser extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalTargetsystemAaduser type. */
export declare class PortalTargetsystemAaduserInteractive extends PortalTargetsystemAaduser {
}
export declare class PortalTargetsystemAaduserDeniedserviceplans extends TypedEntity {
    readonly UID_AADUser: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XOrigin: IReadValue<number>;
    readonly UID_AADDeniedServicePlan: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AADUser' | 'XObjectKey' | 'XMarkedForDeletion' | 'XDateInserted' | 'XOrigin' | 'UID_AADDeniedServicePlan'>;
}
/** @deprecated Use the PortalTargetsystemAaduserDeniedserviceplans type. */
export declare class PortalTargetsystemAaduserDeniedserviceplansInteractive extends PortalTargetsystemAaduserDeniedserviceplans {
}
export declare class PortalTargetsystemAaduserSubsku extends TypedEntity {
    readonly UID_AADUser: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XOrigin: IReadValue<number>;
    readonly ObjectKeyAADSubSku: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AADUser' | 'XObjectKey' | 'XMarkedForDeletion' | 'XDateInserted' | 'XOrigin' | 'ObjectKeyAADSubSku'>;
}
/** @deprecated Use the PortalTargetsystemAaduserSubsku type. */
export declare class PortalTargetsystemAaduserSubskuInteractive extends PortalTargetsystemAaduserSubsku {
}
export declare class PortalAaddirectoryroleMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAaddirectoryroleMemberships, unknown>>;
}
export declare class PortalAadgroupMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAadgroupMemberships, unknown>>;
}
export declare class PortalAadscopedrlasgnMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAadscopedrlasgnMemberships, unknown>>;
}
export declare class PortalAadscopedrlelgbMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAadscopedrlelgbMemberships, unknown>>;
}
export declare class PortalAadsubskuMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalAadsubskuMemberships, unknown>>;
}
export declare class PortalShopConfigEntitlementsAaddeniedserviceplanWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsAaddeniedserviceplan;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: portal_shop_config_entitlements_AADDeniedServicePlan_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsAaddeniedserviceplan, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsAaddeniedserviceplan, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsAaddeniedserviceplan, unknown>>;
    Delete(UID_ITShopOrg: string, UID_AADDeniedServicePlan: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsAaddeniedserviceplan, unknown>>;
}
export declare class PortalTargetsystemAaddirectoryroleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_aaddirectoryrole_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaddirectoryrole, unknown>>;
    Put(inputParameterName: PortalTargetsystemAaddirectoryrole, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaddirectoryrole, unknown>>;
}
export declare class PortalTargetsystemAaddirectoryroleInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemAaddirectoryrole, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaddirectoryrole, unknown>>;
    Get_byid(UID_AADDirectoryRole: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaddirectoryrole, unknown>>;
}
export declare class PortalTargetsystemAadgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_aadgroup_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroup, unknown>>;
    Put(inputParameterName: PortalTargetsystemAadgroup, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroup, unknown>>;
}
export declare class PortalTargetsystemAadgroupChildrenWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalTargetsystemAadgroupChildren;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AADGroupContainer: string, parametersOptional?: portal_targetsystem_aadgroup_children_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupChildren, unknown>>;
    Post(UID_AADGroupContainer: string, inputParameterName: PortalTargetsystemAadgroupChildren, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupChildren, unknown>>;
    Delete(UID_AADGroupContainer: string, UID_AADGroupMember: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupChildren, unknown>>;
}
export declare class PortalTargetsystemAadgroupDeniedserviceplansWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalTargetsystemAadgroupDeniedserviceplans;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AADGroup: string, parametersOptional?: portal_targetsystem_aadgroup_deniedserviceplans_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupDeniedserviceplans, unknown>>;
    Put(UID_AADGroup: string, inputParameterName: PortalTargetsystemAadgroupDeniedserviceplans, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupDeniedserviceplans, unknown>>;
    Post(UID_AADGroup: string, inputParameterName: PortalTargetsystemAadgroupDeniedserviceplans, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupDeniedserviceplans, unknown>>;
    Delete(UID_AADGroup: string, UID_AADDeniedServicePlan: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupDeniedserviceplans, unknown>>;
}
export declare class PortalTargetsystemAadgroupInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemAadgroup, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroup, unknown>>;
    Get_byid(UID_AADGroup: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroup, unknown>>;
}
export declare class PortalTargetsystemAadgroupSubskuWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalTargetsystemAadgroupSubsku;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AADGroup: string, parametersOptional?: portal_targetsystem_aadgroup_subsku_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupSubsku, unknown>>;
    Put(UID_AADGroup: string, inputParameterName: PortalTargetsystemAadgroupSubsku, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupSubsku, unknown>>;
    Post(UID_AADGroup: string, inputParameterName: PortalTargetsystemAadgroupSubsku, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupSubsku, unknown>>;
    Delete(UID_AADGroup: string, UID_AADSubSku: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadgroupSubsku, unknown>>;
}
export declare class PortalTargetsystemAadscopedrlasgnWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_aadscopedrlasgn_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadscopedrlasgn, unknown>>;
    Put(inputParameterName: PortalTargetsystemAadscopedrlasgn, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadscopedrlasgn, unknown>>;
}
export declare class PortalTargetsystemAadscopedrlasgnInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemAadscopedrlasgn, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadscopedrlasgn, unknown>>;
    Get_byid(UID_AADScopedRLAsgn: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadscopedrlasgn, unknown>>;
}
export declare class PortalTargetsystemAadscopedrlelgbWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_aadscopedrlelgb_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadscopedrlelgb, unknown>>;
    Put(inputParameterName: PortalTargetsystemAadscopedrlelgb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadscopedrlelgb, unknown>>;
}
export declare class PortalTargetsystemAadscopedrlelgbInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemAadscopedrlelgb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadscopedrlelgb, unknown>>;
    Get_byid(UID_AADScopedRLElgb: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadscopedrlelgb, unknown>>;
}
export declare class PortalTargetsystemAadsubskuWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_aadsubsku_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadsubsku, unknown>>;
    Put(inputParameterName: PortalTargetsystemAadsubsku, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadsubsku, unknown>>;
}
export declare class PortalTargetsystemAadsubskuInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemAadsubsku, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadsubsku, unknown>>;
    Get_byid(UID_AADSubSku: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAadsubsku, unknown>>;
}
export declare class PortalTargetsystemAaduserWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_aaduser_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduser, unknown>>;
    Put(inputParameterName: PortalTargetsystemAaduser, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduser, unknown>>;
}
export declare class PortalTargetsystemAaduserDeniedserviceplansWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalTargetsystemAaduserDeniedserviceplans;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AADUser: string, parametersOptional?: portal_targetsystem_aaduser_deniedserviceplans_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserDeniedserviceplans, unknown>>;
    Put(UID_AADUser: string, inputParameterName: PortalTargetsystemAaduserDeniedserviceplans, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserDeniedserviceplans, unknown>>;
    Post(UID_AADUser: string, inputParameterName: PortalTargetsystemAaduserDeniedserviceplans, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserDeniedserviceplans, unknown>>;
    Delete(UID_AADUser: string, UID_AADDeniedServicePlan: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserDeniedserviceplans, unknown>>;
}
export declare class PortalTargetsystemAaduserInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemAaduser, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduser, unknown>>;
    Get_byid(UID_AADUser: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduser, unknown>>;
}
export declare class PortalTargetsystemAaduserSubskuWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalTargetsystemAaduserSubsku;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_AADUser: string, parametersOptional?: portal_targetsystem_aaduser_subsku_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserSubsku, unknown>>;
    Put(UID_AADUser: string, inputParameterName: PortalTargetsystemAaduserSubsku, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserSubsku, unknown>>;
    Post(UID_AADUser: string, inputParameterName: PortalTargetsystemAaduserSubsku, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserSubsku, unknown>>;
    Delete(UID_AADUser: string, UID_AADUserHasSubSku: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemAaduserSubsku, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_AADDirectoryRole_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_AADDirectoryRole_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_AADGroup_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_AADGroup_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_AADScopedRLAsgn_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_AADScopedRLAsgn_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_AADScopedRLElgb_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_AADScopedRLElgb_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_AADSubSku_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_AADSubSku_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg: string, UID_AADDeniedServicePlan: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aaddirectoryrole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaddirectoryrole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaddirectoryrole_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aaddirectoryrole_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aaddirectoryrole_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aaddirectoryrole_interactive_byid_get(UID_AADDirectoryRole: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadgroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup: string, UID_AADDeniedServicePlan: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADGroup: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADGroup: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADGroup: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadgroup_subsku_get(UID_AADGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_put(UID_AADGroup: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_post(UID_AADGroup: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup: string, UID_AADSubSku: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(UID_AADGroup: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(UID_AADGroup: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(UID_AADGroup: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadgroup_children_get(UID_AADGroupContainer: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_post(UID_AADGroupContainer: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_delete(UID_AADGroupContainer: string, UID_AADGroupMember: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get(UID_AADGroupContainer: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get(UID_AADGroupContainer: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post(UID_AADGroupContainer: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadgroup_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aadgroup_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadgroup_interactive_byid_get(UID_AADGroup: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlasgn_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadscopedrlasgn_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadscopedrlasgn_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aadscopedrlasgn_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aadscopedrlasgn_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlasgn_interactive_byid_get(UID_AADScopedRLAsgn: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlelgb_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadscopedrlelgb_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadscopedrlelgb_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aadscopedrlelgb_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aadscopedrlelgb_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlelgb_interactive_byid_get(UID_AADScopedRLElgb: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadsubsku_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadsubsku_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku: string): MethodDescriptor<void>;
    portal_targetsystem_aadsubsku_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aadsubsku_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aadsubsku_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadsubsku_interactive_byid_get(UID_AADSubSku: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aaduser_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser: string, UID_AADDeniedServicePlan: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADUser: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADUser: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADUser: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aaduser_subsku_get(UID_AADUser: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_put(UID_AADUser: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_post(UID_AADUser: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_delete(UID_AADUser: string, UID_AADUserHasSubSku: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(UID_AADUser: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(UID_AADUser: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(UID_AADUser: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aaduser_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_aaduser_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_aaduser_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aaduser_interactive_byid_get(UID_AADUser: string): MethodDescriptor<InteractiveEntityData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_AADDirectoryRole_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADDirectoryRole_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_AADGroup_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADGroup_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_AADScopedRLAsgn_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADScopedRLAsgn_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_AADScopedRLElgb_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADScopedRLElgb_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_AADSubSku_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADSubSku_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg: string, UID_AADDeniedServicePlan: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADDirectoryRole. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADGroup. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aaddirectoryrole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaddirectoryrole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaddirectoryrole_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aaddirectoryrole endpoint. */
    portal_targetsystem_aaddirectoryrole_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aaddirectoryrole_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aaddirectoryrole_interactive_byid_get(UID_AADDirectoryRole: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadgroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup: string, UID_AADDeniedServicePlan: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADGroup: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADGroup: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADGroup: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aadgroup_subsku_get(UID_AADGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_put(UID_AADGroup: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_post(UID_AADGroup: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup: string, UID_AADSubSku: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_bulk_put(UID_AADGroup: string, inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(UID_AADGroup: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(UID_AADGroup: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(UID_AADGroup: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aadgroup_children_get(UID_AADGroupContainer: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_post(UID_AADGroupContainer: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_delete(UID_AADGroupContainer: string, UID_AADGroupMember: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_AADGroupMember. */
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get(UID_AADGroupContainer: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates endpoint. */
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get(UID_AADGroupContainer: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates endpoint. */
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post(UID_AADGroupContainer: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aadgroup_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aadgroup endpoint. */
    portal_targetsystem_aadgroup_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aadgroup_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadgroup_interactive_byid_get(UID_AADGroup: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlasgn_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadscopedrlasgn_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadscopedrlasgn_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aadscopedrlasgn endpoint. */
    portal_targetsystem_aadscopedrlasgn_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aadscopedrlasgn_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlasgn_interactive_byid_get(UID_AADScopedRLAsgn: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlelgb_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadscopedrlelgb_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadscopedrlelgb_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aadscopedrlelgb endpoint. */
    portal_targetsystem_aadscopedrlelgb_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aadscopedrlelgb_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlelgb_interactive_byid_get(UID_AADScopedRLElgb: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadsubsku_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadsubsku_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_targetsystem_aadsubsku_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aadsubsku endpoint. */
    portal_targetsystem_aadsubsku_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aadsubsku_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadsubsku_interactive_byid_get(UID_AADSubSku: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aaduser_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser: string, UID_AADDeniedServicePlan: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADUser: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADUser: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADUser: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aaduser_subsku_get(UID_AADUser: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_put(UID_AADUser: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_post(UID_AADUser: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_delete(UID_AADUser: string, UID_AADUserHasSubSku: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_bulk_put(UID_AADUser: string, inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property ObjectKeyAADSubSku. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(UID_AADUser: string, xorigin: number, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(UID_AADUser: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(UID_AADUser: string, xorigin: number, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aaduser_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aaduser endpoint. */
    portal_targetsystem_aaduser_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aaduser_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aaduser_interactive_byid_get(UID_AADUser: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
}
export interface portal_shop_config_entitlements_AADDeniedServicePlan_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_aaddirectoryrole_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_aaddirectoryrole_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_aadgroup_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_aadgroup_deniedserviceplans_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_aadgroup_subsku_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_aadgroup_children_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_aadgroup_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_aadscopedrlasgn_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_aadscopedrlasgn_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_aadscopedrlelgb_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_aadscopedrlelgb_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_aadsubsku_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_aadsubsku_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_aaduser_get_args {
    /** Filters accounts for main and sub identities associated with the specified identity */ UID_PersonAssociated?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters orphaned accounts */ orphaned?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_aaduser_deniedserviceplans_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_aaduser_subsku_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post_args {
    /** Filter candidates by assignment flag */ xorigin?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_aaduser_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export declare class V2ApiClientMethodFactory {
    portal_AADDirectoryRole_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_AADDirectoryRole_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_AADGroup_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_AADGroup_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_AADScopedRLAsgn_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_AADScopedRLAsgn_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_AADScopedRLElgb_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_AADScopedRLElgb_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_AADSubSku_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_AADSubSku_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_shop_config_entitlements_AADDeniedServicePlan_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADDeniedServicePlan_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aaddirectoryrole_get(options?: portal_targetsystem_aaddirectoryrole_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaddirectoryrole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaddirectoryrole_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aaddirectoryrole_datamodel_get(options?: portal_targetsystem_aaddirectoryrole_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aaddirectoryrole_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aaddirectoryrole_interactive_byid_get(/** Primary key value UID_AADDirectoryRole */ UID_AADDirectoryRole: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadgroup_get(options?: portal_targetsystem_aadgroup_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_deniedserviceplans_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_put(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_post(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_delete(/** Unique identifier of the base object */ UID_AADGroup: string, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadgroup_subsku_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_subsku_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_put(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_post(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_delete(/** Unique identifier of the base object */ UID_AADGroup: string, /** Azure Active Directory subscription */ UID_AADSubSku: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_bulk_put(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadgroup_children_get(/** Unique identifier of the base object */ UID_AADGroupContainer: string, options?: portal_targetsystem_aadgroup_children_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_post(/** Unique identifier of the base object */ UID_AADGroupContainer: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_delete(/** Unique identifier of the base object */ UID_AADGroupContainer: string, /** Member group */ UID_AADGroupMember: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get(/** Unique identifier of the base object */ UID_AADGroupContainer: string, options?: portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get(/** Unique identifier of the base object */ UID_AADGroupContainer: string, options?: portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post(/** Unique identifier of the base object */ UID_AADGroupContainer: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aadgroup_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aadgroup_datamodel_get(options?: portal_targetsystem_aadgroup_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aadgroup_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadgroup_interactive_byid_get(/** Primary key value UID_AADGroup */ UID_AADGroup: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlasgn_get(options?: portal_targetsystem_aadscopedrlasgn_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadscopedrlasgn_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadscopedrlasgn_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aadscopedrlasgn_datamodel_get(options?: portal_targetsystem_aadscopedrlasgn_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aadscopedrlasgn_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlasgn_interactive_byid_get(/** Primary key value UID_AADScopedRLAsgn */ UID_AADScopedRLAsgn: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlelgb_get(options?: portal_targetsystem_aadscopedrlelgb_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadscopedrlelgb_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadscopedrlelgb_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aadscopedrlelgb_datamodel_get(options?: portal_targetsystem_aadscopedrlelgb_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aadscopedrlelgb_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlelgb_interactive_byid_get(/** Primary key value UID_AADScopedRLElgb */ UID_AADScopedRLElgb: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadsubsku_get(options?: portal_targetsystem_aadsubsku_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadsubsku_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aadsubsku_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aadsubsku_datamodel_get(options?: portal_targetsystem_aadsubsku_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aadsubsku_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aadsubsku_interactive_byid_get(/** Primary key value UID_AADSubSku */ UID_AADSubSku: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aaduser_get(options?: portal_targetsystem_aaduser_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_deniedserviceplans_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_put(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_post(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_delete(/** Unique identifier of the base object */ UID_AADUser: string, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_bulk_put(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aaduser_subsku_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_subsku_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_put(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_post(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_delete(/** Unique identifier of the base object */ UID_AADUser: string, /** Subscription assignment */ UID_AADUserHasSubSku: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_bulk_put(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_aaduser_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_aaduser_datamodel_get(options?: portal_targetsystem_aaduser_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_aaduser_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_aaduser_interactive_byid_get(/** Primary key value UID_AADUser */ UID_AADUser: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_AADDirectoryRole_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADDirectoryRole_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_AADGroup_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADGroup_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_AADScopedRLAsgn_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADScopedRLAsgn_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_AADScopedRLElgb_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADScopedRLElgb_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_AADSubSku_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_AADSubSku_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_shop_config_entitlements_AADDeniedServicePlan_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADDeniedServicePlan_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_AADDeniedServicePlan_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADDirectoryRole. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADGroup. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aaddirectoryrole_get(options?: portal_targetsystem_aaddirectoryrole_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaddirectoryrole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaddirectoryrole_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aaddirectoryrole endpoint. */
    portal_targetsystem_aaddirectoryrole_datamodel_get(options?: portal_targetsystem_aaddirectoryrole_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aaddirectoryrole_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aaddirectoryrole_interactive_byid_get(/** Primary key value UID_AADDirectoryRole */ UID_AADDirectoryRole: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadgroup_get(options?: portal_targetsystem_aadgroup_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_deniedserviceplans_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_put(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_post(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_delete(/** Unique identifier of the base object */ UID_AADGroup: string, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aadgroup_subsku_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_subsku_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_put(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_post(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_delete(/** Unique identifier of the base object */ UID_AADGroup: string, /** Azure Active Directory subscription */ UID_AADSubSku: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_subsku_bulk_put(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(/** Unique identifier of the base object */ UID_AADGroup: string, options?: portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(/** Unique identifier of the base object */ UID_AADGroup: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aadgroup_children_get(/** Unique identifier of the base object */ UID_AADGroupContainer: string, options?: portal_targetsystem_aadgroup_children_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_post(/** Unique identifier of the base object */ UID_AADGroupContainer: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadgroup_children_delete(/** Unique identifier of the base object */ UID_AADGroupContainer: string, /** Member group */ UID_AADGroupMember: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_AADGroupMember. */
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get(/** Unique identifier of the base object */ UID_AADGroupContainer: string, options?: portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates endpoint. */
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get(/** Unique identifier of the base object */ UID_AADGroupContainer: string, options?: portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates endpoint. */
    portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post(/** Unique identifier of the base object */ UID_AADGroupContainer: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aadgroup_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aadgroup endpoint. */
    portal_targetsystem_aadgroup_datamodel_get(options?: portal_targetsystem_aadgroup_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aadgroup_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadgroup_interactive_byid_get(/** Primary key value UID_AADGroup */ UID_AADGroup: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlasgn_get(options?: portal_targetsystem_aadscopedrlasgn_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadscopedrlasgn_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadscopedrlasgn_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aadscopedrlasgn endpoint. */
    portal_targetsystem_aadscopedrlasgn_datamodel_get(options?: portal_targetsystem_aadscopedrlasgn_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aadscopedrlasgn_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlasgn_interactive_byid_get(/** Primary key value UID_AADScopedRLAsgn */ UID_AADScopedRLAsgn: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlelgb_get(options?: portal_targetsystem_aadscopedrlelgb_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadscopedrlelgb_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadscopedrlelgb_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aadscopedrlelgb endpoint. */
    portal_targetsystem_aadscopedrlelgb_datamodel_get(options?: portal_targetsystem_aadscopedrlelgb_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aadscopedrlelgb_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadscopedrlelgb_interactive_byid_get(/** Primary key value UID_AADScopedRLElgb */ UID_AADScopedRLElgb: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadsubsku_get(options?: portal_targetsystem_aadsubsku_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadsubsku_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_targetsystem_aadsubsku_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aadsubsku endpoint. */
    portal_targetsystem_aadsubsku_datamodel_get(options?: portal_targetsystem_aadsubsku_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aadsubsku_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aadsubsku_interactive_byid_get(/** Primary key value UID_AADSubSku */ UID_AADSubSku: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aaduser_get(options?: portal_targetsystem_aaduser_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_deniedserviceplans_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_put(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_post(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_delete(/** Unique identifier of the base object */ UID_AADUser: string, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_deniedserviceplans_bulk_put(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aaduser_subsku_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_subsku_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_put(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_post(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_delete(/** Unique identifier of the base object */ UID_AADUser: string, /** Subscription assignment */ UID_AADUserHasSubSku: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_aaduser_subsku_bulk_put(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns a list of objects that can be assigned to the property ObjectKeyAADSubSku. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(/** Unique identifier of the base object */ UID_AADUser: string, options?: portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(/** Unique identifier of the base object */ UID_AADUser: string, inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_aaduser_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/aaduser endpoint. */
    portal_targetsystem_aaduser_datamodel_get(options?: portal_targetsystem_aaduser_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_aaduser_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_aaduser_interactive_byid_get(/** Primary key value UID_AADUser */ UID_AADUser: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
}
