(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.PortalCandidatesAccproductgroup = new PortalCandidatesAccproductgroupWrapper(client, translationProvider);
            this.PortalCandidatesAccproductparamcategory = new PortalCandidatesAccproductparamcategoryWrapper(client, translationProvider);
            this.PortalClaimgroupGroup = new PortalClaimgroupGroupWrapper(client, translationProvider);
            this.PortalClaimgroupSuggestedowner = new PortalClaimgroupSuggestedownerWrapper(client, translationProvider);
            this.PortalClaimgroupSuggestedowner2 = new PortalClaimgroupSuggestedowner2Wrapper(client, translationProvider);
            this.PortalPersonAccounts = new PortalPersonAccountsWrapper(client, translationProvider);
            this.PortalPersonGroupmemberships = new PortalPersonGroupmembershipsWrapper(client, translationProvider);
            this.PortalRespUnsgroup = new PortalRespUnsgroupWrapper(client, translationProvider);
            this.PortalRespUnsgroupb = new PortalRespUnsgroupbWrapper(client, translationProvider);
            this.PortalRespUnsgroupb1 = new PortalRespUnsgroupb1Wrapper(client, translationProvider);
            this.PortalRespUnsgroupb1Interactive = new PortalRespUnsgroupb1InteractiveWrapper(client, translationProvider);
            this.PortalRespUnsgroupb2 = new PortalRespUnsgroupb2Wrapper(client, translationProvider);
            this.PortalRespUnsgroupb2Interactive = new PortalRespUnsgroupb2InteractiveWrapper(client, translationProvider);
            this.PortalRespUnsgroupb3 = new PortalRespUnsgroupb3Wrapper(client, translationProvider);
            this.PortalRespUnsgroupb3Interactive = new PortalRespUnsgroupb3InteractiveWrapper(client, translationProvider);
            this.PortalRespUnsgroupbInteractive = new PortalRespUnsgroupbInteractiveWrapper(client, translationProvider);
            this.PortalShopConfigEntitlementsTsbaccountdef = new PortalShopConfigEntitlementsTsbaccountdefWrapper(client, translationProvider);
            this.PortalShopConfigEntitlementsUnsgroupb = new PortalShopConfigEntitlementsUnsgroupbWrapper(client, translationProvider);
            this.PortalShopConfigEntitlementsUnsgroupb1 = new PortalShopConfigEntitlementsUnsgroupb1Wrapper(client, translationProvider);
            this.PortalShopConfigEntitlementsUnsgroupb2 = new PortalShopConfigEntitlementsUnsgroupb2Wrapper(client, translationProvider);
            this.PortalShopConfigEntitlementsUnsgroupb3 = new PortalShopConfigEntitlementsUnsgroupb3Wrapper(client, translationProvider);
            this.PortalTargetsystemUnsAccount = new PortalTargetsystemUnsAccountWrapper(client, translationProvider);
            this.PortalTargetsystemUnsaccountb = new PortalTargetsystemUnsaccountbWrapper(client, translationProvider);
            this.PortalTargetsystemUnsaccountbInteractive = new PortalTargetsystemUnsaccountbInteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemUnsContainer = new PortalTargetsystemUnsContainerWrapper(client, translationProvider);
            this.PortalTargetsystemUnscontainerb = new PortalTargetsystemUnscontainerbWrapper(client, translationProvider);
            this.PortalTargetsystemUnscontainerbInteractive = new PortalTargetsystemUnscontainerbInteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemUnsDirectmembers = new PortalTargetsystemUnsDirectmembersWrapper(client, translationProvider);
            this.PortalTargetsystemUnsGroup = new PortalTargetsystemUnsGroupWrapper(client, translationProvider);
            this.PortalTargetsystemUnsgroupb = new PortalTargetsystemUnsgroupbWrapper(client, translationProvider);
            this.PortalTargetsystemUnsgroupb1 = new PortalTargetsystemUnsgroupb1Wrapper(client, translationProvider);
            this.PortalTargetsystemUnsgroupb1Interactive = new PortalTargetsystemUnsgroupb1InteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemUnsgroupb2 = new PortalTargetsystemUnsgroupb2Wrapper(client, translationProvider);
            this.PortalTargetsystemUnsgroupb2Interactive = new PortalTargetsystemUnsgroupb2InteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemUnsgroupb3 = new PortalTargetsystemUnsgroupb3Wrapper(client, translationProvider);
            this.PortalTargetsystemUnsgroupb3Interactive = new PortalTargetsystemUnsgroupb3InteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemUnsgroupbInteractive = new PortalTargetsystemUnsgroupbInteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemUnsGroupmembers = new PortalTargetsystemUnsGroupmembersWrapper(client, translationProvider);
            this.PortalTargetsystemUnsGroupServiceitem = new PortalTargetsystemUnsGroupServiceitemWrapper(client, translationProvider);
            this.PortalTargetsystemUnsGroupServiceitemInteractive = new PortalTargetsystemUnsGroupServiceitemInteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemUnsitemb = new PortalTargetsystemUnsitembWrapper(client, translationProvider);
            this.PortalTargetsystemUnsitembInteractive = new PortalTargetsystemUnsitembInteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemUnsNestedmembers = new PortalTargetsystemUnsNestedmembersWrapper(client, translationProvider);
            this.PortalTargetsystemUnsSystem = new PortalTargetsystemUnsSystemWrapper(client, translationProvider);
            this.PortalUnsgroupb1Memberships = new PortalUnsgroupb1MembershipsWrapper(client, translationProvider);
            this.PortalUnsgroupb2Memberships = new PortalUnsgroupb2MembershipsWrapper(client, translationProvider);
            this.PortalUnsgroupb3Memberships = new PortalUnsgroupb3MembershipsWrapper(client, translationProvider);
            this.PortalUnsgroupbMemberships = new PortalUnsgroupbMembershipsWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var PortalCandidatesAccproductgroup = /** @class */ (function (_super) {
        __extends(PortalCandidatesAccproductgroup, _super);
        function PortalCandidatesAccproductgroup() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_AccProductGroup = _this.GetEntityValue('UID_AccProductGroup');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesAccproductgroup.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AccProductGroup': {
                    ColumnName: 'UID_AccProductGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AccProductGroup', Columns: columns };
        };
        return PortalCandidatesAccproductgroup;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesAccproductgroup type. */
    var PortalCandidatesAccproductgroupInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesAccproductgroupInteractive, _super);
        function PortalCandidatesAccproductgroupInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesAccproductgroupInteractive;
    }(PortalCandidatesAccproductgroup));
    var PortalCandidatesAccproductparamcategory = /** @class */ (function (_super) {
        __extends(PortalCandidatesAccproductparamcategory, _super);
        function PortalCandidatesAccproductparamcategory() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_AccProductParamCategory = _this.GetEntityValue('UID_AccProductParamCategory');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesAccproductparamcategory.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AccProductParamCategory': {
                    ColumnName: 'UID_AccProductParamCategory',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AccProductParamCategory', Columns: columns };
        };
        return PortalCandidatesAccproductparamcategory;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesAccproductparamcategory type. */
    var PortalCandidatesAccproductparamcategoryInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesAccproductparamcategoryInteractive, _super);
        function PortalCandidatesAccproductparamcategoryInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesAccproductparamcategoryInteractive;
    }(PortalCandidatesAccproductparamcategory));
    var PortalClaimgroupGroup = /** @class */ (function (_super) {
        __extends(PortalClaimgroupGroup, _super);
        function PortalClaimgroupGroup() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Description = _this.GetEntityValue('Description');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalClaimgroupGroup.GetEntitySchema = function () {
            var columns = {
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroup', Columns: columns };
        };
        return PortalClaimgroupGroup;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalClaimgroupGroup type. */
    var PortalClaimgroupGroupInteractive = /** @class */ (function (_super) {
        __extends(PortalClaimgroupGroupInteractive, _super);
        function PortalClaimgroupGroupInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalClaimgroupGroupInteractive;
    }(PortalClaimgroupGroup));
    var PortalClaimgroupSuggestedowner = /** @class */ (function (_super) {
        __extends(PortalClaimgroupSuggestedowner, _super);
        function PortalClaimgroupSuggestedowner() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.DefaultEmailAddress = _this.GetEntityValue('DefaultEmailAddress');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalClaimgroupSuggestedowner.GetEntitySchema = function () {
            var columns = {
                'DefaultEmailAddress': {
                    ColumnName: 'DefaultEmailAddress',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'Person', Columns: columns };
        };
        return PortalClaimgroupSuggestedowner;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalClaimgroupSuggestedowner type. */
    var PortalClaimgroupSuggestedownerInteractive = /** @class */ (function (_super) {
        __extends(PortalClaimgroupSuggestedownerInteractive, _super);
        function PortalClaimgroupSuggestedownerInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalClaimgroupSuggestedownerInteractive;
    }(PortalClaimgroupSuggestedowner));
    var PortalClaimgroupSuggestedowner2 = /** @class */ (function (_super) {
        __extends(PortalClaimgroupSuggestedowner2, _super);
        function PortalClaimgroupSuggestedowner2() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.DefaultEmailAddress = _this.GetEntityValue('DefaultEmailAddress');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalClaimgroupSuggestedowner2.GetEntitySchema = function () {
            var columns = {
                'DefaultEmailAddress': {
                    ColumnName: 'DefaultEmailAddress',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'Person', Columns: columns };
        };
        return PortalClaimgroupSuggestedowner2;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalClaimgroupSuggestedowner2 type. */
    var PortalClaimgroupSuggestedowner2Interactive = /** @class */ (function (_super) {
        __extends(PortalClaimgroupSuggestedowner2Interactive, _super);
        function PortalClaimgroupSuggestedowner2Interactive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalClaimgroupSuggestedowner2Interactive;
    }(PortalClaimgroupSuggestedowner2));
    var PortalPersonAccounts = /** @class */ (function (_super) {
        __extends(PortalPersonAccounts, _super);
        function PortalPersonAccounts() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.AccountName = _this.GetEntityValue('AccountName');
            _this.CanonicalName = _this.GetEntityValue('CanonicalName');
            _this.UID_DPRNameSpace = _this.GetEntityValue('UID_DPRNameSpace');
            _this.UID_UNSRoot = _this.GetEntityValue('UID_UNSRoot');
            _this.AccountDisabled = _this.GetEntityValue('AccountDisabled');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalPersonAccounts.GetEntitySchema = function () {
            var columns = {
                'AccountName': {
                    ColumnName: 'AccountName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'CanonicalName': {
                    ColumnName: 'CanonicalName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DPRNameSpace': {
                    ColumnName: 'UID_DPRNameSpace',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSRoot': {
                    ColumnName: 'UID_UNSRoot',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'AccountDisabled': {
                    ColumnName: 'AccountDisabled',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSAccount', Columns: columns };
        };
        return PortalPersonAccounts;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalPersonAccounts type. */
    var PortalPersonAccountsInteractive = /** @class */ (function (_super) {
        __extends(PortalPersonAccountsInteractive, _super);
        function PortalPersonAccountsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalPersonAccountsInteractive;
    }(PortalPersonAccounts));
    var PortalPersonGroupmemberships = /** @class */ (function (_super) {
        __extends(PortalPersonGroupmemberships, _super);
        function PortalPersonGroupmemberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroup = _this.GetEntityValue('UID_UNSGroup');
            _this.UID_UNSRoot = _this.GetEntityValue('UID_UNSRoot');
            _this.ObjectKeyGroup = _this.GetEntityValue('ObjectKeyGroup');
            _this.IsFromDynamic = _this.GetEntityValue('IsFromDynamic');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalPersonGroupmemberships.GetEntitySchema = function () {
            var columns = {
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroup': {
                    ColumnName: 'UID_UNSGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSRoot': {
                    ColumnName: 'UID_UNSRoot',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyGroup': {
                    ColumnName: 'ObjectKeyGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsFromDynamic': {
                    ColumnName: 'IsFromDynamic',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSAccountInUNSGroup', Columns: columns };
        };
        return PortalPersonGroupmemberships;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalPersonGroupmemberships type. */
    var PortalPersonGroupmembershipsInteractive = /** @class */ (function (_super) {
        __extends(PortalPersonGroupmembershipsInteractive, _super);
        function PortalPersonGroupmembershipsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalPersonGroupmembershipsInteractive;
    }(PortalPersonGroupmemberships));
    var PortalRespUnsgroup = /** @class */ (function (_super) {
        __extends(PortalRespUnsgroup, _super);
        function PortalRespUnsgroup() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.Description = _this.GetEntityValue('Description');
            _this.DistinguishedName = _this.GetEntityValue('DistinguishedName');
            _this.GroupType = _this.GetEntityValue('GroupType');
            _this.UID_UNSRoot = _this.GetEntityValue('UID_UNSRoot');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.Requestable = _this.GetEntityValue('Requestable');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalRespUnsgroup.GetEntitySchema = function () {
            var columns = {
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'DistinguishedName': {
                    ColumnName: 'DistinguishedName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'GroupType': {
                    ColumnName: 'GroupType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSRoot': {
                    ColumnName: 'UID_UNSRoot',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Requestable': {
                    ColumnName: 'Requestable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroup', Columns: columns };
        };
        return PortalRespUnsgroup;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalRespUnsgroup type. */
    var PortalRespUnsgroupInteractive = /** @class */ (function (_super) {
        __extends(PortalRespUnsgroupInteractive, _super);
        function PortalRespUnsgroupInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalRespUnsgroupInteractive;
    }(PortalRespUnsgroup));
    var PortalRespUnsgroupb = /** @class */ (function (_super) {
        __extends(PortalRespUnsgroupb, _super);
        function PortalRespUnsgroupb() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalRespUnsgroupb.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroupB', Columns: columns };
        };
        return PortalRespUnsgroupb;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalRespUnsgroupb type. */
    var PortalRespUnsgroupbInteractive = /** @class */ (function (_super) {
        __extends(PortalRespUnsgroupbInteractive, _super);
        function PortalRespUnsgroupbInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalRespUnsgroupbInteractive;
    }(PortalRespUnsgroupb));
    var PortalRespUnsgroupb1 = /** @class */ (function (_super) {
        __extends(PortalRespUnsgroupb1, _super);
        function PortalRespUnsgroupb1() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalRespUnsgroupb1.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroupB1', Columns: columns };
        };
        return PortalRespUnsgroupb1;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalRespUnsgroupb1 type. */
    var PortalRespUnsgroupb1Interactive = /** @class */ (function (_super) {
        __extends(PortalRespUnsgroupb1Interactive, _super);
        function PortalRespUnsgroupb1Interactive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalRespUnsgroupb1Interactive;
    }(PortalRespUnsgroupb1));
    var PortalRespUnsgroupb2 = /** @class */ (function (_super) {
        __extends(PortalRespUnsgroupb2, _super);
        function PortalRespUnsgroupb2() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalRespUnsgroupb2.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroupB2', Columns: columns };
        };
        return PortalRespUnsgroupb2;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalRespUnsgroupb2 type. */
    var PortalRespUnsgroupb2Interactive = /** @class */ (function (_super) {
        __extends(PortalRespUnsgroupb2Interactive, _super);
        function PortalRespUnsgroupb2Interactive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalRespUnsgroupb2Interactive;
    }(PortalRespUnsgroupb2));
    var PortalRespUnsgroupb3 = /** @class */ (function (_super) {
        __extends(PortalRespUnsgroupb3, _super);
        function PortalRespUnsgroupb3() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalRespUnsgroupb3.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroupB3', Columns: columns };
        };
        return PortalRespUnsgroupb3;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalRespUnsgroupb3 type. */
    var PortalRespUnsgroupb3Interactive = /** @class */ (function (_super) {
        __extends(PortalRespUnsgroupb3Interactive, _super);
        function PortalRespUnsgroupb3Interactive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalRespUnsgroupb3Interactive;
    }(PortalRespUnsgroupb3));
    var PortalShopConfigEntitlementsTsbaccountdef = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsTsbaccountdef, _super);
        function PortalShopConfigEntitlementsTsbaccountdef() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
            _this.UID_TSBAccountDef = _this.GetEntityValue('UID_TSBAccountDef');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalShopConfigEntitlementsTsbaccountdef.GetEntitySchema = function () {
            var columns = {
                'UID_ITShopOrg': {
                    ColumnName: 'UID_ITShopOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_TSBAccountDef': {
                    ColumnName: 'UID_TSBAccountDef',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ITShopOrgHasTSBAccountDef', Columns: columns };
        };
        return PortalShopConfigEntitlementsTsbaccountdef;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalShopConfigEntitlementsTsbaccountdef type. */
    var PortalShopConfigEntitlementsTsbaccountdefInteractive = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsTsbaccountdefInteractive, _super);
        function PortalShopConfigEntitlementsTsbaccountdefInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalShopConfigEntitlementsTsbaccountdefInteractive;
    }(PortalShopConfigEntitlementsTsbaccountdef));
    var PortalShopConfigEntitlementsUnsgroupb = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsUnsgroupb, _super);
        function PortalShopConfigEntitlementsUnsgroupb() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
            _this.UID_UNSGroupB = _this.GetEntityValue('UID_UNSGroupB');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalShopConfigEntitlementsUnsgroupb.GetEntitySchema = function () {
            var columns = {
                'UID_ITShopOrg': {
                    ColumnName: 'UID_ITShopOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupB': {
                    ColumnName: 'UID_UNSGroupB',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ITShopOrgHasUNSGroupB', Columns: columns };
        };
        return PortalShopConfigEntitlementsUnsgroupb;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalShopConfigEntitlementsUnsgroupb type. */
    var PortalShopConfigEntitlementsUnsgroupbInteractive = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsUnsgroupbInteractive, _super);
        function PortalShopConfigEntitlementsUnsgroupbInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalShopConfigEntitlementsUnsgroupbInteractive;
    }(PortalShopConfigEntitlementsUnsgroupb));
    var PortalShopConfigEntitlementsUnsgroupb1 = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsUnsgroupb1, _super);
        function PortalShopConfigEntitlementsUnsgroupb1() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
            _this.UID_UNSGroupB1 = _this.GetEntityValue('UID_UNSGroupB1');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalShopConfigEntitlementsUnsgroupb1.GetEntitySchema = function () {
            var columns = {
                'UID_ITShopOrg': {
                    ColumnName: 'UID_ITShopOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupB1': {
                    ColumnName: 'UID_UNSGroupB1',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ITShopOrgHasUNSGroupB1', Columns: columns };
        };
        return PortalShopConfigEntitlementsUnsgroupb1;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalShopConfigEntitlementsUnsgroupb1 type. */
    var PortalShopConfigEntitlementsUnsgroupb1Interactive = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsUnsgroupb1Interactive, _super);
        function PortalShopConfigEntitlementsUnsgroupb1Interactive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalShopConfigEntitlementsUnsgroupb1Interactive;
    }(PortalShopConfigEntitlementsUnsgroupb1));
    var PortalShopConfigEntitlementsUnsgroupb2 = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsUnsgroupb2, _super);
        function PortalShopConfigEntitlementsUnsgroupb2() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
            _this.UID_UNSGroupB2 = _this.GetEntityValue('UID_UNSGroupB2');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalShopConfigEntitlementsUnsgroupb2.GetEntitySchema = function () {
            var columns = {
                'UID_ITShopOrg': {
                    ColumnName: 'UID_ITShopOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupB2': {
                    ColumnName: 'UID_UNSGroupB2',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ITShopOrgHasUNSGroupB2', Columns: columns };
        };
        return PortalShopConfigEntitlementsUnsgroupb2;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalShopConfigEntitlementsUnsgroupb2 type. */
    var PortalShopConfigEntitlementsUnsgroupb2Interactive = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsUnsgroupb2Interactive, _super);
        function PortalShopConfigEntitlementsUnsgroupb2Interactive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalShopConfigEntitlementsUnsgroupb2Interactive;
    }(PortalShopConfigEntitlementsUnsgroupb2));
    var PortalShopConfigEntitlementsUnsgroupb3 = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsUnsgroupb3, _super);
        function PortalShopConfigEntitlementsUnsgroupb3() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
            _this.UID_UNSGroupB3 = _this.GetEntityValue('UID_UNSGroupB3');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalShopConfigEntitlementsUnsgroupb3.GetEntitySchema = function () {
            var columns = {
                'UID_ITShopOrg': {
                    ColumnName: 'UID_ITShopOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupB3': {
                    ColumnName: 'UID_UNSGroupB3',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ITShopOrgHasUNSGroupB3', Columns: columns };
        };
        return PortalShopConfigEntitlementsUnsgroupb3;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalShopConfigEntitlementsUnsgroupb3 type. */
    var PortalShopConfigEntitlementsUnsgroupb3Interactive = /** @class */ (function (_super) {
        __extends(PortalShopConfigEntitlementsUnsgroupb3Interactive, _super);
        function PortalShopConfigEntitlementsUnsgroupb3Interactive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalShopConfigEntitlementsUnsgroupb3Interactive;
    }(PortalShopConfigEntitlementsUnsgroupb3));
    var PortalTargetsystemUnsAccount = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsAccount, _super);
        function PortalTargetsystemUnsAccount() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.AccountDisabled = _this.GetEntityValue('AccountDisabled');
            _this.AccountExpires = _this.GetEntityValue('AccountExpires');
            _this.AccountName = _this.GetEntityValue('AccountName');
            _this.CanonicalName = _this.GetEntityValue('CanonicalName');
            _this.cn = _this.GetEntityValue('cn');
            _this.Description = _this.GetEntityValue('Description');
            _this.DistinguishedName = _this.GetEntityValue('DistinguishedName');
            _this.FirstName = _this.GetEntityValue('FirstName');
            _this.IdentityType = _this.GetEntityValue('IdentityType');
            _this.IsGroupAccount = _this.GetEntityValue('IsGroupAccount');
            _this.IsPrivilegedAccount = _this.GetEntityValue('IsPrivilegedAccount');
            _this.LastLogon = _this.GetEntityValue('LastLogon');
            _this.LastName = _this.GetEntityValue('LastName');
            _this.MatchPatternForMembership = _this.GetEntityValue('MatchPatternForMembership');
            _this.NeverConnectToPerson = _this.GetEntityValue('NeverConnectToPerson');
            _this.ObjectGUID = _this.GetEntityValue('ObjectGUID');
            _this.PWDLastSet = _this.GetEntityValue('PWDLastSet');
            _this.RiskIndexCalculated = _this.GetEntityValue('RiskIndexCalculated');
            _this.UID_DPRNameSpace = _this.GetEntityValue('UID_DPRNameSpace');
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.UID_TSBAccountDef = _this.GetEntityValue('UID_TSBAccountDef');
            _this.UID_TSBBehavior = _this.GetEntityValue('UID_TSBBehavior');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSContainer = _this.GetEntityValue('UID_UNSContainer');
            _this.UID_UNSRoot = _this.GetEntityValue('UID_UNSRoot');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.XTouched = _this.GetEntityValue('XTouched');
            _this.XUserInserted = _this.GetEntityValue('XUserInserted');
            _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsAccount.GetEntitySchema = function () {
            var columns = {
                'AccountDisabled': {
                    ColumnName: 'AccountDisabled',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'AccountExpires': {
                    ColumnName: 'AccountExpires',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'AccountName': {
                    ColumnName: 'AccountName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'CanonicalName': {
                    ColumnName: 'CanonicalName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'cn': {
                    ColumnName: 'cn',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'DistinguishedName': {
                    ColumnName: 'DistinguishedName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'FirstName': {
                    ColumnName: 'FirstName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IdentityType': {
                    ColumnName: 'IdentityType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsGroupAccount': {
                    ColumnName: 'IsGroupAccount',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrivilegedAccount': {
                    ColumnName: 'IsPrivilegedAccount',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'LastLogon': {
                    ColumnName: 'LastLogon',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'LastName': {
                    ColumnName: 'LastName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'MatchPatternForMembership': {
                    ColumnName: 'MatchPatternForMembership',
                    Type: imxQbmDbts.ValType.Long,
                    IsReadOnly: true,
                },
                'NeverConnectToPerson': {
                    ColumnName: 'NeverConnectToPerson',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'ObjectGUID': {
                    ColumnName: 'ObjectGUID',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PWDLastSet': {
                    ColumnName: 'PWDLastSet',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'RiskIndexCalculated': {
                    ColumnName: 'RiskIndexCalculated',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'UID_DPRNameSpace': {
                    ColumnName: 'UID_DPRNameSpace',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_TSBAccountDef': {
                    ColumnName: 'UID_TSBAccountDef',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_TSBBehavior': {
                    ColumnName: 'UID_TSBBehavior',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSContainer': {
                    ColumnName: 'UID_UNSContainer',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSRoot': {
                    ColumnName: 'UID_UNSRoot',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XDateUpdated': {
                    ColumnName: 'XDateUpdated',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XTouched': {
                    ColumnName: 'XTouched',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserInserted': {
                    ColumnName: 'XUserInserted',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserUpdated': {
                    ColumnName: 'XUserUpdated',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSAccount', Columns: columns };
        };
        return PortalTargetsystemUnsAccount;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsAccount type. */
    var PortalTargetsystemUnsAccountInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsAccountInteractive, _super);
        function PortalTargetsystemUnsAccountInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsAccountInteractive;
    }(PortalTargetsystemUnsAccount));
    var PortalTargetsystemUnsaccountb = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsaccountb, _super);
        function PortalTargetsystemUnsaccountb() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsaccountb.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSAccountB', Columns: columns };
        };
        return PortalTargetsystemUnsaccountb;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsaccountb type. */
    var PortalTargetsystemUnsaccountbInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsaccountbInteractive, _super);
        function PortalTargetsystemUnsaccountbInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsaccountbInteractive;
    }(PortalTargetsystemUnsaccountb));
    var PortalTargetsystemUnsContainer = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsContainer, _super);
        function PortalTargetsystemUnsContainer() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.CanonicalName = _this.GetEntityValue('CanonicalName');
            _this.cn = _this.GetEntityValue('cn');
            _this.Description = _this.GetEntityValue('Description');
            _this.DistinguishedName = _this.GetEntityValue('DistinguishedName');
            _this.DomainDisplayName = _this.GetEntityValue('DomainDisplayName');
            _this.ObjectGUID = _this.GetEntityValue('ObjectGUID');
            _this.UID_DPRNameSpace = _this.GetEntityValue('UID_DPRNameSpace');
            _this.UID_ParentUNSContainer = _this.GetEntityValue('UID_ParentUNSContainer');
            _this.UID_UNSContainer = _this.GetEntityValue('UID_UNSContainer');
            _this.UID_UNSRoot = _this.GetEntityValue('UID_UNSRoot');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.XTouched = _this.GetEntityValue('XTouched');
            _this.XUserInserted = _this.GetEntityValue('XUserInserted');
            _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
            _this.HasChildren = _this.GetEntityValue('HasChildren');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsContainer.GetEntitySchema = function () {
            var columns = {
                'CanonicalName': {
                    ColumnName: 'CanonicalName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'cn': {
                    ColumnName: 'cn',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'DistinguishedName': {
                    ColumnName: 'DistinguishedName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DomainDisplayName': {
                    ColumnName: 'DomainDisplayName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectGUID': {
                    ColumnName: 'ObjectGUID',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DPRNameSpace': {
                    ColumnName: 'UID_DPRNameSpace',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_ParentUNSContainer': {
                    ColumnName: 'UID_ParentUNSContainer',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSContainer': {
                    ColumnName: 'UID_UNSContainer',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSRoot': {
                    ColumnName: 'UID_UNSRoot',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XDateUpdated': {
                    ColumnName: 'XDateUpdated',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XTouched': {
                    ColumnName: 'XTouched',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserInserted': {
                    ColumnName: 'XUserInserted',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserUpdated': {
                    ColumnName: 'XUserUpdated',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'HasChildren': {
                    ColumnName: 'HasChildren',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSContainer', Columns: columns };
        };
        return PortalTargetsystemUnsContainer;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsContainer type. */
    var PortalTargetsystemUnsContainerInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsContainerInteractive, _super);
        function PortalTargetsystemUnsContainerInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsContainerInteractive;
    }(PortalTargetsystemUnsContainer));
    var PortalTargetsystemUnscontainerb = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnscontainerb, _super);
        function PortalTargetsystemUnscontainerb() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnscontainerb.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSContainerB', Columns: columns };
        };
        return PortalTargetsystemUnscontainerb;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemUnscontainerb type. */
    var PortalTargetsystemUnscontainerbInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnscontainerbInteractive, _super);
        function PortalTargetsystemUnscontainerbInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnscontainerbInteractive;
    }(PortalTargetsystemUnscontainerb));
    var PortalTargetsystemUnsDirectmembers = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsDirectmembers, _super);
        function PortalTargetsystemUnsDirectmembers() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_UNSGroup = _this.GetEntityValue('UID_UNSGroup');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.IsFromDynamic = _this.GetEntityValue('IsFromDynamic');
            _this.UID_PersonWantsOrg = _this.GetEntityValue('UID_PersonWantsOrg');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.IsRequestCancellable = _this.GetEntityValue('IsRequestCancellable');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsDirectmembers.GetEntitySchema = function () {
            var columns = {
                'UID_UNSGroup': {
                    ColumnName: 'UID_UNSGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsFromDynamic': {
                    ColumnName: 'IsFromDynamic',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'UID_PersonWantsOrg': {
                    ColumnName: 'UID_PersonWantsOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsRequestCancellable': {
                    ColumnName: 'IsRequestCancellable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSAccountInUNSGroup', Columns: columns };
        };
        return PortalTargetsystemUnsDirectmembers;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsDirectmembers type. */
    var PortalTargetsystemUnsDirectmembersInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsDirectmembersInteractive, _super);
        function PortalTargetsystemUnsDirectmembersInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsDirectmembersInteractive;
    }(PortalTargetsystemUnsDirectmembers));
    var PortalTargetsystemUnsGroup = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsGroup, _super);
        function PortalTargetsystemUnsGroup() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.CanonicalName = _this.GetEntityValue('CanonicalName');
            _this.cn = _this.GetEntityValue('cn');
            _this.Description = _this.GetEntityValue('Description');
            _this.DisplayName = _this.GetEntityValue('DisplayName');
            _this.DistinguishedName = _this.GetEntityValue('DistinguishedName');
            _this.GroupType = _this.GetEntityValue('GroupType');
            _this.HasReadOnlyMemberships = _this.GetEntityValue('HasReadOnlyMemberships');
            _this.IsForITShop = _this.GetEntityValue('IsForITShop');
            _this.IsITShopOnly = _this.GetEntityValue('IsITShopOnly');
            _this.MatchPatternForMembership = _this.GetEntityValue('MatchPatternForMembership');
            _this.ObjectGUID = _this.GetEntityValue('ObjectGUID');
            _this.RiskIndex = _this.GetEntityValue('RiskIndex');
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.UID_DPRNameSpace = _this.GetEntityValue('UID_DPRNameSpace');
            _this.UID_UNSContainer = _this.GetEntityValue('UID_UNSContainer');
            _this.UID_UNSGroup = _this.GetEntityValue('UID_UNSGroup');
            _this.UID_UNSRoot = _this.GetEntityValue('UID_UNSRoot');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.XTouched = _this.GetEntityValue('XTouched');
            _this.XUserInserted = _this.GetEntityValue('XUserInserted');
            _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
            _this.Requestable = _this.GetEntityValue('Requestable');
            _this.Owned = _this.GetEntityValue('Owned');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsGroup.GetEntitySchema = function () {
            var columns = {
                'CanonicalName': {
                    ColumnName: 'CanonicalName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'cn': {
                    ColumnName: 'cn',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'DisplayName': {
                    ColumnName: 'DisplayName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DistinguishedName': {
                    ColumnName: 'DistinguishedName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'GroupType': {
                    ColumnName: 'GroupType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'HasReadOnlyMemberships': {
                    ColumnName: 'HasReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsForITShop': {
                    ColumnName: 'IsForITShop',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsITShopOnly': {
                    ColumnName: 'IsITShopOnly',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'MatchPatternForMembership': {
                    ColumnName: 'MatchPatternForMembership',
                    Type: imxQbmDbts.ValType.Long,
                    IsReadOnly: true,
                },
                'ObjectGUID': {
                    ColumnName: 'ObjectGUID',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'RiskIndex': {
                    ColumnName: 'RiskIndex',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DPRNameSpace': {
                    ColumnName: 'UID_DPRNameSpace',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSContainer': {
                    ColumnName: 'UID_UNSContainer',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroup': {
                    ColumnName: 'UID_UNSGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSRoot': {
                    ColumnName: 'UID_UNSRoot',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XDateUpdated': {
                    ColumnName: 'XDateUpdated',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XTouched': {
                    ColumnName: 'XTouched',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserInserted': {
                    ColumnName: 'XUserInserted',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserUpdated': {
                    ColumnName: 'XUserUpdated',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Requestable': {
                    ColumnName: 'Requestable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Owned': {
                    ColumnName: 'Owned',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroup', Columns: columns };
        };
        return PortalTargetsystemUnsGroup;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsGroup type. */
    var PortalTargetsystemUnsGroupInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsGroupInteractive, _super);
        function PortalTargetsystemUnsGroupInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsGroupInteractive;
    }(PortalTargetsystemUnsGroup));
    var PortalTargetsystemUnsgroupb = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsgroupb, _super);
        function PortalTargetsystemUnsgroupb() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.HasReadOnlyMemberships = _this.GetEntityValue('HasReadOnlyMemberships');
            _this.Requestable = _this.GetEntityValue('Requestable');
            _this.Owned = _this.GetEntityValue('Owned');
            _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsgroupb.GetEntitySchema = function () {
            var columns = {
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'HasReadOnlyMemberships': {
                    ColumnName: 'HasReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Requestable': {
                    ColumnName: 'Requestable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Owned': {
                    ColumnName: 'Owned',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XReadOnlyMemberships': {
                    ColumnName: 'XReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroupB', Columns: columns };
        };
        return PortalTargetsystemUnsgroupb;
    }(imxQbmDbts.WriteExtTypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsgroupb type. */
    var PortalTargetsystemUnsgroupbInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsgroupbInteractive, _super);
        function PortalTargetsystemUnsgroupbInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsgroupbInteractive;
    }(PortalTargetsystemUnsgroupb));
    var PortalTargetsystemUnsgroupb1 = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsgroupb1, _super);
        function PortalTargetsystemUnsgroupb1() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.HasReadOnlyMemberships = _this.GetEntityValue('HasReadOnlyMemberships');
            _this.Requestable = _this.GetEntityValue('Requestable');
            _this.Owned = _this.GetEntityValue('Owned');
            _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsgroupb1.GetEntitySchema = function () {
            var columns = {
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'HasReadOnlyMemberships': {
                    ColumnName: 'HasReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Requestable': {
                    ColumnName: 'Requestable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Owned': {
                    ColumnName: 'Owned',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XReadOnlyMemberships': {
                    ColumnName: 'XReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroupB1', Columns: columns };
        };
        return PortalTargetsystemUnsgroupb1;
    }(imxQbmDbts.WriteExtTypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsgroupb1 type. */
    var PortalTargetsystemUnsgroupb1Interactive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsgroupb1Interactive, _super);
        function PortalTargetsystemUnsgroupb1Interactive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsgroupb1Interactive;
    }(PortalTargetsystemUnsgroupb1));
    var PortalTargetsystemUnsgroupb2 = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsgroupb2, _super);
        function PortalTargetsystemUnsgroupb2() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.HasReadOnlyMemberships = _this.GetEntityValue('HasReadOnlyMemberships');
            _this.Requestable = _this.GetEntityValue('Requestable');
            _this.Owned = _this.GetEntityValue('Owned');
            _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsgroupb2.GetEntitySchema = function () {
            var columns = {
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'HasReadOnlyMemberships': {
                    ColumnName: 'HasReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Requestable': {
                    ColumnName: 'Requestable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Owned': {
                    ColumnName: 'Owned',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XReadOnlyMemberships': {
                    ColumnName: 'XReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroupB2', Columns: columns };
        };
        return PortalTargetsystemUnsgroupb2;
    }(imxQbmDbts.WriteExtTypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsgroupb2 type. */
    var PortalTargetsystemUnsgroupb2Interactive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsgroupb2Interactive, _super);
        function PortalTargetsystemUnsgroupb2Interactive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsgroupb2Interactive;
    }(PortalTargetsystemUnsgroupb2));
    var PortalTargetsystemUnsgroupb3 = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsgroupb3, _super);
        function PortalTargetsystemUnsgroupb3() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.HasReadOnlyMemberships = _this.GetEntityValue('HasReadOnlyMemberships');
            _this.Requestable = _this.GetEntityValue('Requestable');
            _this.Owned = _this.GetEntityValue('Owned');
            _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsgroupb3.GetEntitySchema = function () {
            var columns = {
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'HasReadOnlyMemberships': {
                    ColumnName: 'HasReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Requestable': {
                    ColumnName: 'Requestable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Owned': {
                    ColumnName: 'Owned',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XReadOnlyMemberships': {
                    ColumnName: 'XReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroupB3', Columns: columns };
        };
        return PortalTargetsystemUnsgroupb3;
    }(imxQbmDbts.WriteExtTypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsgroupb3 type. */
    var PortalTargetsystemUnsgroupb3Interactive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsgroupb3Interactive, _super);
        function PortalTargetsystemUnsgroupb3Interactive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsgroupb3Interactive;
    }(PortalTargetsystemUnsgroupb3));
    var PortalTargetsystemUnsGroupmembers = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsGroupmembers, _super);
        function PortalTargetsystemUnsGroupmembers() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsGroupmembers.GetEntitySchema = function () {
            var columns = {
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSGroupInUNSGroup', Columns: columns };
        };
        return PortalTargetsystemUnsGroupmembers;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsGroupmembers type. */
    var PortalTargetsystemUnsGroupmembersInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsGroupmembersInteractive, _super);
        function PortalTargetsystemUnsGroupmembersInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsGroupmembersInteractive;
    }(PortalTargetsystemUnsGroupmembers));
    var PortalTargetsystemUnsGroupServiceitem = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsGroupServiceitem, _super);
        function PortalTargetsystemUnsGroupServiceitem() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Description = _this.GetEntityValue('Description');
            _this.Ident_AccProduct = _this.GetEntityValue('Ident_AccProduct');
            _this.IsInActive = _this.GetEntityValue('IsInActive');
            _this.UID_AccProductGroup = _this.GetEntityValue('UID_AccProductGroup');
            _this.UID_AccProductParamCategory = _this.GetEntityValue('UID_AccProductParamCategory');
            _this.UID_OrgAttestator = _this.GetEntityValue('UID_OrgAttestator');
            _this.UID_OrgRuler = _this.GetEntityValue('UID_OrgRuler');
            _this.UID_PWODecisionMethod = _this.GetEntityValue('UID_PWODecisionMethod');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsGroupServiceitem.GetEntitySchema = function () {
            var columns = {
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: false,
                },
                'Ident_AccProduct': {
                    ColumnName: 'Ident_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'IsInActive': {
                    ColumnName: 'IsInActive',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: false,
                },
                'UID_AccProductGroup': {
                    ColumnName: 'UID_AccProductGroup',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_AccProductParamCategory': {
                    ColumnName: 'UID_AccProductParamCategory',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_OrgAttestator': {
                    ColumnName: 'UID_OrgAttestator',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_OrgRuler': {
                    ColumnName: 'UID_OrgRuler',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_PWODecisionMethod': {
                    ColumnName: 'UID_PWODecisionMethod',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'AccProduct', Columns: columns };
        };
        return PortalTargetsystemUnsGroupServiceitem;
    }(imxQbmDbts.WriteExtTypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsGroupServiceitem type. */
    var PortalTargetsystemUnsGroupServiceitemInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsGroupServiceitemInteractive, _super);
        function PortalTargetsystemUnsGroupServiceitemInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsGroupServiceitemInteractive;
    }(PortalTargetsystemUnsGroupServiceitem));
    var PortalTargetsystemUnsitemb = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsitemb, _super);
        function PortalTargetsystemUnsitemb() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsitemb.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSItemB', Columns: columns };
        };
        return PortalTargetsystemUnsitemb;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsitemb type. */
    var PortalTargetsystemUnsitembInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsitembInteractive, _super);
        function PortalTargetsystemUnsitembInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsitembInteractive;
    }(PortalTargetsystemUnsitemb));
    var PortalTargetsystemUnsNestedmembers = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsNestedmembers, _super);
        function PortalTargetsystemUnsNestedmembers() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsNestedmembers.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSAccount', Columns: columns };
        };
        return PortalTargetsystemUnsNestedmembers;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsNestedmembers type. */
    var PortalTargetsystemUnsNestedmembersInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsNestedmembersInteractive, _super);
        function PortalTargetsystemUnsNestedmembersInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsNestedmembersInteractive;
    }(PortalTargetsystemUnsNestedmembers));
    var PortalTargetsystemUnsSystem = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsSystem, _super);
        function PortalTargetsystemUnsSystem() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.CanonicalName = _this.GetEntityValue('CanonicalName');
            _this.Description = _this.GetEntityValue('Description');
            _this.DisplayName = _this.GetEntityValue('DisplayName');
            _this.DistinguishedName = _this.GetEntityValue('DistinguishedName');
            _this.Ident_UNSRoot = _this.GetEntityValue('Ident_UNSRoot');
            _this.MatchPatternDisplay = _this.GetEntityValue('MatchPatternDisplay');
            _this.NamespaceManagedBy = _this.GetEntityValue('NamespaceManagedBy');
            _this.UID_AERoleOwner = _this.GetEntityValue('UID_AERoleOwner');
            _this.UID_DPRNameSpace = _this.GetEntityValue('UID_DPRNameSpace');
            _this.UID_TSBAccountDef = _this.GetEntityValue('UID_TSBAccountDef');
            _this.UID_UNSRoot = _this.GetEntityValue('UID_UNSRoot');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.XTouched = _this.GetEntityValue('XTouched');
            _this.XUserInserted = _this.GetEntityValue('XUserInserted');
            _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
            _this.HasSync = _this.GetEntityValue('HasSync');
            _this.HasData = _this.GetEntityValue('HasData');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemUnsSystem.GetEntitySchema = function () {
            var columns = {
                'CanonicalName': {
                    ColumnName: 'CanonicalName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'DisplayName': {
                    ColumnName: 'DisplayName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DistinguishedName': {
                    ColumnName: 'DistinguishedName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Ident_UNSRoot': {
                    ColumnName: 'Ident_UNSRoot',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'MatchPatternDisplay': {
                    ColumnName: 'MatchPatternDisplay',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'NamespaceManagedBy': {
                    ColumnName: 'NamespaceManagedBy',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_AERoleOwner': {
                    ColumnName: 'UID_AERoleOwner',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DPRNameSpace': {
                    ColumnName: 'UID_DPRNameSpace',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_TSBAccountDef': {
                    ColumnName: 'UID_TSBAccountDef',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSRoot': {
                    ColumnName: 'UID_UNSRoot',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XDateUpdated': {
                    ColumnName: 'XDateUpdated',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XTouched': {
                    ColumnName: 'XTouched',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserInserted': {
                    ColumnName: 'XUserInserted',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserUpdated': {
                    ColumnName: 'XUserUpdated',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'HasSync': {
                    ColumnName: 'HasSync',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'HasData': {
                    ColumnName: 'HasData',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'UNSRoot', Columns: columns };
        };
        return PortalTargetsystemUnsSystem;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemUnsSystem type. */
    var PortalTargetsystemUnsSystemInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemUnsSystemInteractive, _super);
        function PortalTargetsystemUnsSystemInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemUnsSystemInteractive;
    }(PortalTargetsystemUnsSystem));
    var PortalUnsgroupb1Memberships = /** @class */ (function (_super) {
        __extends(PortalUnsgroupb1Memberships, _super);
        function PortalUnsgroupb1Memberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalUnsgroupb1Memberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalUnsgroupb1Memberships;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalUnsgroupb1Memberships type. */
    var PortalUnsgroupb1MembershipsInteractive = /** @class */ (function (_super) {
        __extends(PortalUnsgroupb1MembershipsInteractive, _super);
        function PortalUnsgroupb1MembershipsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalUnsgroupb1MembershipsInteractive;
    }(PortalUnsgroupb1Memberships));
    var PortalUnsgroupb2Memberships = /** @class */ (function (_super) {
        __extends(PortalUnsgroupb2Memberships, _super);
        function PortalUnsgroupb2Memberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalUnsgroupb2Memberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalUnsgroupb2Memberships;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalUnsgroupb2Memberships type. */
    var PortalUnsgroupb2MembershipsInteractive = /** @class */ (function (_super) {
        __extends(PortalUnsgroupb2MembershipsInteractive, _super);
        function PortalUnsgroupb2MembershipsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalUnsgroupb2MembershipsInteractive;
    }(PortalUnsgroupb2Memberships));
    var PortalUnsgroupb3Memberships = /** @class */ (function (_super) {
        __extends(PortalUnsgroupb3Memberships, _super);
        function PortalUnsgroupb3Memberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalUnsgroupb3Memberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalUnsgroupb3Memberships;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalUnsgroupb3Memberships type. */
    var PortalUnsgroupb3MembershipsInteractive = /** @class */ (function (_super) {
        __extends(PortalUnsgroupb3MembershipsInteractive, _super);
        function PortalUnsgroupb3MembershipsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalUnsgroupb3MembershipsInteractive;
    }(PortalUnsgroupb3Memberships));
    var PortalUnsgroupbMemberships = /** @class */ (function (_super) {
        __extends(PortalUnsgroupbMemberships, _super);
        function PortalUnsgroupbMemberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalUnsgroupbMemberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalUnsgroupbMemberships;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalUnsgroupbMemberships type. */
    var PortalUnsgroupbMembershipsInteractive = /** @class */ (function (_super) {
        __extends(PortalUnsgroupbMembershipsInteractive, _super);
        function PortalUnsgroupbMembershipsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalUnsgroupbMembershipsInteractive;
    }(PortalUnsgroupbMemberships));
    var PortalCandidatesAccproductgroupWrapper = /** @class */ (function () {
        function PortalCandidatesAccproductgroupWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesAccproductgroupWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/AccProductGroup');
        };
        PortalCandidatesAccproductgroupWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/AccProductGroup');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesAccproductgroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesAccproductgroupWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_AccProductGroup_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesAccproductgroupWrapper;
    }());
    var PortalCandidatesAccproductparamcategoryWrapper = /** @class */ (function () {
        function PortalCandidatesAccproductparamcategoryWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesAccproductparamcategoryWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/AccProductParamCategory');
        };
        PortalCandidatesAccproductparamcategoryWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/AccProductParamCategory');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesAccproductparamcategory, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesAccproductparamcategoryWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_AccProductParamCategory_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesAccproductparamcategoryWrapper;
    }());
    var PortalClaimgroupGroupWrapper = /** @class */ (function () {
        function PortalClaimgroupGroupWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalClaimgroupGroupWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/claimgroup/group');
        };
        PortalClaimgroupGroupWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/claimgroup/group');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalClaimgroupGroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalClaimgroupGroupWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_claimgroup_group_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalClaimgroupGroupWrapper;
    }());
    var PortalClaimgroupSuggestedownerWrapper = /** @class */ (function () {
        function PortalClaimgroupSuggestedownerWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalClaimgroupSuggestedownerWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/claimgroup/suggestedowner/{tablename}/{uidunsgroup}');
        };
        PortalClaimgroupSuggestedownerWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/claimgroup/suggestedowner/{tablename}/{uidunsgroup}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalClaimgroupSuggestedowner, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalClaimgroupSuggestedownerWrapper.prototype.Get = function (tablename, uidunsgroup, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_claimgroup_suggestedowner_get(tablename, uidunsgroup, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalClaimgroupSuggestedownerWrapper;
    }());
    var PortalClaimgroupSuggestedowner2Wrapper = /** @class */ (function () {
        function PortalClaimgroupSuggestedowner2Wrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalClaimgroupSuggestedowner2Wrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/claimgroup/suggestedowner2/{tablename}/{uidunsgroup}');
        };
        PortalClaimgroupSuggestedowner2Wrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/claimgroup/suggestedowner2/{tablename}/{uidunsgroup}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalClaimgroupSuggestedowner2, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalClaimgroupSuggestedowner2Wrapper.prototype.Get = function (tablename, uidunsgroup, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_claimgroup_suggestedowner2_get(tablename, uidunsgroup, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalClaimgroupSuggestedowner2Wrapper;
    }());
    var PortalPersonAccountsWrapper = /** @class */ (function () {
        function PortalPersonAccountsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalPersonAccountsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/person/{uid}/accounts');
        };
        PortalPersonAccountsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/person/{uid}/accounts');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalPersonAccounts, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalPersonAccountsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_accounts_get(uid, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalPersonAccountsWrapper;
    }());
    var PortalPersonGroupmembershipsWrapper = /** @class */ (function () {
        function PortalPersonGroupmembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalPersonGroupmembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/person/{uid}/groupmemberships');
        };
        PortalPersonGroupmembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/person/{uid}/groupmemberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalPersonGroupmemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalPersonGroupmembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_groupmemberships_get(uid, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalPersonGroupmembershipsWrapper;
    }());
    var PortalRespUnsgroupWrapper = /** @class */ (function () {
        function PortalRespUnsgroupWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalRespUnsgroupWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/unsgroup');
        };
        PortalRespUnsgroupWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/unsgroup');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRespUnsgroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespUnsgroupWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroup_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespUnsgroupWrapper;
    }());
    var PortalRespUnsgroupbWrapper = /** @class */ (function () {
        function PortalRespUnsgroupbWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalRespUnsgroupbWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/unsgroupb');
        };
        PortalRespUnsgroupbWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/unsgroupb');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRespUnsgroupb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespUnsgroupbWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespUnsgroupbWrapper;
    }());
    var PortalRespUnsgroupb1Wrapper = /** @class */ (function () {
        function PortalRespUnsgroupb1Wrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalRespUnsgroupb1Wrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/unsgroupb1');
        };
        PortalRespUnsgroupb1Wrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/unsgroupb1');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRespUnsgroupb1, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespUnsgroupb1Wrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb1_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespUnsgroupb1Wrapper;
    }());
    var PortalRespUnsgroupb1InteractiveWrapper = /** @class */ (function () {
        function PortalRespUnsgroupb1InteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_resp_unsgroupb1_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalRespUnsgroupb1InteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/unsgroupb1/interactive');
        };
        PortalRespUnsgroupb1InteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/unsgroupb1/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalRespUnsgroupb1, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespUnsgroupb1InteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb1_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRespUnsgroupb1InteractiveWrapper.prototype.Get_byid = function (UID_UNSGroupB1, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb1_interactive_byid_get(UID_UNSGroupB1, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespUnsgroupb1InteractiveWrapper;
    }());
    var PortalRespUnsgroupb2Wrapper = /** @class */ (function () {
        function PortalRespUnsgroupb2Wrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalRespUnsgroupb2Wrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/unsgroupb2');
        };
        PortalRespUnsgroupb2Wrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/unsgroupb2');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRespUnsgroupb2, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespUnsgroupb2Wrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb2_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespUnsgroupb2Wrapper;
    }());
    var PortalRespUnsgroupb2InteractiveWrapper = /** @class */ (function () {
        function PortalRespUnsgroupb2InteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_resp_unsgroupb2_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalRespUnsgroupb2InteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/unsgroupb2/interactive');
        };
        PortalRespUnsgroupb2InteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/unsgroupb2/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalRespUnsgroupb2, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespUnsgroupb2InteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb2_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRespUnsgroupb2InteractiveWrapper.prototype.Get_byid = function (UID_UNSGroupB2, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb2_interactive_byid_get(UID_UNSGroupB2, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespUnsgroupb2InteractiveWrapper;
    }());
    var PortalRespUnsgroupb3Wrapper = /** @class */ (function () {
        function PortalRespUnsgroupb3Wrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalRespUnsgroupb3Wrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/unsgroupb3');
        };
        PortalRespUnsgroupb3Wrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/unsgroupb3');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRespUnsgroupb3, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespUnsgroupb3Wrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb3_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespUnsgroupb3Wrapper;
    }());
    var PortalRespUnsgroupb3InteractiveWrapper = /** @class */ (function () {
        function PortalRespUnsgroupb3InteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_resp_unsgroupb3_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalRespUnsgroupb3InteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/unsgroupb3/interactive');
        };
        PortalRespUnsgroupb3InteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/unsgroupb3/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalRespUnsgroupb3, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespUnsgroupb3InteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb3_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRespUnsgroupb3InteractiveWrapper.prototype.Get_byid = function (UID_UNSGroupB3, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb3_interactive_byid_get(UID_UNSGroupB3, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespUnsgroupb3InteractiveWrapper;
    }());
    var PortalRespUnsgroupbInteractiveWrapper = /** @class */ (function () {
        function PortalRespUnsgroupbInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_resp_unsgroupb_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalRespUnsgroupbInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/resp/unsgroupb/interactive');
        };
        PortalRespUnsgroupbInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/resp/unsgroupb/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalRespUnsgroupb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRespUnsgroupbInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRespUnsgroupbInteractiveWrapper.prototype.Get_byid = function (UID_UNSGroupB, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_resp_unsgroupb_interactive_byid_get(UID_UNSGroupB, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRespUnsgroupbInteractiveWrapper;
    }());
    var PortalShopConfigEntitlementsTsbaccountdefWrapper = /** @class */ (function () {
        function PortalShopConfigEntitlementsTsbaccountdefWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_shop_config_entitlements_TSBAccountDef_post(entity.GetColumn('UID_ITShopOrg').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_shop_config_entitlements_TSBAccountDef_delete(entity.GetColumn('UID_ITShopOrg').GetValue(), entity.GetColumn('UID_TSBAccountDef').GetValue());
            };
        }
        PortalShopConfigEntitlementsTsbaccountdefWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalShopConfigEntitlementsTsbaccountdefWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef');
        };
        PortalShopConfigEntitlementsTsbaccountdefWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalShopConfigEntitlementsTsbaccountdef, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalShopConfigEntitlementsTsbaccountdefWrapper.prototype.Get = function (UID_ITShopOrg, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_TSBAccountDef_get(UID_ITShopOrg, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsTsbaccountdefWrapper.prototype.Post = function (UID_ITShopOrg, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_TSBAccountDef_post(UID_ITShopOrg, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsTsbaccountdefWrapper.prototype.Delete = function (UID_ITShopOrg, UID_TSBAccountDef, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_TSBAccountDef_delete(UID_ITShopOrg, UID_TSBAccountDef, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalShopConfigEntitlementsTsbaccountdefWrapper;
    }());
    var PortalShopConfigEntitlementsUnsgroupbWrapper = /** @class */ (function () {
        function PortalShopConfigEntitlementsUnsgroupbWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_shop_config_entitlements_UNSGroupB_post(entity.GetColumn('UID_ITShopOrg').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_shop_config_entitlements_UNSGroupB_delete(entity.GetColumn('UID_ITShopOrg').GetValue(), entity.GetColumn('UID_UNSGroupB').GetValue());
            };
        }
        PortalShopConfigEntitlementsUnsgroupbWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalShopConfigEntitlementsUnsgroupbWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB');
        };
        PortalShopConfigEntitlementsUnsgroupbWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalShopConfigEntitlementsUnsgroupb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalShopConfigEntitlementsUnsgroupbWrapper.prototype.Get = function (UID_ITShopOrg, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB_get(UID_ITShopOrg, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsUnsgroupbWrapper.prototype.Post = function (UID_ITShopOrg, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB_post(UID_ITShopOrg, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsUnsgroupbWrapper.prototype.Delete = function (UID_ITShopOrg, UID_UNSGroupB, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB_delete(UID_ITShopOrg, UID_UNSGroupB, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalShopConfigEntitlementsUnsgroupbWrapper;
    }());
    var PortalShopConfigEntitlementsUnsgroupb1Wrapper = /** @class */ (function () {
        function PortalShopConfigEntitlementsUnsgroupb1Wrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_shop_config_entitlements_UNSGroupB1_post(entity.GetColumn('UID_ITShopOrg').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_shop_config_entitlements_UNSGroupB1_delete(entity.GetColumn('UID_ITShopOrg').GetValue(), entity.GetColumn('UID_UNSGroupB1').GetValue());
            };
        }
        PortalShopConfigEntitlementsUnsgroupb1Wrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalShopConfigEntitlementsUnsgroupb1Wrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1');
        };
        PortalShopConfigEntitlementsUnsgroupb1Wrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalShopConfigEntitlementsUnsgroupb1, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalShopConfigEntitlementsUnsgroupb1Wrapper.prototype.Get = function (UID_ITShopOrg, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB1_get(UID_ITShopOrg, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsUnsgroupb1Wrapper.prototype.Post = function (UID_ITShopOrg, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB1_post(UID_ITShopOrg, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsUnsgroupb1Wrapper.prototype.Delete = function (UID_ITShopOrg, UID_UNSGroupB1, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB1_delete(UID_ITShopOrg, UID_UNSGroupB1, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalShopConfigEntitlementsUnsgroupb1Wrapper;
    }());
    var PortalShopConfigEntitlementsUnsgroupb2Wrapper = /** @class */ (function () {
        function PortalShopConfigEntitlementsUnsgroupb2Wrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_shop_config_entitlements_UNSGroupB2_post(entity.GetColumn('UID_ITShopOrg').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_shop_config_entitlements_UNSGroupB2_delete(entity.GetColumn('UID_ITShopOrg').GetValue(), entity.GetColumn('UID_UNSGroupB2').GetValue());
            };
        }
        PortalShopConfigEntitlementsUnsgroupb2Wrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalShopConfigEntitlementsUnsgroupb2Wrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2');
        };
        PortalShopConfigEntitlementsUnsgroupb2Wrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalShopConfigEntitlementsUnsgroupb2, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalShopConfigEntitlementsUnsgroupb2Wrapper.prototype.Get = function (UID_ITShopOrg, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB2_get(UID_ITShopOrg, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsUnsgroupb2Wrapper.prototype.Post = function (UID_ITShopOrg, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB2_post(UID_ITShopOrg, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsUnsgroupb2Wrapper.prototype.Delete = function (UID_ITShopOrg, UID_UNSGroupB2, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB2_delete(UID_ITShopOrg, UID_UNSGroupB2, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalShopConfigEntitlementsUnsgroupb2Wrapper;
    }());
    var PortalShopConfigEntitlementsUnsgroupb3Wrapper = /** @class */ (function () {
        function PortalShopConfigEntitlementsUnsgroupb3Wrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_shop_config_entitlements_UNSGroupB3_post(entity.GetColumn('UID_ITShopOrg').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_shop_config_entitlements_UNSGroupB3_delete(entity.GetColumn('UID_ITShopOrg').GetValue(), entity.GetColumn('UID_UNSGroupB3').GetValue());
            };
        }
        PortalShopConfigEntitlementsUnsgroupb3Wrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalShopConfigEntitlementsUnsgroupb3Wrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3');
        };
        PortalShopConfigEntitlementsUnsgroupb3Wrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalShopConfigEntitlementsUnsgroupb3, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalShopConfigEntitlementsUnsgroupb3Wrapper.prototype.Get = function (UID_ITShopOrg, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB3_get(UID_ITShopOrg, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsUnsgroupb3Wrapper.prototype.Post = function (UID_ITShopOrg, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB3_post(UID_ITShopOrg, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalShopConfigEntitlementsUnsgroupb3Wrapper.prototype.Delete = function (UID_ITShopOrg, UID_UNSGroupB3, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_UNSGroupB3_delete(UID_ITShopOrg, UID_UNSGroupB3, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalShopConfigEntitlementsUnsgroupb3Wrapper;
    }());
    var PortalTargetsystemUnsAccountWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsAccountWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsAccountWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/uns/account');
        };
        PortalTargetsystemUnsAccountWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/uns/account');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsAccount, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsAccountWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_account_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsAccountWrapper;
    }());
    var PortalTargetsystemUnsaccountbWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsaccountbWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsaccountb_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsaccountbWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsaccountb');
        };
        PortalTargetsystemUnsaccountbWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsaccountb');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsaccountb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsaccountbWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsaccountb_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsaccountbWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsaccountb_put(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsaccountbWrapper;
    }());
    var PortalTargetsystemUnsaccountbInteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsaccountbInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsaccountb_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsaccountbInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsaccountb/interactive');
        };
        PortalTargetsystemUnsaccountbInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsaccountb/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemUnsaccountb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsaccountbInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsaccountb_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsaccountbInteractiveWrapper.prototype.Get_byid = function (UID_UNSAccountB, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsaccountb_interactive_byid_get(UID_UNSAccountB, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsaccountbInteractiveWrapper;
    }());
    var PortalTargetsystemUnsContainerWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsContainerWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsContainerWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/uns/container');
        };
        PortalTargetsystemUnsContainerWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/uns/container');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsContainer, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsContainerWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_container_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsContainerWrapper;
    }());
    var PortalTargetsystemUnscontainerbWrapper = /** @class */ (function () {
        function PortalTargetsystemUnscontainerbWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unscontainerb_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnscontainerbWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unscontainerb');
        };
        PortalTargetsystemUnscontainerbWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unscontainerb');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnscontainerb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnscontainerbWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unscontainerb_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnscontainerbWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unscontainerb_put(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnscontainerbWrapper;
    }());
    var PortalTargetsystemUnscontainerbInteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemUnscontainerbInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unscontainerb_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnscontainerbInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unscontainerb/interactive');
        };
        PortalTargetsystemUnscontainerbInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unscontainerb/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemUnscontainerb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnscontainerbInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unscontainerb_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnscontainerbInteractiveWrapper.prototype.Get_byid = function (UID_UNSContainerB, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unscontainerb_interactive_byid_get(UID_UNSContainerB, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnscontainerbInteractiveWrapper;
    }());
    var PortalTargetsystemUnsDirectmembersWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsDirectmembersWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsDirectmembersWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/uns/directmembers/{UID_UNSGroup}');
        };
        PortalTargetsystemUnsDirectmembersWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/uns/directmembers/{UID_UNSGroup}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsDirectmembers, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsDirectmembersWrapper.prototype.Get = function (UID_UNSGroup, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_directmembers_get(UID_UNSGroup, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsDirectmembersWrapper;
    }());
    var PortalTargetsystemUnsGroupWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsGroupWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsGroupWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/uns/group');
        };
        PortalTargetsystemUnsGroupWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/uns/group');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsGroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsGroupWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_group_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsGroupWrapper;
    }());
    var PortalTargetsystemUnsgroupbWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsgroupbWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsgroupb_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsgroupbWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsgroupb');
        };
        PortalTargetsystemUnsgroupbWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsgroupb');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsgroupb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsgroupbWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsgroupbWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsgroupbWrapper;
    }());
    var PortalTargetsystemUnsgroupb1Wrapper = /** @class */ (function () {
        function PortalTargetsystemUnsgroupb1Wrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsgroupb1_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsgroupb1Wrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsgroupb1');
        };
        PortalTargetsystemUnsgroupb1Wrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsgroupb1');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsgroupb1, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsgroupb1Wrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb1_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsgroupb1Wrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb1_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsgroupb1Wrapper;
    }());
    var PortalTargetsystemUnsgroupb1InteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsgroupb1InteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsgroupb1_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsgroupb1InteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsgroupb1/interactive');
        };
        PortalTargetsystemUnsgroupb1InteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsgroupb1/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemUnsgroupb1, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsgroupb1InteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb1_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsgroupb1InteractiveWrapper.prototype.Get_byid = function (UID_UNSGroupB1, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb1_interactive_byid_get(UID_UNSGroupB1, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsgroupb1InteractiveWrapper;
    }());
    var PortalTargetsystemUnsgroupb2Wrapper = /** @class */ (function () {
        function PortalTargetsystemUnsgroupb2Wrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsgroupb2_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsgroupb2Wrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsgroupb2');
        };
        PortalTargetsystemUnsgroupb2Wrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsgroupb2');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsgroupb2, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsgroupb2Wrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb2_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsgroupb2Wrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb2_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsgroupb2Wrapper;
    }());
    var PortalTargetsystemUnsgroupb2InteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsgroupb2InteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsgroupb2_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsgroupb2InteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsgroupb2/interactive');
        };
        PortalTargetsystemUnsgroupb2InteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsgroupb2/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemUnsgroupb2, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsgroupb2InteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb2_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsgroupb2InteractiveWrapper.prototype.Get_byid = function (UID_UNSGroupB2, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb2_interactive_byid_get(UID_UNSGroupB2, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsgroupb2InteractiveWrapper;
    }());
    var PortalTargetsystemUnsgroupb3Wrapper = /** @class */ (function () {
        function PortalTargetsystemUnsgroupb3Wrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsgroupb3_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsgroupb3Wrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsgroupb3');
        };
        PortalTargetsystemUnsgroupb3Wrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsgroupb3');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsgroupb3, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsgroupb3Wrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb3_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsgroupb3Wrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb3_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsgroupb3Wrapper;
    }());
    var PortalTargetsystemUnsgroupb3InteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsgroupb3InteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsgroupb3_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsgroupb3InteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsgroupb3/interactive');
        };
        PortalTargetsystemUnsgroupb3InteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsgroupb3/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemUnsgroupb3, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsgroupb3InteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb3_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsgroupb3InteractiveWrapper.prototype.Get_byid = function (UID_UNSGroupB3, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb3_interactive_byid_get(UID_UNSGroupB3, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsgroupb3InteractiveWrapper;
    }());
    var PortalTargetsystemUnsgroupbInteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsgroupbInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsgroupb_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsgroupbInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsgroupb/interactive');
        };
        PortalTargetsystemUnsgroupbInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsgroupb/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemUnsgroupb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsgroupbInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsgroupbInteractiveWrapper.prototype.Get_byid = function (UID_UNSGroupB, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsgroupb_interactive_byid_get(UID_UNSGroupB, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsgroupbInteractiveWrapper;
    }());
    var PortalTargetsystemUnsGroupmembersWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsGroupmembersWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsGroupmembersWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/uns/groupmembers/{uidgroup}');
        };
        PortalTargetsystemUnsGroupmembersWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/uns/groupmembers/{uidgroup}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsGroupmembers, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsGroupmembersWrapper.prototype.Get = function (uidgroup, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_groupmembers_get(uidgroup, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsGroupmembersWrapper;
    }());
    var PortalTargetsystemUnsGroupServiceitemWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsGroupServiceitemWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_uns_group_serviceitem_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsGroupServiceitemWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/uns/group/serviceitem');
        };
        PortalTargetsystemUnsGroupServiceitemWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/uns/group/serviceitem');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsGroupServiceitem, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsGroupServiceitemWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_group_serviceitem_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsGroupServiceitemWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_group_serviceitem_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsGroupServiceitemWrapper;
    }());
    var PortalTargetsystemUnsGroupServiceitemInteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsGroupServiceitemInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_uns_group_serviceitem_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsGroupServiceitemInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/uns/group/serviceitem/interactive');
        };
        PortalTargetsystemUnsGroupServiceitemInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/uns/group/serviceitem/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemUnsGroupServiceitem, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsGroupServiceitemInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_group_serviceitem_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsGroupServiceitemInteractiveWrapper.prototype.Get_byid = function (UID_AccProduct, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_group_serviceitem_interactive_byid_get(UID_AccProduct, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsGroupServiceitemInteractiveWrapper;
    }());
    var PortalTargetsystemUnsitembWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsitembWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsitemb_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsitembWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsitemb');
        };
        PortalTargetsystemUnsitembWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsitemb');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsitemb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsitembWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsitemb_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsitembWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsitemb_put(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsitembWrapper;
    }());
    var PortalTargetsystemUnsitembInteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsitembInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_unsitemb_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsitembInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/unsitemb/interactive');
        };
        PortalTargetsystemUnsitembInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/unsitemb/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemUnsitemb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsitembInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsitemb_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemUnsitembInteractiveWrapper.prototype.Get_byid = function (UID_UNSItemB, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_unsitemb_interactive_byid_get(UID_UNSItemB, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsitembInteractiveWrapper;
    }());
    var PortalTargetsystemUnsNestedmembersWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsNestedmembersWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsNestedmembersWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/uns/nestedmembers/{uid}');
        };
        PortalTargetsystemUnsNestedmembersWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/uns/nestedmembers/{uid}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsNestedmembers, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsNestedmembersWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_nestedmembers_get(uid, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsNestedmembersWrapper;
    }());
    var PortalTargetsystemUnsSystemWrapper = /** @class */ (function () {
        function PortalTargetsystemUnsSystemWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemUnsSystemWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/uns/system');
        };
        PortalTargetsystemUnsSystemWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/uns/system');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemUnsSystem, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemUnsSystemWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_uns_system_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemUnsSystemWrapper;
    }());
    var PortalUnsgroupb1MembershipsWrapper = /** @class */ (function () {
        function PortalUnsgroupb1MembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalUnsgroupb1MembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/UNSGroupB1/{uid}/memberships');
        };
        PortalUnsgroupb1MembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/UNSGroupB1/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalUnsgroupb1Memberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalUnsgroupb1MembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_UNSGroupB1_memberships_get(uid, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalUnsgroupb1MembershipsWrapper;
    }());
    var PortalUnsgroupb2MembershipsWrapper = /** @class */ (function () {
        function PortalUnsgroupb2MembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalUnsgroupb2MembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/UNSGroupB2/{uid}/memberships');
        };
        PortalUnsgroupb2MembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/UNSGroupB2/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalUnsgroupb2Memberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalUnsgroupb2MembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_UNSGroupB2_memberships_get(uid, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalUnsgroupb2MembershipsWrapper;
    }());
    var PortalUnsgroupb3MembershipsWrapper = /** @class */ (function () {
        function PortalUnsgroupb3MembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalUnsgroupb3MembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/UNSGroupB3/{uid}/memberships');
        };
        PortalUnsgroupb3MembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/UNSGroupB3/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalUnsgroupb3Memberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalUnsgroupb3MembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_UNSGroupB3_memberships_get(uid, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalUnsgroupb3MembershipsWrapper;
    }());
    var PortalUnsgroupbMembershipsWrapper = /** @class */ (function () {
        function PortalUnsgroupbMembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalUnsgroupbMembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/UNSGroupB/{uid}/memberships');
        };
        PortalUnsgroupbMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/UNSGroupB/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalUnsgroupbMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalUnsgroupbMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_UNSGroupB_memberships_get(uid, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalUnsgroupbMembershipsWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.portal_candidates_AccProductGroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/candidates/AccProductGroup',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_AccProductGroup_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/AccProductGroup/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_AccProductParamCategory_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/candidates/AccProductParamCategory',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_AccProductParamCategory_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/AccProductParamCategory/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_claimgroup_post = function (uidperson, tablename, uidunsgroup) {
            return {
                path: '/portal/claimgroup/{uidperson}/{tablename}/{uidunsgroup}',
                parameters: [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'tablename',
                        value: tablename,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidunsgroup',
                        value: uidunsgroup,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_claimgroup_group_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/claimgroup/group',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_claimgroup_suggestedowner_get = function (tablename, uidunsgroup, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/claimgroup/suggestedowner/{tablename}/{uidunsgroup}',
                parameters: [
                    {
                        name: 'tablename',
                        value: tablename,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidunsgroup',
                        value: uidunsgroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_claimgroup_suggestedowner2_get = function (tablename, uidunsgroup, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/claimgroup/suggestedowner2/{tablename}/{uidunsgroup}',
                parameters: [
                    {
                        name: 'tablename',
                        value: tablename,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidunsgroup',
                        value: uidunsgroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_accounts_get = function (uid, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/person/{uid}/accounts',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_groupmemberships_get = function (uid, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/person/{uid}/groupmemberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroup_get = function (system, container, OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk, namespace) {
            return {
                path: '/portal/resp/unsgroup',
                parameters: [
                    {
                        name: 'system',
                        value: system,
                        in: 'query'
                    },
                    {
                        name: 'container',
                        value: container,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                    {
                        name: 'namespace',
                        value: namespace,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroup_datamodel_get = function (filter) {
            return {
                path: '/portal/resp/unsgroup/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk) {
            return {
                path: '/portal/resp/unsgroupb',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb_datamodel_get = function (filter) {
            return {
                path: '/portal/resp/unsgroupb/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/resp/unsgroupb/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb_interactive_byid_get = function (UID_UNSGroupB) {
            return {
                path: '/portal/resp/unsgroupb/interactive/{UID_UNSGroupB}',
                parameters: [
                    {
                        name: 'UID_UNSGroupB',
                        value: UID_UNSGroupB,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb1_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk) {
            return {
                path: '/portal/resp/unsgroupb1',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb1_datamodel_get = function (filter) {
            return {
                path: '/portal/resp/unsgroupb1/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb1_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/resp/unsgroupb1/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb1_interactive_byid_get = function (UID_UNSGroupB1) {
            return {
                path: '/portal/resp/unsgroupb1/interactive/{UID_UNSGroupB1}',
                parameters: [
                    {
                        name: 'UID_UNSGroupB1',
                        value: UID_UNSGroupB1,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb2_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk) {
            return {
                path: '/portal/resp/unsgroupb2',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb2_datamodel_get = function (filter) {
            return {
                path: '/portal/resp/unsgroupb2/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb2_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/resp/unsgroupb2/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb2_interactive_byid_get = function (UID_UNSGroupB2) {
            return {
                path: '/portal/resp/unsgroupb2/interactive/{UID_UNSGroupB2}',
                parameters: [
                    {
                        name: 'UID_UNSGroupB2',
                        value: UID_UNSGroupB2,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb3_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk) {
            return {
                path: '/portal/resp/unsgroupb3',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb3_datamodel_get = function (filter) {
            return {
                path: '/portal/resp/unsgroupb3/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb3_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/resp/unsgroupb3/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_resp_unsgroupb3_interactive_byid_get = function (UID_UNSGroupB3) {
            return {
                path: '/portal/resp/unsgroupb3/interactive/{UID_UNSGroupB3}',
                parameters: [
                    {
                        name: 'UID_UNSGroupB3',
                        value: UID_UNSGroupB3,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_post = function (UID_ITShopOrg, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_delete = function (UID_ITShopOrg, UID_TSBAccountDef) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/{UID_TSBAccountDef}',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_TSBAccountDef',
                        value: UID_TSBAccountDef,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_post = function (UID_ITShopOrg, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_delete = function (UID_ITShopOrg, UID_UNSGroupB) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/{UID_UNSGroupB}',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_UNSGroupB',
                        value: UID_UNSGroupB,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_post = function (UID_ITShopOrg, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_delete = function (UID_ITShopOrg, UID_UNSGroupB1) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/{UID_UNSGroupB1}',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_UNSGroupB1',
                        value: UID_UNSGroupB1,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_post = function (UID_ITShopOrg, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_delete = function (UID_ITShopOrg, UID_UNSGroupB2) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/{UID_UNSGroupB2}',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_UNSGroupB2',
                        value: UID_UNSGroupB2,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_post = function (UID_ITShopOrg, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_delete = function (UID_ITShopOrg, UID_UNSGroupB3) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/{UID_UNSGroupB3}',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_UNSGroupB3',
                        value: UID_UNSGroupB3,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_get = function (container, system, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, inactive, deletedintarget, risk, namespace) {
            return {
                path: '/portal/targetsystem/uns/account',
                parameters: [
                    {
                        name: 'container',
                        value: container,
                        in: 'query'
                    },
                    {
                        name: 'system',
                        value: system,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'orphaned',
                        value: orphaned,
                        in: 'query'
                    },
                    {
                        name: 'inactive',
                        value: inactive,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                    {
                        name: 'namespace',
                        value: namespace,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_report_get = function (tablename, historydays, uidaccount) {
            return {
                path: '/portal/targetsystem/uns/account/{tablename}/{uidaccount}/report',
                parameters: [
                    {
                        name: 'tablename',
                        value: tablename,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'historydays',
                        value: historydays,
                        in: 'query'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/uns/account/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_filtertree_get = function (container, system, filter, parentkey) {
            return {
                path: '/portal/targetsystem/uns/account/filtertree',
                parameters: [
                    {
                        name: 'container',
                        value: container,
                        in: 'query'
                    },
                    {
                        name: 'system',
                        value: system,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_ownedby_report_get = function (historydays, uidperson) {
            return {
                path: '/portal/targetsystem/uns/account/ownedby/{uidperson}/report',
                parameters: [
                    {
                        name: 'historydays',
                        value: historydays,
                        in: 'query'
                    },
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_ownedbymanaged_report_get = function (historydays, uidperson) {
            return {
                path: '/portal/targetsystem/uns/account/ownedbymanaged/{uidperson}/report',
                parameters: [
                    {
                        name: 'historydays',
                        value: historydays,
                        in: 'query'
                    },
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_container_get = function (system, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, namespace) {
            return {
                path: '/portal/targetsystem/uns/container',
                parameters: [
                    {
                        name: 'system',
                        value: system,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                    {
                        name: 'namespace',
                        value: namespace,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_container_accounts_report_get = function (historydays, uidcontainer) {
            return {
                path: '/portal/targetsystem/uns/container/{uidcontainer}/accounts/report',
                parameters: [
                    {
                        name: 'historydays',
                        value: historydays,
                        in: 'query'
                    },
                    {
                        name: 'uidcontainer',
                        value: uidcontainer,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_container_groups_report_get = function (historydays, uidcontainer) {
            return {
                path: '/portal/targetsystem/uns/container/{uidcontainer}/groups/report',
                parameters: [
                    {
                        name: 'historydays',
                        value: historydays,
                        in: 'query'
                    },
                    {
                        name: 'uidcontainer',
                        value: uidcontainer,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_container_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/uns/container/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_directmembers_get = function (UID_UNSGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/uns/directmembers/{UID_UNSGroup}',
                parameters: [
                    {
                        name: 'UID_UNSGroup',
                        value: UID_UNSGroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_get = function (uid_unsaccount, container, system, OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, namespace) {
            return {
                path: '/portal/targetsystem/uns/group',
                parameters: [
                    {
                        name: 'uid_unsaccount',
                        value: uid_unsaccount,
                        in: 'query'
                    },
                    {
                        name: 'container',
                        value: container,
                        in: 'query'
                    },
                    {
                        name: 'system',
                        value: system,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'withowner',
                        value: withowner,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                    {
                        name: 'namespace',
                        value: namespace,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_report_get = function (historydays, uidgroup) {
            return {
                path: '/portal/targetsystem/uns/group/{uidgroup}/report',
                parameters: [
                    {
                        name: 'historydays',
                        value: historydays,
                        in: 'query'
                    },
                    {
                        name: 'uidgroup',
                        value: uidgroup,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/uns/group/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_filtertree_get = function (uid_unsaccount, container, system, filter, parentkey) {
            return {
                path: '/portal/targetsystem/uns/group/filtertree',
                parameters: [
                    {
                        name: 'uid_unsaccount',
                        value: uid_unsaccount,
                        in: 'query'
                    },
                    {
                        name: 'container',
                        value: container,
                        in: 'query'
                    },
                    {
                        name: 'system',
                        value: system,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_byid_get = function (UID_AccProduct) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/{UID_AccProduct}',
                parameters: [
                    {
                        name: 'UID_AccProduct',
                        value: UID_AccProduct,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_OrgAttestator/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_OrgAttestator/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_OrgRuler/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_OrgRuler/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_PWODecisionMethod/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_PWODecisionMethod/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_OrgAttestator/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_OrgAttestator/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_OrgRuler/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_OrgRuler/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_PWODecisionMethod/candidates',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_PWODecisionMethod/candidates/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_groupmembers_get = function (uidgroup, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/uns/groupmembers/{uidgroup}',
                parameters: [
                    {
                        name: 'uidgroup',
                        value: uidgroup,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_nestedmembers_get = function (uid, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/uns/nestedmembers/{uid}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_ownedby_report_get = function (historydays, uidperson) {
            return {
                path: '/portal/targetsystem/uns/ownedby/{uidperson}/report',
                parameters: [
                    {
                        name: 'historydays',
                        value: historydays,
                        in: 'query'
                    },
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_person_managed_report_get = function (uidperson) {
            return {
                path: '/portal/targetsystem/uns/person/{uidperson}/managed/report',
                parameters: [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_person_report_get = function (IncludeSubIdentities, IncludeHistory, uidperson, historydays) {
            return {
                path: '/portal/targetsystem/uns/person/{uidperson}/report',
                parameters: [
                    {
                        name: 'IncludeSubIdentities',
                        value: IncludeSubIdentities,
                        in: 'query'
                    },
                    {
                        name: 'IncludeHistory',
                        value: IncludeHistory,
                        in: 'query'
                    },
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'historydays',
                        value: historydays,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_root_accounts_report_get = function (historydays, uidroot) {
            return {
                path: '/portal/targetsystem/uns/root/{uidroot}/accounts/report',
                parameters: [
                    {
                        name: 'historydays',
                        value: historydays,
                        in: 'query'
                    },
                    {
                        name: 'uidroot',
                        value: uidroot,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_root_groups_report_get = function (historydays, uidroot) {
            return {
                path: '/portal/targetsystem/uns/root/{uidroot}/groups/report',
                parameters: [
                    {
                        name: 'historydays',
                        value: historydays,
                        in: 'query'
                    },
                    {
                        name: 'uidroot',
                        value: uidroot,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_system_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, namespace) {
            return {
                path: '/portal/targetsystem/uns/system',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'namespace',
                        value: namespace,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_uns_system_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/uns/system/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk) {
            return {
                path: '/portal/targetsystem/unsaccountb',
                parameters: [
                    {
                        name: 'UID_PersonAssociated',
                        value: UID_PersonAssociated,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'orphaned',
                        value: orphaned,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsaccountb',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsaccountb/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/unsaccountb/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsaccountb/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_interactive_byid_get = function (UID_UNSAccountB) {
            return {
                path: '/portal/targetsystem/unsaccountb/interactive/{UID_UNSAccountB}',
                parameters: [
                    {
                        name: 'UID_UNSAccountB',
                        value: UID_UNSAccountB,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/portal/targetsystem/unscontainerb',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unscontainerb',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unscontainerb/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/unscontainerb/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unscontainerb/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_interactive_byid_get = function (UID_UNSContainerB) {
            return {
                path: '/portal/targetsystem/unscontainerb/interactive/{UID_UNSContainerB}',
                parameters: [
                    {
                        name: 'UID_UNSContainerB',
                        value: UID_UNSContainerB,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
            return {
                path: '/portal/targetsystem/unsgroupb',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'withowner',
                        value: withowner,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/unsgroupb/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_interactive_byid_get = function (UID_UNSGroupB) {
            return {
                path: '/portal/targetsystem/unsgroupb/interactive/{UID_UNSGroupB}',
                parameters: [
                    {
                        name: 'UID_UNSGroupB',
                        value: UID_UNSGroupB,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
            return {
                path: '/portal/targetsystem/unsgroupb1',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'withowner',
                        value: withowner,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb1',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb1/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/unsgroupb1/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb1/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_interactive_byid_get = function (UID_UNSGroupB1) {
            return {
                path: '/portal/targetsystem/unsgroupb1/interactive/{UID_UNSGroupB1}',
                parameters: [
                    {
                        name: 'UID_UNSGroupB1',
                        value: UID_UNSGroupB1,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
            return {
                path: '/portal/targetsystem/unsgroupb2',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'withowner',
                        value: withowner,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb2',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb2/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/unsgroupb2/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb2/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_interactive_byid_get = function (UID_UNSGroupB2) {
            return {
                path: '/portal/targetsystem/unsgroupb2/interactive/{UID_UNSGroupB2}',
                parameters: [
                    {
                        name: 'UID_UNSGroupB2',
                        value: UID_UNSGroupB2,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
            return {
                path: '/portal/targetsystem/unsgroupb3',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'withowner',
                        value: withowner,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb3',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb3/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/unsgroupb3/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsgroupb3/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_interactive_byid_get = function (UID_UNSGroupB3) {
            return {
                path: '/portal/targetsystem/unsgroupb3/interactive/{UID_UNSGroupB3}',
                parameters: [
                    {
                        name: 'UID_UNSGroupB3',
                        value: UID_UNSGroupB3,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/targetsystem/unsitemb',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsitemb',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsitemb/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/unsitemb/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/unsitemb/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_interactive_byid_get = function (UID_UNSItemB) {
            return {
                path: '/portal/targetsystem/unsitemb/interactive/{UID_UNSItemB}',
                parameters: [
                    {
                        name: 'UID_UNSItemB',
                        value: UID_UNSItemB,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_userconfig_get = function () {
            return {
                path: '/portal/targetsystem/userconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_uns_config_get = function () {
            return {
                path: '/portal/uns/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_UNSGroupB_memberships_get = function (uid) {
            return {
                path: '/portal/UNSGroupB/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_UNSGroupB_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/UNSGroupB/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_UNSGroupB1_memberships_get = function (uid) {
            return {
                path: '/portal/UNSGroupB1/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_UNSGroupB1_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/UNSGroupB1/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_UNSGroupB2_memberships_get = function (uid) {
            return {
                path: '/portal/UNSGroupB2/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_UNSGroupB2_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/UNSGroupB2/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_UNSGroupB3_memberships_get = function (uid) {
            return {
                path: '/portal/UNSGroupB3/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_UNSGroupB3_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/UNSGroupB3/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        /** Returns a list of candidate objects from the table AccProductGroup. */
        Client.prototype.portal_candidates_AccProductGroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductGroup_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        /** Returns filter tree information for the candidates/AccProductGroup endpoint. */
        Client.prototype.portal_candidates_AccProductGroup_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductGroup_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of candidate objects from the table AccProductParamCategory. */
        Client.prototype.portal_candidates_AccProductParamCategory_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductParamCategory_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
        Client.prototype.portal_candidates_AccProductParamCategory_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductParamCategory_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Create an attestation case to assign ownership of the specified group to the current user. */
        Client.prototype.portal_claimgroup_post = function (uidperson, tablename, uidunsgroup, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimgroup_post(uidperson, tablename, uidunsgroup), requestOptions);
        };
        /** Returns system entitlements that have no current owner */
        Client.prototype.portal_claimgroup_group_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimgroup_group_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns suggested owners (first suggestions) for the specified group */
        Client.prototype.portal_claimgroup_suggestedowner_get = function (tablename, uidunsgroup, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimgroup_suggestedowner_get(tablename, uidunsgroup, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns suggested owners (second suggestions) for the specified group */
        Client.prototype.portal_claimgroup_suggestedowner2_get = function (tablename, uidunsgroup, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimgroup_suggestedowner2_get(tablename, uidunsgroup, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_person_accounts_get = function (uid, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_accounts_get(uid, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_person_groupmemberships_get = function (uid, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_groupmemberships_get(uid, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_resp_unsgroup_get = function (system, container, OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk, namespace, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroup_get(system, container, OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk, namespace), requestOptions);
        };
        /** Returns data model information about query options for the resp/unsgroup endpoint. */
        Client.prototype.portal_resp_unsgroup_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroup_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk), requestOptions);
        };
        /** Returns data model information about query options for the resp/unsgroupb endpoint. */
        Client.prototype.portal_resp_unsgroupb_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb_interactive_byid_get = function (UID_UNSGroupB, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb_interactive_byid_get(UID_UNSGroupB), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb1_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb1_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk), requestOptions);
        };
        /** Returns data model information about query options for the resp/unsgroupb1 endpoint. */
        Client.prototype.portal_resp_unsgroupb1_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb1_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb1_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb1_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb1_interactive_byid_get = function (UID_UNSGroupB1, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb1_interactive_byid_get(UID_UNSGroupB1), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb2_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb2_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk), requestOptions);
        };
        /** Returns data model information about query options for the resp/unsgroupb2 endpoint. */
        Client.prototype.portal_resp_unsgroupb2_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb2_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb2_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb2_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb2_interactive_byid_get = function (UID_UNSGroupB2, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb2_interactive_byid_get(UID_UNSGroupB2), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb3_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb3_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, risk), requestOptions);
        };
        /** Returns data model information about query options for the resp/unsgroupb3 endpoint. */
        Client.prototype.portal_resp_unsgroupb3_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb3_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb3_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb3_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_resp_unsgroupb3_interactive_byid_get = function (UID_UNSGroupB3, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb3_interactive_byid_get(UID_UNSGroupB3), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_TSBAccountDef_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_TSBAccountDef_post = function (UID_ITShopOrg, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_post(UID_ITShopOrg, inputParameterName), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_TSBAccountDef_delete = function (UID_ITShopOrg, UID_TSBAccountDef, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_delete(UID_ITShopOrg, UID_TSBAccountDef), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_TSBAccountDef. */
        Client.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB_post = function (UID_ITShopOrg, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_post(UID_ITShopOrg, inputParameterName), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB_delete = function (UID_ITShopOrg, UID_UNSGroupB, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_delete(UID_ITShopOrg, UID_UNSGroupB), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_UNSGroupB. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB1_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB1_post = function (UID_ITShopOrg, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_post(UID_ITShopOrg, inputParameterName), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB1_delete = function (UID_ITShopOrg, UID_UNSGroupB1, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_delete(UID_ITShopOrg, UID_UNSGroupB1), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_UNSGroupB1. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB2_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB2_post = function (UID_ITShopOrg, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_post(UID_ITShopOrg, inputParameterName), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB2_delete = function (UID_ITShopOrg, UID_UNSGroupB2, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_delete(UID_ITShopOrg, UID_UNSGroupB2), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_UNSGroupB2. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB3_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB3_post = function (UID_ITShopOrg, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_post(UID_ITShopOrg, inputParameterName), requestOptions);
        };
        Client.prototype.portal_shop_config_entitlements_UNSGroupB3_delete = function (UID_ITShopOrg, UID_UNSGroupB3, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_delete(UID_ITShopOrg, UID_UNSGroupB3), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_UNSGroupB3. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_account_get = function (container, system, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, inactive, deletedintarget, risk, namespace, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_get(container, system, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, inactive, deletedintarget, risk, namespace), requestOptions);
        };
        /** Renders a report for the specified account. */
        Client.prototype.portal_targetsystem_uns_account_report_get = function (tablename, historydays, uidaccount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_report_get(tablename, historydays, uidaccount), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/uns/account endpoint. */
        Client.prototype.portal_targetsystem_uns_account_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_datamodel_get(filter), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/account endpoint. */
        Client.prototype.portal_targetsystem_uns_account_filtertree_get = function (container, system, filter, parentkey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_filtertree_get(container, system, filter, parentkey), requestOptions);
        };
        /** Renders a report for accounts belonging to the specified identity. */
        Client.prototype.portal_targetsystem_uns_account_ownedby_report_get = function (historydays, uidperson, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_ownedby_report_get(historydays, uidperson), requestOptions);
        };
        /** Renders a report for accounts belonging to identities managed by the specified identity. */
        Client.prototype.portal_targetsystem_uns_account_ownedbymanaged_report_get = function (historydays, uidperson, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_ownedbymanaged_report_get(historydays, uidperson), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_container_get = function (system, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, namespace, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_container_get(system, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, namespace), requestOptions);
        };
        /** Renders a report for accounts in the specified container. */
        Client.prototype.portal_targetsystem_uns_container_accounts_report_get = function (historydays, uidcontainer, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_container_accounts_report_get(historydays, uidcontainer), requestOptions);
        };
        /** Renders a report for system entitlements in the specified container. */
        Client.prototype.portal_targetsystem_uns_container_groups_report_get = function (historydays, uidcontainer, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_container_groups_report_get(historydays, uidcontainer), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/uns/container endpoint. */
        Client.prototype.portal_targetsystem_uns_container_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_container_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_directmembers_get = function (UID_UNSGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_directmembers_get(UID_UNSGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_group_get = function (uid_unsaccount, container, system, OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, namespace, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_get(uid_unsaccount, container, system, OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, namespace), requestOptions);
        };
        /** Renders a report for the specified system entitlements. */
        Client.prototype.portal_targetsystem_uns_group_report_get = function (historydays, uidgroup, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_report_get(historydays, uidgroup), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/uns/group endpoint. */
        Client.prototype.portal_targetsystem_uns_group_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_datamodel_get(filter), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group endpoint. */
        Client.prototype.portal_targetsystem_uns_group_filtertree_get = function (uid_unsaccount, container, system, filter, parentkey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_filtertree_get(uid_unsaccount, container, system, filter, parentkey), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_group_serviceitem_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_group_serviceitem_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_group_serviceitem_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/uns/group/serviceitem endpoint. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_byid_get = function (UID_AccProduct, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_byid_get(UID_AccProduct), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_OrgAttestator/candidates endpoint. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_OrgRuler/candidates endpoint. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_PWODecisionMethod/candidates endpoint. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_OrgAttestator/candidates endpoint. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_OrgRuler/candidates endpoint. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_PWODecisionMethod/candidates endpoint. */
        Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_groupmembers_get = function (uidgroup, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_groupmembers_get(uidgroup, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_nestedmembers_get = function (uid, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_nestedmembers_get(uid, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Renders a report for system entitlements owned by the specified identity. */
        Client.prototype.portal_targetsystem_uns_ownedby_report_get = function (historydays, uidperson, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_ownedby_report_get(historydays, uidperson), requestOptions);
        };
        /** Creates a report containing information about identities managed by the specified identity. */
        Client.prototype.portal_targetsystem_uns_person_managed_report_get = function (uidperson, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_person_managed_report_get(uidperson), requestOptions);
        };
        /** Creates a report containing information about personal and organizational data as well as the identity's user accounts, groups and roles. */
        Client.prototype.portal_targetsystem_uns_person_report_get = function (IncludeSubIdentities, IncludeHistory, uidperson, historydays, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_person_report_get(IncludeSubIdentities, IncludeHistory, uidperson, historydays), requestOptions);
        };
        /** Renders a report for accounts in the specified target system. */
        Client.prototype.portal_targetsystem_uns_root_accounts_report_get = function (historydays, uidroot, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_root_accounts_report_get(historydays, uidroot), requestOptions);
        };
        /** Renders a report for system entitlements in the specified target system. */
        Client.prototype.portal_targetsystem_uns_root_groups_report_get = function (historydays, uidroot, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_root_groups_report_get(historydays, uidroot), requestOptions);
        };
        Client.prototype.portal_targetsystem_uns_system_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, namespace, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_system_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, namespace), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/uns/system endpoint. */
        Client.prototype.portal_targetsystem_uns_system_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_system_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsaccountb_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_get(UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsaccountb_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsaccountb_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsaccountb endpoint. */
        Client.prototype.portal_targetsystem_unsaccountb_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsaccountb_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsaccountb_interactive_byid_get = function (UID_UNSAccountB, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_interactive_byid_get(UID_UNSAccountB), requestOptions);
        };
        Client.prototype.portal_targetsystem_unscontainerb_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        Client.prototype.portal_targetsystem_unscontainerb_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unscontainerb_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unscontainerb endpoint. */
        Client.prototype.portal_targetsystem_unscontainerb_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_unscontainerb_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unscontainerb_interactive_byid_get = function (UID_UNSContainerB, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_interactive_byid_get(UID_UNSContainerB), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsgroupb endpoint. */
        Client.prototype.portal_targetsystem_unsgroupb_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb_interactive_byid_get = function (UID_UNSGroupB, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_interactive_byid_get(UID_UNSGroupB), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb1_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb1_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb1_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsgroupb1 endpoint. */
        Client.prototype.portal_targetsystem_unsgroupb1_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb1_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb1_interactive_byid_get = function (UID_UNSGroupB1, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_interactive_byid_get(UID_UNSGroupB1), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb2_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb2_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb2_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsgroupb2 endpoint. */
        Client.prototype.portal_targetsystem_unsgroupb2_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb2_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb2_interactive_byid_get = function (UID_UNSGroupB2, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_interactive_byid_get(UID_UNSGroupB2), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb3_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb3_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb3_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsgroupb3 endpoint. */
        Client.prototype.portal_targetsystem_unsgroupb3_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb3_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsgroupb3_interactive_byid_get = function (UID_UNSGroupB3, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_interactive_byid_get(UID_UNSGroupB3), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsitemb_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsitemb_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsitemb_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsitemb endpoint. */
        Client.prototype.portal_targetsystem_unsitemb_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsitemb_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_unsitemb_interactive_byid_get = function (UID_UNSItemB, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_interactive_byid_get(UID_UNSItemB), requestOptions);
        };
        Client.prototype.portal_targetsystem_userconfig_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_userconfig_get(), requestOptions);
        };
        /** Returns schema information about the Unified Namespace. */
        Client.prototype.portal_uns_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_uns_config_get(), requestOptions);
        };
        Client.prototype.portal_UNSGroupB_memberships_get = function (uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB_memberships_get(uid), requestOptions);
        };
        /** Deletes an account membership. */
        Client.prototype.portal_UNSGroupB_memberships_delete = function (uid, uidaccount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB_memberships_delete(uid, uidaccount), requestOptions);
        };
        Client.prototype.portal_UNSGroupB1_memberships_get = function (uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB1_memberships_get(uid), requestOptions);
        };
        /** Deletes an account membership. */
        Client.prototype.portal_UNSGroupB1_memberships_delete = function (uid, uidaccount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB1_memberships_delete(uid, uidaccount), requestOptions);
        };
        Client.prototype.portal_UNSGroupB2_memberships_get = function (uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB2_memberships_get(uid), requestOptions);
        };
        /** Deletes an account membership. */
        Client.prototype.portal_UNSGroupB2_memberships_delete = function (uid, uidaccount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB2_memberships_delete(uid, uidaccount), requestOptions);
        };
        Client.prototype.portal_UNSGroupB3_memberships_get = function (uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB3_memberships_get(uid), requestOptions);
        };
        /** Deletes an account membership. */
        Client.prototype.portal_UNSGroupB3_memberships_delete = function (uid, uidaccount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB3_memberships_delete(uid, uidaccount), requestOptions);
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.portal_candidates_AccProductGroup_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/AccProductGroup',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_AccProductGroup_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/AccProductGroup/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_AccProductParamCategory_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/AccProductParamCategory',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_AccProductParamCategory_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/AccProductParamCategory/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_claimgroup_post = function (/** Identity claiming the ownership */ uidperson, /** Table name of the system entitlement */ tablename, /** Identifier of the system entitlement */ uidunsgroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/claimgroup/{uidperson}/{tablename}/{uidunsgroup}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'tablename',
                        value: tablename,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidunsgroup',
                        value: uidunsgroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_claimgroup_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/claimgroup/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_claimgroup_suggestedowner_get = function (/** Table name of the system entitlement */ tablename, /** Identifier of the system entitlement */ uidunsgroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/claimgroup/suggestedowner/{tablename}/{uidunsgroup}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'tablename',
                        value: tablename,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidunsgroup',
                        value: uidunsgroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_claimgroup_suggestedowner2_get = function (/** Table name of the system entitlement */ tablename, /** Identifier of the system entitlement */ uidunsgroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/claimgroup/suggestedowner2/{tablename}/{uidunsgroup}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'tablename',
                        value: tablename,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidunsgroup',
                        value: uidunsgroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_accounts_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{uid}/accounts',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_groupmemberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{uid}/groupmemberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroup_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroup',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroup_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroup/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb_interactive_byid_get = function (/** Primary key value UID_UNSGroupB */ UID_UNSGroupB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb/interactive/{UID_UNSGroupB}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSGroupB',
                        value: UID_UNSGroupB,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb1_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb1',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb1_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb1/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb1_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb1/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb1_interactive_byid_get = function (/** Primary key value UID_UNSGroupB1 */ UID_UNSGroupB1, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb1/interactive/{UID_UNSGroupB1}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSGroupB1',
                        value: UID_UNSGroupB1,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb2_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb2',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb2_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb2/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb2_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb2/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb2_interactive_byid_get = function (/** Primary key value UID_UNSGroupB2 */ UID_UNSGroupB2, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb2/interactive/{UID_UNSGroupB2}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSGroupB2',
                        value: UID_UNSGroupB2,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb3_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb3',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb3_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb3/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb3_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb3/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_resp_unsgroupb3_interactive_byid_get = function (/** Primary key value UID_UNSGroupB3 */ UID_UNSGroupB3, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/resp/unsgroupb3/interactive/{UID_UNSGroupB3}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSGroupB3',
                        value: UID_UNSGroupB3,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** Account definition */ UID_TSBAccountDef, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/{UID_TSBAccountDef}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_TSBAccountDef',
                        value: UID_TSBAccountDef,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** Group */ UID_UNSGroupB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/{UID_UNSGroupB}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_UNSGroupB',
                        value: UID_UNSGroupB,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** System entitlement 1 */ UID_UNSGroupB1, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/{UID_UNSGroupB1}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_UNSGroupB1',
                        value: UID_UNSGroupB1,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** System entitlement 2 */ UID_UNSGroupB2, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/{UID_UNSGroupB2}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_UNSGroupB2',
                        value: UID_UNSGroupB2,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** System entitlement 3 */ UID_UNSGroupB3, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/{UID_UNSGroupB3}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_UNSGroupB3',
                        value: UID_UNSGroupB3,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/account',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_report_get = function (/** Type of account */ tablename, /** Unique account identifier */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/account/{tablename}/{uidaccount}/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'tablename',
                        value: tablename,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/account/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_filtertree_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/account/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_ownedby_report_get = function (/** Unique identity identifier */ uidperson, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/account/ownedby/{uidperson}/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_account_ownedbymanaged_report_get = function (/** Unique identity identifier */ uidperson, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/account/ownedbymanaged/{uidperson}/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_container_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/container',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_container_accounts_report_get = function (/** Unique container identifier */ uidcontainer, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/container/{uidcontainer}/accounts/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcontainer',
                        value: uidcontainer,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_container_groups_report_get = function (/** Unique container identifier */ uidcontainer, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/container/{uidcontainer}/groups/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidcontainer',
                        value: uidcontainer,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_container_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/container/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_directmembers_get = function (/** Unique system entitlement identifier */ UID_UNSGroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/directmembers/{UID_UNSGroup}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSGroup',
                        value: UID_UNSGroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_report_get = function (/** Unique group identifier */ uidgroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/{uidgroup}/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidgroup',
                        value: uidgroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_filtertree_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_byid_get = function (/** Primary key value UID_AccProduct */ UID_AccProduct, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/{UID_AccProduct}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_AccProduct',
                        value: UID_AccProduct,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_OrgAttestator/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_OrgAttestator/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_OrgRuler/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_OrgRuler/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_PWODecisionMethod/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/interactive/UID_PWODecisionMethod/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_OrgAttestator/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_OrgAttestator/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_OrgRuler/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_OrgRuler/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_PWODecisionMethod/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/group/serviceitem/UID_PWODecisionMethod/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_groupmembers_get = function (/** Unique group identifier */ uidgroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/groupmembers/{uidgroup}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidgroup',
                        value: uidgroup,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_nestedmembers_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/nestedmembers/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_ownedby_report_get = function (/** Unique Identity identifier */ uidperson, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/ownedby/{uidperson}/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_person_managed_report_get = function (/** Unique identity identifier */ uidperson, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/person/{uidperson}/managed/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_person_report_get = function (/** Unique identity identifier */ uidperson, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/person/{uidperson}/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_root_accounts_report_get = function (/** Unique root identifier */ uidroot, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/root/{uidroot}/accounts/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidroot',
                        value: uidroot,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_root_groups_report_get = function (/** Unique root identifier */ uidroot, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/root/{uidroot}/groups/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidroot',
                        value: uidroot,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_system_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/system',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_uns_system_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/uns/system/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsaccountb',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsaccountb',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsaccountb/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsaccountb/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsaccountb/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsaccountb_interactive_byid_get = function (/** Primary key value UID_UNSAccountB */ UID_UNSAccountB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsaccountb/interactive/{UID_UNSAccountB}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSAccountB',
                        value: UID_UNSAccountB,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unscontainerb',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unscontainerb',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unscontainerb/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unscontainerb/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unscontainerb/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unscontainerb_interactive_byid_get = function (/** Primary key value UID_UNSContainerB */ UID_UNSContainerB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unscontainerb/interactive/{UID_UNSContainerB}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSContainerB',
                        value: UID_UNSContainerB,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb_interactive_byid_get = function (/** Primary key value UID_UNSGroupB */ UID_UNSGroupB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb/interactive/{UID_UNSGroupB}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSGroupB',
                        value: UID_UNSGroupB,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb1',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb1',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb1/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb1/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb1/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb1_interactive_byid_get = function (/** Primary key value UID_UNSGroupB1 */ UID_UNSGroupB1, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb1/interactive/{UID_UNSGroupB1}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSGroupB1',
                        value: UID_UNSGroupB1,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb2',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb2',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb2/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb2/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb2/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb2_interactive_byid_get = function (/** Primary key value UID_UNSGroupB2 */ UID_UNSGroupB2, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb2/interactive/{UID_UNSGroupB2}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSGroupB2',
                        value: UID_UNSGroupB2,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb3',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb3',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb3/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb3/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb3/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsgroupb3_interactive_byid_get = function (/** Primary key value UID_UNSGroupB3 */ UID_UNSGroupB3, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsgroupb3/interactive/{UID_UNSGroupB3}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSGroupB3',
                        value: UID_UNSGroupB3,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsitemb',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsitemb',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsitemb/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsitemb/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsitemb/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_unsitemb_interactive_byid_get = function (/** Primary key value UID_UNSItemB */ UID_UNSItemB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/unsitemb/interactive/{UID_UNSItemB}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_UNSItemB',
                        value: UID_UNSItemB,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_userconfig_get = function (options, requestOptions) {
            return {
                path: '/portal/targetsystem/userconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_uns_config_get = function (options, requestOptions) {
            return {
                path: '/portal/uns/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_UNSGroupB_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/UNSGroupB/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_UNSGroupB_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/UNSGroupB/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_UNSGroupB1_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/UNSGroupB1/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_UNSGroupB1_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/UNSGroupB1/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_UNSGroupB2_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/UNSGroupB2/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_UNSGroupB2_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/UNSGroupB2/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_UNSGroupB3_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/UNSGroupB3/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_UNSGroupB3_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/UNSGroupB3/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        /** Returns a list of candidate objects from the table AccProductGroup. */
        V2Client.prototype.portal_candidates_AccProductGroup_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductGroup_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/AccProductGroup endpoint. */
        V2Client.prototype.portal_candidates_AccProductGroup_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductGroup_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of candidate objects from the table AccProductParamCategory. */
        V2Client.prototype.portal_candidates_AccProductParamCategory_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductParamCategory_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
        V2Client.prototype.portal_candidates_AccProductParamCategory_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductParamCategory_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Create an attestation case to assign ownership of the specified group to the current user. */
        V2Client.prototype.portal_claimgroup_post = function (/** Identity claiming the ownership */ uidperson, /** Table name of the system entitlement */ tablename, /** Identifier of the system entitlement */ uidunsgroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimgroup_post(uidperson, tablename, uidunsgroup, options), requestOptions);
        };
        /** Returns system entitlements that have no current owner */
        V2Client.prototype.portal_claimgroup_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimgroup_group_get(options), requestOptions);
        };
        /** Returns suggested owners (first suggestions) for the specified group */
        V2Client.prototype.portal_claimgroup_suggestedowner_get = function (/** Table name of the system entitlement */ tablename, /** Identifier of the system entitlement */ uidunsgroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimgroup_suggestedowner_get(tablename, uidunsgroup, options), requestOptions);
        };
        /** Returns suggested owners (second suggestions) for the specified group */
        V2Client.prototype.portal_claimgroup_suggestedowner2_get = function (/** Table name of the system entitlement */ tablename, /** Identifier of the system entitlement */ uidunsgroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_claimgroup_suggestedowner2_get(tablename, uidunsgroup, options), requestOptions);
        };
        V2Client.prototype.portal_person_accounts_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_accounts_get(uid, options), requestOptions);
        };
        V2Client.prototype.portal_person_groupmemberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_groupmemberships_get(uid, options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroup_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroup_get(options), requestOptions);
        };
        /** Returns data model information about query options for the resp/unsgroup endpoint. */
        V2Client.prototype.portal_resp_unsgroup_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroup_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb_get(options), requestOptions);
        };
        /** Returns data model information about query options for the resp/unsgroupb endpoint. */
        V2Client.prototype.portal_resp_unsgroupb_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb_interactive_byid_get = function (/** Primary key value UID_UNSGroupB */ UID_UNSGroupB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb_interactive_byid_get(UID_UNSGroupB, options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb1_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb1_get(options), requestOptions);
        };
        /** Returns data model information about query options for the resp/unsgroupb1 endpoint. */
        V2Client.prototype.portal_resp_unsgroupb1_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb1_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb1_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb1_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb1_interactive_byid_get = function (/** Primary key value UID_UNSGroupB1 */ UID_UNSGroupB1, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb1_interactive_byid_get(UID_UNSGroupB1, options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb2_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb2_get(options), requestOptions);
        };
        /** Returns data model information about query options for the resp/unsgroupb2 endpoint. */
        V2Client.prototype.portal_resp_unsgroupb2_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb2_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb2_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb2_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb2_interactive_byid_get = function (/** Primary key value UID_UNSGroupB2 */ UID_UNSGroupB2, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb2_interactive_byid_get(UID_UNSGroupB2, options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb3_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb3_get(options), requestOptions);
        };
        /** Returns data model information about query options for the resp/unsgroupb3 endpoint. */
        V2Client.prototype.portal_resp_unsgroupb3_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb3_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb3_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb3_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_resp_unsgroupb3_interactive_byid_get = function (/** Primary key value UID_UNSGroupB3 */ UID_UNSGroupB3, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_resp_unsgroupb3_interactive_byid_get(UID_UNSGroupB3, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_TSBAccountDef_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_get(UID_ITShopOrg, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_TSBAccountDef_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_TSBAccountDef_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** Account definition */ UID_TSBAccountDef, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_delete(UID_ITShopOrg, UID_TSBAccountDef, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_TSBAccountDef. */
        V2Client.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_get(UID_ITShopOrg, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** Group */ UID_UNSGroupB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_delete(UID_ITShopOrg, UID_UNSGroupB, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_UNSGroupB. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB1_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_get(UID_ITShopOrg, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB1_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB1_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** System entitlement 1 */ UID_UNSGroupB1, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_delete(UID_ITShopOrg, UID_UNSGroupB1, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_UNSGroupB1. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB2_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_get(UID_ITShopOrg, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB2_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB2_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** System entitlement 2 */ UID_UNSGroupB2, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_delete(UID_ITShopOrg, UID_UNSGroupB2, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_UNSGroupB2. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB3_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_get(UID_ITShopOrg, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB3_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB3_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** System entitlement 3 */ UID_UNSGroupB3, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_delete(UID_ITShopOrg, UID_UNSGroupB3, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_UNSGroupB3. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_account_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_get(options), requestOptions);
        };
        /** Renders a report for the specified account. */
        V2Client.prototype.portal_targetsystem_uns_account_report_get = function (/** Type of account */ tablename, /** Unique account identifier */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_report_get(tablename, uidaccount, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/uns/account endpoint. */
        V2Client.prototype.portal_targetsystem_uns_account_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_datamodel_get(options), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/account endpoint. */
        V2Client.prototype.portal_targetsystem_uns_account_filtertree_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_filtertree_get(options), requestOptions);
        };
        /** Renders a report for accounts belonging to the specified identity. */
        V2Client.prototype.portal_targetsystem_uns_account_ownedby_report_get = function (/** Unique identity identifier */ uidperson, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_ownedby_report_get(uidperson, options), requestOptions);
        };
        /** Renders a report for accounts belonging to identities managed by the specified identity. */
        V2Client.prototype.portal_targetsystem_uns_account_ownedbymanaged_report_get = function (/** Unique identity identifier */ uidperson, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_account_ownedbymanaged_report_get(uidperson, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_container_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_container_get(options), requestOptions);
        };
        /** Renders a report for accounts in the specified container. */
        V2Client.prototype.portal_targetsystem_uns_container_accounts_report_get = function (/** Unique container identifier */ uidcontainer, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_container_accounts_report_get(uidcontainer, options), requestOptions);
        };
        /** Renders a report for system entitlements in the specified container. */
        V2Client.prototype.portal_targetsystem_uns_container_groups_report_get = function (/** Unique container identifier */ uidcontainer, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_container_groups_report_get(uidcontainer, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/uns/container endpoint. */
        V2Client.prototype.portal_targetsystem_uns_container_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_container_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_directmembers_get = function (/** Unique system entitlement identifier */ UID_UNSGroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_directmembers_get(UID_UNSGroup, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_get(options), requestOptions);
        };
        /** Renders a report for the specified system entitlements. */
        V2Client.prototype.portal_targetsystem_uns_group_report_get = function (/** Unique group identifier */ uidgroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_report_get(uidgroup, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/uns/group endpoint. */
        V2Client.prototype.portal_targetsystem_uns_group_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_datamodel_get(options), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group endpoint. */
        V2Client.prototype.portal_targetsystem_uns_group_filtertree_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_filtertree_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/uns/group/serviceitem endpoint. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_byid_get = function (/** Primary key value UID_AccProduct */ UID_AccProduct, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_byid_get(UID_AccProduct, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get(options), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_OrgAttestator/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get(options), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_OrgRuler/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get(options), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_PWODecisionMethod/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get(options), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_OrgAttestator/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get(options), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_OrgRuler/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get(options), requestOptions);
        };
        /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_PWODecisionMethod/candidates endpoint. */
        V2Client.prototype.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_groupmembers_get = function (/** Unique group identifier */ uidgroup, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_groupmembers_get(uidgroup, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_nestedmembers_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_nestedmembers_get(uid, options), requestOptions);
        };
        /** Renders a report for system entitlements owned by the specified identity. */
        V2Client.prototype.portal_targetsystem_uns_ownedby_report_get = function (/** Unique Identity identifier */ uidperson, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_ownedby_report_get(uidperson, options), requestOptions);
        };
        /** Creates a report containing information about identities managed by the specified identity. */
        V2Client.prototype.portal_targetsystem_uns_person_managed_report_get = function (/** Unique identity identifier */ uidperson, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_person_managed_report_get(uidperson, options), requestOptions);
        };
        /** Creates a report containing information about personal and organizational data as well as the identity's user accounts, groups and roles. */
        V2Client.prototype.portal_targetsystem_uns_person_report_get = function (/** Unique identity identifier */ uidperson, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_person_report_get(uidperson, options), requestOptions);
        };
        /** Renders a report for accounts in the specified target system. */
        V2Client.prototype.portal_targetsystem_uns_root_accounts_report_get = function (/** Unique root identifier */ uidroot, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_root_accounts_report_get(uidroot, options), requestOptions);
        };
        /** Renders a report for system entitlements in the specified target system. */
        V2Client.prototype.portal_targetsystem_uns_root_groups_report_get = function (/** Unique root identifier */ uidroot, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_root_groups_report_get(uidroot, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_uns_system_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_system_get(options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/uns/system endpoint. */
        V2Client.prototype.portal_targetsystem_uns_system_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_uns_system_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsaccountb_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsaccountb_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsaccountb_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsaccountb endpoint. */
        V2Client.prototype.portal_targetsystem_unsaccountb_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsaccountb_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsaccountb_interactive_byid_get = function (/** Primary key value UID_UNSAccountB */ UID_UNSAccountB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsaccountb_interactive_byid_get(UID_UNSAccountB, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unscontainerb_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unscontainerb_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unscontainerb_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unscontainerb endpoint. */
        V2Client.prototype.portal_targetsystem_unscontainerb_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unscontainerb_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unscontainerb_interactive_byid_get = function (/** Primary key value UID_UNSContainerB */ UID_UNSContainerB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unscontainerb_interactive_byid_get(UID_UNSContainerB, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsgroupb endpoint. */
        V2Client.prototype.portal_targetsystem_unsgroupb_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb_interactive_byid_get = function (/** Primary key value UID_UNSGroupB */ UID_UNSGroupB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb_interactive_byid_get(UID_UNSGroupB, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb1_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb1_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb1_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsgroupb1 endpoint. */
        V2Client.prototype.portal_targetsystem_unsgroupb1_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb1_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb1_interactive_byid_get = function (/** Primary key value UID_UNSGroupB1 */ UID_UNSGroupB1, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb1_interactive_byid_get(UID_UNSGroupB1, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb2_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb2_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb2_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsgroupb2 endpoint. */
        V2Client.prototype.portal_targetsystem_unsgroupb2_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb2_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb2_interactive_byid_get = function (/** Primary key value UID_UNSGroupB2 */ UID_UNSGroupB2, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb2_interactive_byid_get(UID_UNSGroupB2, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb3_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb3_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb3_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsgroupb3 endpoint. */
        V2Client.prototype.portal_targetsystem_unsgroupb3_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb3_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsgroupb3_interactive_byid_get = function (/** Primary key value UID_UNSGroupB3 */ UID_UNSGroupB3, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsgroupb3_interactive_byid_get(UID_UNSGroupB3, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsitemb_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsitemb_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsitemb_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/unsitemb endpoint. */
        V2Client.prototype.portal_targetsystem_unsitemb_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsitemb_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_unsitemb_interactive_byid_get = function (/** Primary key value UID_UNSItemB */ UID_UNSItemB, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_unsitemb_interactive_byid_get(UID_UNSItemB, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_userconfig_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_userconfig_get(options), requestOptions);
        };
        /** Returns schema information about the Unified Namespace. */
        V2Client.prototype.portal_uns_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_uns_config_get(options), requestOptions);
        };
        V2Client.prototype.portal_UNSGroupB_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB_memberships_get(uid, options), requestOptions);
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_UNSGroupB_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB_memberships_delete(uid, uidaccount, options), requestOptions);
        };
        V2Client.prototype.portal_UNSGroupB1_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB1_memberships_get(uid, options), requestOptions);
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_UNSGroupB1_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB1_memberships_delete(uid, uidaccount, options), requestOptions);
        };
        V2Client.prototype.portal_UNSGroupB2_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB2_memberships_get(uid, options), requestOptions);
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_UNSGroupB2_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB2_memberships_delete(uid, uidaccount, options), requestOptions);
        };
        V2Client.prototype.portal_UNSGroupB3_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB3_memberships_get(uid, options), requestOptions);
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_UNSGroupB3_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_UNSGroupB3_memberships_delete(uid, uidaccount, options), requestOptions);
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.PortalCandidatesAccproductgroup = PortalCandidatesAccproductgroup;
    exports.PortalCandidatesAccproductgroupInteractive = PortalCandidatesAccproductgroupInteractive;
    exports.PortalCandidatesAccproductgroupWrapper = PortalCandidatesAccproductgroupWrapper;
    exports.PortalCandidatesAccproductparamcategory = PortalCandidatesAccproductparamcategory;
    exports.PortalCandidatesAccproductparamcategoryInteractive = PortalCandidatesAccproductparamcategoryInteractive;
    exports.PortalCandidatesAccproductparamcategoryWrapper = PortalCandidatesAccproductparamcategoryWrapper;
    exports.PortalClaimgroupGroup = PortalClaimgroupGroup;
    exports.PortalClaimgroupGroupInteractive = PortalClaimgroupGroupInteractive;
    exports.PortalClaimgroupGroupWrapper = PortalClaimgroupGroupWrapper;
    exports.PortalClaimgroupSuggestedowner = PortalClaimgroupSuggestedowner;
    exports.PortalClaimgroupSuggestedowner2 = PortalClaimgroupSuggestedowner2;
    exports.PortalClaimgroupSuggestedowner2Interactive = PortalClaimgroupSuggestedowner2Interactive;
    exports.PortalClaimgroupSuggestedowner2Wrapper = PortalClaimgroupSuggestedowner2Wrapper;
    exports.PortalClaimgroupSuggestedownerInteractive = PortalClaimgroupSuggestedownerInteractive;
    exports.PortalClaimgroupSuggestedownerWrapper = PortalClaimgroupSuggestedownerWrapper;
    exports.PortalPersonAccounts = PortalPersonAccounts;
    exports.PortalPersonAccountsInteractive = PortalPersonAccountsInteractive;
    exports.PortalPersonAccountsWrapper = PortalPersonAccountsWrapper;
    exports.PortalPersonGroupmemberships = PortalPersonGroupmemberships;
    exports.PortalPersonGroupmembershipsInteractive = PortalPersonGroupmembershipsInteractive;
    exports.PortalPersonGroupmembershipsWrapper = PortalPersonGroupmembershipsWrapper;
    exports.PortalRespUnsgroup = PortalRespUnsgroup;
    exports.PortalRespUnsgroupInteractive = PortalRespUnsgroupInteractive;
    exports.PortalRespUnsgroupWrapper = PortalRespUnsgroupWrapper;
    exports.PortalRespUnsgroupb = PortalRespUnsgroupb;
    exports.PortalRespUnsgroupb1 = PortalRespUnsgroupb1;
    exports.PortalRespUnsgroupb1Interactive = PortalRespUnsgroupb1Interactive;
    exports.PortalRespUnsgroupb1InteractiveWrapper = PortalRespUnsgroupb1InteractiveWrapper;
    exports.PortalRespUnsgroupb1Wrapper = PortalRespUnsgroupb1Wrapper;
    exports.PortalRespUnsgroupb2 = PortalRespUnsgroupb2;
    exports.PortalRespUnsgroupb2Interactive = PortalRespUnsgroupb2Interactive;
    exports.PortalRespUnsgroupb2InteractiveWrapper = PortalRespUnsgroupb2InteractiveWrapper;
    exports.PortalRespUnsgroupb2Wrapper = PortalRespUnsgroupb2Wrapper;
    exports.PortalRespUnsgroupb3 = PortalRespUnsgroupb3;
    exports.PortalRespUnsgroupb3Interactive = PortalRespUnsgroupb3Interactive;
    exports.PortalRespUnsgroupb3InteractiveWrapper = PortalRespUnsgroupb3InteractiveWrapper;
    exports.PortalRespUnsgroupb3Wrapper = PortalRespUnsgroupb3Wrapper;
    exports.PortalRespUnsgroupbInteractive = PortalRespUnsgroupbInteractive;
    exports.PortalRespUnsgroupbInteractiveWrapper = PortalRespUnsgroupbInteractiveWrapper;
    exports.PortalRespUnsgroupbWrapper = PortalRespUnsgroupbWrapper;
    exports.PortalShopConfigEntitlementsTsbaccountdef = PortalShopConfigEntitlementsTsbaccountdef;
    exports.PortalShopConfigEntitlementsTsbaccountdefInteractive = PortalShopConfigEntitlementsTsbaccountdefInteractive;
    exports.PortalShopConfigEntitlementsTsbaccountdefWrapper = PortalShopConfigEntitlementsTsbaccountdefWrapper;
    exports.PortalShopConfigEntitlementsUnsgroupb = PortalShopConfigEntitlementsUnsgroupb;
    exports.PortalShopConfigEntitlementsUnsgroupb1 = PortalShopConfigEntitlementsUnsgroupb1;
    exports.PortalShopConfigEntitlementsUnsgroupb1Interactive = PortalShopConfigEntitlementsUnsgroupb1Interactive;
    exports.PortalShopConfigEntitlementsUnsgroupb1Wrapper = PortalShopConfigEntitlementsUnsgroupb1Wrapper;
    exports.PortalShopConfigEntitlementsUnsgroupb2 = PortalShopConfigEntitlementsUnsgroupb2;
    exports.PortalShopConfigEntitlementsUnsgroupb2Interactive = PortalShopConfigEntitlementsUnsgroupb2Interactive;
    exports.PortalShopConfigEntitlementsUnsgroupb2Wrapper = PortalShopConfigEntitlementsUnsgroupb2Wrapper;
    exports.PortalShopConfigEntitlementsUnsgroupb3 = PortalShopConfigEntitlementsUnsgroupb3;
    exports.PortalShopConfigEntitlementsUnsgroupb3Interactive = PortalShopConfigEntitlementsUnsgroupb3Interactive;
    exports.PortalShopConfigEntitlementsUnsgroupb3Wrapper = PortalShopConfigEntitlementsUnsgroupb3Wrapper;
    exports.PortalShopConfigEntitlementsUnsgroupbInteractive = PortalShopConfigEntitlementsUnsgroupbInteractive;
    exports.PortalShopConfigEntitlementsUnsgroupbWrapper = PortalShopConfigEntitlementsUnsgroupbWrapper;
    exports.PortalTargetsystemUnsAccount = PortalTargetsystemUnsAccount;
    exports.PortalTargetsystemUnsAccountInteractive = PortalTargetsystemUnsAccountInteractive;
    exports.PortalTargetsystemUnsAccountWrapper = PortalTargetsystemUnsAccountWrapper;
    exports.PortalTargetsystemUnsContainer = PortalTargetsystemUnsContainer;
    exports.PortalTargetsystemUnsContainerInteractive = PortalTargetsystemUnsContainerInteractive;
    exports.PortalTargetsystemUnsContainerWrapper = PortalTargetsystemUnsContainerWrapper;
    exports.PortalTargetsystemUnsDirectmembers = PortalTargetsystemUnsDirectmembers;
    exports.PortalTargetsystemUnsDirectmembersInteractive = PortalTargetsystemUnsDirectmembersInteractive;
    exports.PortalTargetsystemUnsDirectmembersWrapper = PortalTargetsystemUnsDirectmembersWrapper;
    exports.PortalTargetsystemUnsGroup = PortalTargetsystemUnsGroup;
    exports.PortalTargetsystemUnsGroupInteractive = PortalTargetsystemUnsGroupInteractive;
    exports.PortalTargetsystemUnsGroupServiceitem = PortalTargetsystemUnsGroupServiceitem;
    exports.PortalTargetsystemUnsGroupServiceitemInteractive = PortalTargetsystemUnsGroupServiceitemInteractive;
    exports.PortalTargetsystemUnsGroupServiceitemInteractiveWrapper = PortalTargetsystemUnsGroupServiceitemInteractiveWrapper;
    exports.PortalTargetsystemUnsGroupServiceitemWrapper = PortalTargetsystemUnsGroupServiceitemWrapper;
    exports.PortalTargetsystemUnsGroupWrapper = PortalTargetsystemUnsGroupWrapper;
    exports.PortalTargetsystemUnsGroupmembers = PortalTargetsystemUnsGroupmembers;
    exports.PortalTargetsystemUnsGroupmembersInteractive = PortalTargetsystemUnsGroupmembersInteractive;
    exports.PortalTargetsystemUnsGroupmembersWrapper = PortalTargetsystemUnsGroupmembersWrapper;
    exports.PortalTargetsystemUnsNestedmembers = PortalTargetsystemUnsNestedmembers;
    exports.PortalTargetsystemUnsNestedmembersInteractive = PortalTargetsystemUnsNestedmembersInteractive;
    exports.PortalTargetsystemUnsNestedmembersWrapper = PortalTargetsystemUnsNestedmembersWrapper;
    exports.PortalTargetsystemUnsSystem = PortalTargetsystemUnsSystem;
    exports.PortalTargetsystemUnsSystemInteractive = PortalTargetsystemUnsSystemInteractive;
    exports.PortalTargetsystemUnsSystemWrapper = PortalTargetsystemUnsSystemWrapper;
    exports.PortalTargetsystemUnsaccountb = PortalTargetsystemUnsaccountb;
    exports.PortalTargetsystemUnsaccountbInteractive = PortalTargetsystemUnsaccountbInteractive;
    exports.PortalTargetsystemUnsaccountbInteractiveWrapper = PortalTargetsystemUnsaccountbInteractiveWrapper;
    exports.PortalTargetsystemUnsaccountbWrapper = PortalTargetsystemUnsaccountbWrapper;
    exports.PortalTargetsystemUnscontainerb = PortalTargetsystemUnscontainerb;
    exports.PortalTargetsystemUnscontainerbInteractive = PortalTargetsystemUnscontainerbInteractive;
    exports.PortalTargetsystemUnscontainerbInteractiveWrapper = PortalTargetsystemUnscontainerbInteractiveWrapper;
    exports.PortalTargetsystemUnscontainerbWrapper = PortalTargetsystemUnscontainerbWrapper;
    exports.PortalTargetsystemUnsgroupb = PortalTargetsystemUnsgroupb;
    exports.PortalTargetsystemUnsgroupb1 = PortalTargetsystemUnsgroupb1;
    exports.PortalTargetsystemUnsgroupb1Interactive = PortalTargetsystemUnsgroupb1Interactive;
    exports.PortalTargetsystemUnsgroupb1InteractiveWrapper = PortalTargetsystemUnsgroupb1InteractiveWrapper;
    exports.PortalTargetsystemUnsgroupb1Wrapper = PortalTargetsystemUnsgroupb1Wrapper;
    exports.PortalTargetsystemUnsgroupb2 = PortalTargetsystemUnsgroupb2;
    exports.PortalTargetsystemUnsgroupb2Interactive = PortalTargetsystemUnsgroupb2Interactive;
    exports.PortalTargetsystemUnsgroupb2InteractiveWrapper = PortalTargetsystemUnsgroupb2InteractiveWrapper;
    exports.PortalTargetsystemUnsgroupb2Wrapper = PortalTargetsystemUnsgroupb2Wrapper;
    exports.PortalTargetsystemUnsgroupb3 = PortalTargetsystemUnsgroupb3;
    exports.PortalTargetsystemUnsgroupb3Interactive = PortalTargetsystemUnsgroupb3Interactive;
    exports.PortalTargetsystemUnsgroupb3InteractiveWrapper = PortalTargetsystemUnsgroupb3InteractiveWrapper;
    exports.PortalTargetsystemUnsgroupb3Wrapper = PortalTargetsystemUnsgroupb3Wrapper;
    exports.PortalTargetsystemUnsgroupbInteractive = PortalTargetsystemUnsgroupbInteractive;
    exports.PortalTargetsystemUnsgroupbInteractiveWrapper = PortalTargetsystemUnsgroupbInteractiveWrapper;
    exports.PortalTargetsystemUnsgroupbWrapper = PortalTargetsystemUnsgroupbWrapper;
    exports.PortalTargetsystemUnsitemb = PortalTargetsystemUnsitemb;
    exports.PortalTargetsystemUnsitembInteractive = PortalTargetsystemUnsitembInteractive;
    exports.PortalTargetsystemUnsitembInteractiveWrapper = PortalTargetsystemUnsitembInteractiveWrapper;
    exports.PortalTargetsystemUnsitembWrapper = PortalTargetsystemUnsitembWrapper;
    exports.PortalUnsgroupb1Memberships = PortalUnsgroupb1Memberships;
    exports.PortalUnsgroupb1MembershipsInteractive = PortalUnsgroupb1MembershipsInteractive;
    exports.PortalUnsgroupb1MembershipsWrapper = PortalUnsgroupb1MembershipsWrapper;
    exports.PortalUnsgroupb2Memberships = PortalUnsgroupb2Memberships;
    exports.PortalUnsgroupb2MembershipsInteractive = PortalUnsgroupb2MembershipsInteractive;
    exports.PortalUnsgroupb2MembershipsWrapper = PortalUnsgroupb2MembershipsWrapper;
    exports.PortalUnsgroupb3Memberships = PortalUnsgroupb3Memberships;
    exports.PortalUnsgroupb3MembershipsInteractive = PortalUnsgroupb3MembershipsInteractive;
    exports.PortalUnsgroupb3MembershipsWrapper = PortalUnsgroupb3MembershipsWrapper;
    exports.PortalUnsgroupbMemberships = PortalUnsgroupbMemberships;
    exports.PortalUnsgroupbMembershipsInteractive = PortalUnsgroupbMembershipsInteractive;
    exports.PortalUnsgroupbMembershipsWrapper = PortalUnsgroupbMembershipsWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
