import { ValType, DisplayColumns, TypedEntity, WriteExtTypedEntity, TypedEntityBuilder, InteractiveTypedEntityBuilder, EntityState, TimeZoneInfo, DisplayPattern, FkCandidateBuilder, MethodDefinition } from 'imx-qbm-dbts';

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var TypedClient = /** @class */ (function () {
    function TypedClient(client, translationProvider) {
        this.PortalO3edlMemberships = new PortalO3edlMembershipsWrapper(client, translationProvider);
        this.PortalO3eunifiedgroupMemberships = new PortalO3eunifiedgroupMembershipsWrapper(client, translationProvider);
        this.PortalTargetsystemO3edl = new PortalTargetsystemO3edlWrapper(client, translationProvider);
        this.PortalTargetsystemO3edlInteractive = new PortalTargetsystemO3edlInteractiveWrapper(client, translationProvider);
        this.PortalTargetsystemO3edlMailboxes = new PortalTargetsystemO3edlMailboxesWrapper(client, translationProvider);
        this.PortalTargetsystemO3emailbox = new PortalTargetsystemO3emailboxWrapper(client, translationProvider);
        this.PortalTargetsystemO3emailboxInteractive = new PortalTargetsystemO3emailboxInteractiveWrapper(client, translationProvider);
        this.PortalTargetsystemO3emailcontact = new PortalTargetsystemO3emailcontactWrapper(client, translationProvider);
        this.PortalTargetsystemO3emailcontactInteractive = new PortalTargetsystemO3emailcontactInteractiveWrapper(client, translationProvider);
        this.PortalTargetsystemO3emailuser = new PortalTargetsystemO3emailuserWrapper(client, translationProvider);
        this.PortalTargetsystemO3emailuserInteractive = new PortalTargetsystemO3emailuserInteractiveWrapper(client, translationProvider);
        this.PortalTargetsystemO3eunifiedgroup = new PortalTargetsystemO3eunifiedgroupWrapper(client, translationProvider);
        this.PortalTargetsystemO3eunifiedgroupInteractive = new PortalTargetsystemO3eunifiedgroupInteractiveWrapper(client, translationProvider);
    }
    return TypedClient;
}());
var PortalO3edlMemberships = /** @class */ (function (_super) {
    __extends(PortalO3edlMemberships, _super);
    function PortalO3edlMemberships() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.IsPending = _this.GetEntityValue('IsPending');
        _this.IsPrimary = _this.GetEntityValue('IsPrimary');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.OrderState = _this.GetEntityValue('OrderState');
        _this.ValidUntil = _this.GetEntityValue('ValidUntil');
        _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
        _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalO3edlMemberships.GetEntitySchema = function () {
        var columns = {
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ObjectKeyAssignment': {
                ColumnName: 'ObjectKeyAssignment',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'IsPending': {
                ColumnName: 'IsPending',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsPrimary': {
                ColumnName: 'IsPrimary',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'OrderState': {
                ColumnName: 'OrderState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ValidUntil': {
                ColumnName: 'ValidUntil',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'UID_UNSAccount': {
                ColumnName: 'UID_UNSAccount',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_UNSGroupChild': {
                ColumnName: 'UID_UNSGroupChild',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return PortalO3edlMemberships;
}(TypedEntity));
/** @deprecated Use the PortalO3edlMemberships type. */
var PortalO3edlMembershipsInteractive = /** @class */ (function (_super) {
    __extends(PortalO3edlMembershipsInteractive, _super);
    function PortalO3edlMembershipsInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalO3edlMembershipsInteractive;
}(PortalO3edlMemberships));
var PortalO3eunifiedgroupMemberships = /** @class */ (function (_super) {
    __extends(PortalO3eunifiedgroupMemberships, _super);
    function PortalO3eunifiedgroupMemberships() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.IsPending = _this.GetEntityValue('IsPending');
        _this.IsPrimary = _this.GetEntityValue('IsPrimary');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.OrderState = _this.GetEntityValue('OrderState');
        _this.ValidUntil = _this.GetEntityValue('ValidUntil');
        _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
        _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalO3eunifiedgroupMemberships.GetEntitySchema = function () {
        var columns = {
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ObjectKeyAssignment': {
                ColumnName: 'ObjectKeyAssignment',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'IsPending': {
                ColumnName: 'IsPending',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsPrimary': {
                ColumnName: 'IsPrimary',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'OrderState': {
                ColumnName: 'OrderState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ValidUntil': {
                ColumnName: 'ValidUntil',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'UID_UNSAccount': {
                ColumnName: 'UID_UNSAccount',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_UNSGroupChild': {
                ColumnName: 'UID_UNSGroupChild',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return PortalO3eunifiedgroupMemberships;
}(TypedEntity));
/** @deprecated Use the PortalO3eunifiedgroupMemberships type. */
var PortalO3eunifiedgroupMembershipsInteractive = /** @class */ (function (_super) {
    __extends(PortalO3eunifiedgroupMembershipsInteractive, _super);
    function PortalO3eunifiedgroupMembershipsInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalO3eunifiedgroupMembershipsInteractive;
}(PortalO3eunifiedgroupMemberships));
var PortalTargetsystemO3edl = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3edl, _super);
    function PortalTargetsystemO3edl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.Requestable = _this.GetEntityValue('Requestable');
        _this.Owned = _this.GetEntityValue('Owned');
        _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemO3edl.GetEntitySchema = function () {
        var columns = {
            'UID_AccProduct': {
                ColumnName: 'UID_AccProduct',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Requestable': {
                ColumnName: 'Requestable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Owned': {
                ColumnName: 'Owned',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XReadOnlyMemberships': {
                ColumnName: 'XReadOnlyMemberships',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'O3EDL', Columns: columns };
    };
    return PortalTargetsystemO3edl;
}(WriteExtTypedEntity));
/** @deprecated Use the PortalTargetsystemO3edl type. */
var PortalTargetsystemO3edlInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3edlInteractive, _super);
    function PortalTargetsystemO3edlInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemO3edlInteractive;
}(PortalTargetsystemO3edl));
var PortalTargetsystemO3edlMailboxes = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3edlMailboxes, _super);
    function PortalTargetsystemO3edlMailboxes() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_O3EDL = _this.GetEntityValue('UID_O3EDL');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.UID_O3EMailbox = _this.GetEntityValue('UID_O3EMailbox');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemO3edlMailboxes.GetEntitySchema = function () {
        var columns = {
            'UID_O3EDL': {
                ColumnName: 'UID_O3EDL',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'UID_O3EMailbox': {
                ColumnName: 'UID_O3EMailbox',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'O3EMailboxInDL', Columns: columns };
    };
    return PortalTargetsystemO3edlMailboxes;
}(TypedEntity));
/** @deprecated Use the PortalTargetsystemO3edlMailboxes type. */
var PortalTargetsystemO3edlMailboxesInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3edlMailboxesInteractive, _super);
    function PortalTargetsystemO3edlMailboxesInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemO3edlMailboxesInteractive;
}(PortalTargetsystemO3edlMailboxes));
var PortalTargetsystemO3emailbox = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3emailbox, _super);
    function PortalTargetsystemO3emailbox() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemO3emailbox.GetEntitySchema = function () {
        var columns = {};
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'O3EMailbox', Columns: columns };
    };
    return PortalTargetsystemO3emailbox;
}(TypedEntity));
/** @deprecated Use the PortalTargetsystemO3emailbox type. */
var PortalTargetsystemO3emailboxInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3emailboxInteractive, _super);
    function PortalTargetsystemO3emailboxInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemO3emailboxInteractive;
}(PortalTargetsystemO3emailbox));
var PortalTargetsystemO3emailcontact = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3emailcontact, _super);
    function PortalTargetsystemO3emailcontact() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemO3emailcontact.GetEntitySchema = function () {
        var columns = {};
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'O3EMailContact', Columns: columns };
    };
    return PortalTargetsystemO3emailcontact;
}(TypedEntity));
/** @deprecated Use the PortalTargetsystemO3emailcontact type. */
var PortalTargetsystemO3emailcontactInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3emailcontactInteractive, _super);
    function PortalTargetsystemO3emailcontactInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemO3emailcontactInteractive;
}(PortalTargetsystemO3emailcontact));
var PortalTargetsystemO3emailuser = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3emailuser, _super);
    function PortalTargetsystemO3emailuser() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemO3emailuser.GetEntitySchema = function () {
        var columns = {};
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'O3EMailUser', Columns: columns };
    };
    return PortalTargetsystemO3emailuser;
}(TypedEntity));
/** @deprecated Use the PortalTargetsystemO3emailuser type. */
var PortalTargetsystemO3emailuserInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3emailuserInteractive, _super);
    function PortalTargetsystemO3emailuserInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemO3emailuserInteractive;
}(PortalTargetsystemO3emailuser));
var PortalTargetsystemO3eunifiedgroup = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3eunifiedgroup, _super);
    function PortalTargetsystemO3eunifiedgroup() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.IsMembershipDynamic = _this.GetEntityValue('IsMembershipDynamic');
        _this.Requestable = _this.GetEntityValue('Requestable');
        _this.Owned = _this.GetEntityValue('Owned');
        _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemO3eunifiedgroup.GetEntitySchema = function () {
        var columns = {
            'UID_AccProduct': {
                ColumnName: 'UID_AccProduct',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IsMembershipDynamic': {
                ColumnName: 'IsMembershipDynamic',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Requestable': {
                ColumnName: 'Requestable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Owned': {
                ColumnName: 'Owned',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XReadOnlyMemberships': {
                ColumnName: 'XReadOnlyMemberships',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'O3EUnifiedGroup', Columns: columns };
    };
    return PortalTargetsystemO3eunifiedgroup;
}(WriteExtTypedEntity));
/** @deprecated Use the PortalTargetsystemO3eunifiedgroup type. */
var PortalTargetsystemO3eunifiedgroupInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemO3eunifiedgroupInteractive, _super);
    function PortalTargetsystemO3eunifiedgroupInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemO3eunifiedgroupInteractive;
}(PortalTargetsystemO3eunifiedgroup));
var PortalO3edlMembershipsWrapper = /** @class */ (function () {
    function PortalO3edlMembershipsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalO3edlMembershipsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/O3EDL/{uid}/memberships');
    };
    PortalO3edlMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/O3EDL/{uid}/memberships');
            this.builder = new TypedEntityBuilder(PortalO3edlMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalO3edlMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_O3EDL_memberships_get(uid, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalO3edlMembershipsWrapper;
}());
var PortalO3eunifiedgroupMembershipsWrapper = /** @class */ (function () {
    function PortalO3eunifiedgroupMembershipsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalO3eunifiedgroupMembershipsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/O3EUnifiedGroup/{uid}/memberships');
    };
    PortalO3eunifiedgroupMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/O3EUnifiedGroup/{uid}/memberships');
            this.builder = new TypedEntityBuilder(PortalO3eunifiedgroupMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalO3eunifiedgroupMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_O3EUnifiedGroup_memberships_get(uid, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalO3eunifiedgroupMembershipsWrapper;
}());
var PortalTargetsystemO3edlWrapper = /** @class */ (function () {
    function PortalTargetsystemO3edlWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_o3edl_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3edlWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3edl');
    };
    PortalTargetsystemO3edlWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3edl');
            this.builder = new TypedEntityBuilder(PortalTargetsystemO3edl, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3edlWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3edl_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3edlWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3edl_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3edlWrapper;
}());
var PortalTargetsystemO3edlInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemO3edlInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_o3edl_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3edlInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3edl/interactive');
    };
    PortalTargetsystemO3edlInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3edl/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemO3edl, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3edlInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3edl_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3edlInteractiveWrapper.prototype.Get_byid = function (UID_O3EDL, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3edl_interactive_byid_get(UID_O3EDL, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3edlInteractiveWrapper;
}());
var PortalTargetsystemO3edlMailboxesWrapper = /** @class */ (function () {
    function PortalTargetsystemO3edlMailboxesWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            {
                return _this.client.portal_targetsystem_o3edl_mailboxes_post(entity.GetColumn('UID_O3EDL').GetValue(), writeData);
            }
        };
        this.deleteMethod = function (entity) {
            return _this.client.portal_targetsystem_o3edl_mailboxes_delete(entity.GetColumn('UID_O3EDL').GetValue(), entity.GetColumn('UID_O3EMailbox').GetValue());
        };
    }
    PortalTargetsystemO3edlMailboxesWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3edlMailboxesWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes');
    };
    PortalTargetsystemO3edlMailboxesWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes');
            this.builder = new TypedEntityBuilder(PortalTargetsystemO3edlMailboxes, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3edlMailboxesWrapper.prototype.Get = function (UID_O3EDL, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3edl_mailboxes_get(UID_O3EDL, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3edlMailboxesWrapper.prototype.Post = function (UID_O3EDL, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3edl_mailboxes_post(UID_O3EDL, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3edlMailboxesWrapper.prototype.Delete = function (UID_O3EDL, UID_O3EMailbox, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3edl_mailboxes_delete(UID_O3EDL, UID_O3EMailbox, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3edlMailboxesWrapper;
}());
var PortalTargetsystemO3emailboxWrapper = /** @class */ (function () {
    function PortalTargetsystemO3emailboxWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_o3emailbox_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3emailboxWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3emailbox');
    };
    PortalTargetsystemO3emailboxWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3emailbox');
            this.builder = new TypedEntityBuilder(PortalTargetsystemO3emailbox, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3emailboxWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailbox_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3emailboxWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailbox_put(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3emailboxWrapper;
}());
var PortalTargetsystemO3emailboxInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemO3emailboxInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_o3emailbox_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3emailboxInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3emailbox/interactive');
    };
    PortalTargetsystemO3emailboxInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3emailbox/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemO3emailbox, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3emailboxInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailbox_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3emailboxInteractiveWrapper.prototype.Get_byid = function (UID_O3EMailbox, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailbox_interactive_byid_get(UID_O3EMailbox, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3emailboxInteractiveWrapper;
}());
var PortalTargetsystemO3emailcontactWrapper = /** @class */ (function () {
    function PortalTargetsystemO3emailcontactWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_o3emailcontact_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3emailcontactWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3emailcontact');
    };
    PortalTargetsystemO3emailcontactWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3emailcontact');
            this.builder = new TypedEntityBuilder(PortalTargetsystemO3emailcontact, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3emailcontactWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailcontact_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3emailcontactWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailcontact_put(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3emailcontactWrapper;
}());
var PortalTargetsystemO3emailcontactInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemO3emailcontactInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_o3emailcontact_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3emailcontactInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3emailcontact/interactive');
    };
    PortalTargetsystemO3emailcontactInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3emailcontact/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemO3emailcontact, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3emailcontactInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailcontact_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3emailcontactInteractiveWrapper.prototype.Get_byid = function (UID_O3EMailContact, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailcontact_interactive_byid_get(UID_O3EMailContact, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3emailcontactInteractiveWrapper;
}());
var PortalTargetsystemO3emailuserWrapper = /** @class */ (function () {
    function PortalTargetsystemO3emailuserWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_o3emailuser_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3emailuserWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3emailuser');
    };
    PortalTargetsystemO3emailuserWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3emailuser');
            this.builder = new TypedEntityBuilder(PortalTargetsystemO3emailuser, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3emailuserWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailuser_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3emailuserWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailuser_put(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3emailuserWrapper;
}());
var PortalTargetsystemO3emailuserInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemO3emailuserInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_o3emailuser_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3emailuserInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3emailuser/interactive');
    };
    PortalTargetsystemO3emailuserInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3emailuser/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemO3emailuser, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3emailuserInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailuser_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3emailuserInteractiveWrapper.prototype.Get_byid = function (UID_O3EMailUser, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3emailuser_interactive_byid_get(UID_O3EMailUser, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3emailuserInteractiveWrapper;
}());
var PortalTargetsystemO3eunifiedgroupWrapper = /** @class */ (function () {
    function PortalTargetsystemO3eunifiedgroupWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_o3eunifiedgroup_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3eunifiedgroupWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3eunifiedgroup');
    };
    PortalTargetsystemO3eunifiedgroupWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3eunifiedgroup');
            this.builder = new TypedEntityBuilder(PortalTargetsystemO3eunifiedgroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3eunifiedgroupWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3eunifiedgroup_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3eunifiedgroupWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3eunifiedgroup_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3eunifiedgroupWrapper;
}());
var PortalTargetsystemO3eunifiedgroupInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemO3eunifiedgroupInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_o3eunifiedgroup_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemO3eunifiedgroupInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/o3eunifiedgroup/interactive');
    };
    PortalTargetsystemO3eunifiedgroupInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/o3eunifiedgroup/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemO3eunifiedgroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemO3eunifiedgroupInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3eunifiedgroup_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemO3eunifiedgroupInteractiveWrapper.prototype.Get_byid = function (UID_O3EUnifiedGroup, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_o3eunifiedgroup_interactive_byid_get(UID_O3EUnifiedGroup, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemO3eunifiedgroupInteractiveWrapper;
}());
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
var ApiClientMethodFactory = /** @class */ (function () {
    function ApiClientMethodFactory() {
    }
    ApiClientMethodFactory.prototype.portal_O3EDL_memberships_get = function (uid) {
        return {
            path: '/portal/O3EDL/{uid}/memberships',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_O3EDL_memberships_delete = function (uid, uidaccount) {
        return {
            path: '/portal/O3EDL/{uid}/memberships/{uidaccount}',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_O3EUnifiedGroup_memberships_get = function (uid) {
        return {
            path: '/portal/O3EUnifiedGroup/{uid}/memberships',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_O3EUnifiedGroup_memberships_delete = function (uid, uidaccount) {
        return {
            path: '/portal/O3EUnifiedGroup/{uid}/memberships/{uidaccount}',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/o3edl',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'published',
                    value: published,
                    in: 'query'
                },
                {
                    name: 'withowner',
                    value: withowner,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3edl',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_get = function (UID_O3EDL, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes',
            parameters: [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_post = function (UID_O3EDL, inputParameterName) {
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes',
            parameters: [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_delete = function (UID_O3EDL, UID_O3EMailbox) {
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes/{UID_O3EMailbox}',
            parameters: [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_O3EMailbox',
                    value: UID_O3EMailbox,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get = function (UID_O3EDL, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates',
            parameters: [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get = function (UID_O3EDL, filter) {
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post = function (UID_O3EDL, xorigin, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3edl/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/o3edl/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3edl/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_interactive_byid_get = function (UID_O3EDL) {
        return {
            path: '/portal/targetsystem/o3edl/interactive/{UID_O3EDL}',
            parameters: [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/o3emailbox',
            parameters: [
                {
                    name: 'UID_PersonAssociated',
                    value: UID_PersonAssociated,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'orphaned',
                    value: orphaned,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3emailbox',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3emailbox/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/o3emailbox/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3emailbox/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_interactive_byid_get = function (UID_O3EMailbox) {
        return {
            path: '/portal/targetsystem/o3emailbox/interactive/{UID_O3EMailbox}',
            parameters: [
                {
                    name: 'UID_O3EMailbox',
                    value: UID_O3EMailbox,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/o3emailcontact',
            parameters: [
                {
                    name: 'UID_PersonAssociated',
                    value: UID_PersonAssociated,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'orphaned',
                    value: orphaned,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3emailcontact',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3emailcontact/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/o3emailcontact/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3emailcontact/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_interactive_byid_get = function (UID_O3EMailContact) {
        return {
            path: '/portal/targetsystem/o3emailcontact/interactive/{UID_O3EMailContact}',
            parameters: [
                {
                    name: 'UID_O3EMailContact',
                    value: UID_O3EMailContact,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/o3emailuser',
            parameters: [
                {
                    name: 'UID_PersonAssociated',
                    value: UID_PersonAssociated,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'orphaned',
                    value: orphaned,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3emailuser',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3emailuser/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/o3emailuser/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3emailuser/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_interactive_byid_get = function (UID_O3EMailUser) {
        return {
            path: '/portal/targetsystem/o3emailuser/interactive/{UID_O3EMailUser}',
            parameters: [
                {
                    name: 'UID_O3EMailUser',
                    value: UID_O3EMailUser,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/o3eunifiedgroup',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'published',
                    value: published,
                    in: 'query'
                },
                {
                    name: 'withowner',
                    value: withowner,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3eunifiedgroup',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3eunifiedgroup/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/o3eunifiedgroup/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/o3eunifiedgroup/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_interactive_byid_get = function (UID_O3EUnifiedGroup) {
        return {
            path: '/portal/targetsystem/o3eunifiedgroup/interactive/{UID_O3EUnifiedGroup}',
            parameters: [
                {
                    name: 'UID_O3EUnifiedGroup',
                    value: UID_O3EUnifiedGroup,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return ApiClientMethodFactory;
}());
/** @deprecated Use the V2Client class for a stable method interface. */
var Client = /** @class */ (function () {
    function Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    Client.prototype.portal_O3EDL_memberships_get = function (uid, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_O3EDL_memberships_get(uid), requestOptions);
    };
    /** Deletes an account membership. */
    Client.prototype.portal_O3EDL_memberships_delete = function (uid, uidaccount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_O3EDL_memberships_delete(uid, uidaccount), requestOptions);
    };
    Client.prototype.portal_O3EUnifiedGroup_memberships_get = function (uid, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_O3EUnifiedGroup_memberships_get(uid), requestOptions);
    };
    /** Deletes an account membership. */
    Client.prototype.portal_O3EUnifiedGroup_memberships_delete = function (uid, uidaccount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_O3EUnifiedGroup_memberships_delete(uid, uidaccount), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_O3EDL. */
    Client.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_O3EUnifiedGroup. */
    Client.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3edl_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3edl_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3edl_mailboxes_get = function (UID_O3EDL, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_get(UID_O3EDL, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3edl_mailboxes_post = function (UID_O3EDL, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_post(UID_O3EDL, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3edl_mailboxes_delete = function (UID_O3EDL, UID_O3EMailbox, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_delete(UID_O3EDL, UID_O3EMailbox), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_O3EMailbox. */
    Client.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get = function (UID_O3EDL, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get(UID_O3EDL, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates endpoint. */
    Client.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get = function (UID_O3EDL, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get(UID_O3EDL, filter), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates endpoint. */
    Client.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post = function (UID_O3EDL, xorigin, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post(UID_O3EDL, xorigin, filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3edl_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3edl endpoint. */
    Client.prototype.portal_targetsystem_o3edl_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3edl_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3edl_interactive_byid_get = function (UID_O3EDL, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_interactive_byid_get(UID_O3EDL), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailbox_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_get(UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailbox_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailbox_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3emailbox endpoint. */
    Client.prototype.portal_targetsystem_o3emailbox_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailbox_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailbox_interactive_byid_get = function (UID_O3EMailbox, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_interactive_byid_get(UID_O3EMailbox), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailcontact_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_get(UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailcontact_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailcontact_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3emailcontact endpoint. */
    Client.prototype.portal_targetsystem_o3emailcontact_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailcontact_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailcontact_interactive_byid_get = function (UID_O3EMailContact, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_interactive_byid_get(UID_O3EMailContact), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailuser_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_get(UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailuser_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailuser_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3emailuser endpoint. */
    Client.prototype.portal_targetsystem_o3emailuser_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailuser_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3emailuser_interactive_byid_get = function (UID_O3EMailUser, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_interactive_byid_get(UID_O3EMailUser), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3eunifiedgroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3eunifiedgroup_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3eunifiedgroup_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3eunifiedgroup endpoint. */
    Client.prototype.portal_targetsystem_o3eunifiedgroup_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3eunifiedgroup_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_o3eunifiedgroup_interactive_byid_get = function (UID_O3EUnifiedGroup, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_interactive_byid_get(UID_O3EUnifiedGroup), requestOptions);
    };
    return Client;
}());
var V2ApiClientMethodFactory = /** @class */ (function () {
    function V2ApiClientMethodFactory() {
    }
    V2ApiClientMethodFactory.prototype.portal_O3EDL_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/O3EDL/{uid}/memberships',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_O3EDL_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/O3EDL/{uid}/memberships/{uidaccount}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_O3EUnifiedGroup_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/O3EUnifiedGroup/{uid}/memberships',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_O3EUnifiedGroup_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/O3EUnifiedGroup/{uid}/memberships/{uidaccount}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_get = function (/** Unique identifier of the base object */ UID_O3EDL, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_post = function (/** Unique identifier of the base object */ UID_O3EDL, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_delete = function (/** Unique identifier of the base object */ UID_O3EDL, /** Exchange Online mailbox */ UID_O3EMailbox, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes/{UID_O3EMailbox}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_O3EMailbox',
                    value: UID_O3EMailbox,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get = function (/** Unique identifier of the base object */ UID_O3EDL, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_O3EDL, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_O3EDL, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3edl_interactive_byid_get = function (/** Primary key value UID_O3EDL */ UID_O3EDL, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3edl/interactive/{UID_O3EDL}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EDL',
                    value: UID_O3EDL,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailbox',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailbox',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailbox/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailbox/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailbox/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailbox_interactive_byid_get = function (/** Primary key value UID_O3EMailbox */ UID_O3EMailbox, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailbox/interactive/{UID_O3EMailbox}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EMailbox',
                    value: UID_O3EMailbox,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailcontact',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailcontact',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailcontact/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailcontact/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailcontact/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailcontact_interactive_byid_get = function (/** Primary key value UID_O3EMailContact */ UID_O3EMailContact, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailcontact/interactive/{UID_O3EMailContact}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EMailContact',
                    value: UID_O3EMailContact,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailuser',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailuser',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailuser/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailuser/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailuser/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3emailuser_interactive_byid_get = function (/** Primary key value UID_O3EMailUser */ UID_O3EMailUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3emailuser/interactive/{UID_O3EMailUser}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EMailUser',
                    value: UID_O3EMailUser,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3eunifiedgroup',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3eunifiedgroup',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3eunifiedgroup/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3eunifiedgroup/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3eunifiedgroup/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_o3eunifiedgroup_interactive_byid_get = function (/** Primary key value UID_O3EUnifiedGroup */ UID_O3EUnifiedGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/o3eunifiedgroup/interactive/{UID_O3EUnifiedGroup}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_O3EUnifiedGroup',
                    value: UID_O3EUnifiedGroup,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return V2ApiClientMethodFactory;
}());
var V2Client = /** @class */ (function () {
    function V2Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new V2ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(V2Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    V2Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    V2Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    V2Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    V2Client.prototype.portal_O3EDL_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_O3EDL_memberships_get(uid, options), requestOptions);
    };
    /** Deletes an account membership. */
    V2Client.prototype.portal_O3EDL_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_O3EDL_memberships_delete(uid, uidaccount, options), requestOptions);
    };
    V2Client.prototype.portal_O3EUnifiedGroup_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_O3EUnifiedGroup_memberships_get(uid, options), requestOptions);
    };
    /** Deletes an account membership. */
    V2Client.prototype.portal_O3EUnifiedGroup_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_O3EUnifiedGroup_memberships_delete(uid, uidaccount, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_O3EDL. */
    V2Client.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/O3EDL/UID_O3EDL/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EDL_UID_O3EDL_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_O3EUnifiedGroup. */
    V2Client.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/O3EUnifiedGroup/UID_O3EUnifiedGroup/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_O3EUnifiedGroup_UID_O3EUnifiedGroup_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3edl_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3edl_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3edl_mailboxes_get = function (/** Unique identifier of the base object */ UID_O3EDL, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_get(UID_O3EDL, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3edl_mailboxes_post = function (/** Unique identifier of the base object */ UID_O3EDL, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_post(UID_O3EDL, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3edl_mailboxes_delete = function (/** Unique identifier of the base object */ UID_O3EDL, /** Exchange Online mailbox */ UID_O3EMailbox, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_delete(UID_O3EDL, UID_O3EMailbox, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_O3EMailbox. */
    V2Client.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get = function (/** Unique identifier of the base object */ UID_O3EDL, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_get(UID_O3EDL, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_O3EDL, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_datamodel_get(UID_O3EDL, options), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/o3edl/{UID_O3EDL}/mailboxes/UID_O3EMailbox/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_O3EDL, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_mailboxes_UID_O3EMailbox_candidates_filtertree_post(UID_O3EDL, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3edl_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3edl endpoint. */
    V2Client.prototype.portal_targetsystem_o3edl_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3edl_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3edl_interactive_byid_get = function (/** Primary key value UID_O3EDL */ UID_O3EDL, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3edl_interactive_byid_get(UID_O3EDL, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailbox_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailbox_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailbox_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3emailbox endpoint. */
    V2Client.prototype.portal_targetsystem_o3emailbox_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailbox_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailbox_interactive_byid_get = function (/** Primary key value UID_O3EMailbox */ UID_O3EMailbox, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailbox_interactive_byid_get(UID_O3EMailbox, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailcontact_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailcontact_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailcontact_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3emailcontact endpoint. */
    V2Client.prototype.portal_targetsystem_o3emailcontact_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailcontact_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailcontact_interactive_byid_get = function (/** Primary key value UID_O3EMailContact */ UID_O3EMailContact, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailcontact_interactive_byid_get(UID_O3EMailContact, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailuser_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailuser_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailuser_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3emailuser endpoint. */
    V2Client.prototype.portal_targetsystem_o3emailuser_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailuser_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3emailuser_interactive_byid_get = function (/** Primary key value UID_O3EMailUser */ UID_O3EMailUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3emailuser_interactive_byid_get(UID_O3EMailUser, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3eunifiedgroup_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3eunifiedgroup_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3eunifiedgroup_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/o3eunifiedgroup endpoint. */
    V2Client.prototype.portal_targetsystem_o3eunifiedgroup_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3eunifiedgroup_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_o3eunifiedgroup_interactive_byid_get = function (/** Primary key value UID_O3EUnifiedGroup */ UID_O3EUnifiedGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_o3eunifiedgroup_interactive_byid_get(UID_O3EUnifiedGroup, options), requestOptions);
    };
    return V2Client;
}());

export { ApiClientMethodFactory, Client, PortalO3edlMemberships, PortalO3edlMembershipsInteractive, PortalO3edlMembershipsWrapper, PortalO3eunifiedgroupMemberships, PortalO3eunifiedgroupMembershipsInteractive, PortalO3eunifiedgroupMembershipsWrapper, PortalTargetsystemO3edl, PortalTargetsystemO3edlInteractive, PortalTargetsystemO3edlInteractiveWrapper, PortalTargetsystemO3edlMailboxes, PortalTargetsystemO3edlMailboxesInteractive, PortalTargetsystemO3edlMailboxesWrapper, PortalTargetsystemO3edlWrapper, PortalTargetsystemO3emailbox, PortalTargetsystemO3emailboxInteractive, PortalTargetsystemO3emailboxInteractiveWrapper, PortalTargetsystemO3emailboxWrapper, PortalTargetsystemO3emailcontact, PortalTargetsystemO3emailcontactInteractive, PortalTargetsystemO3emailcontactInteractiveWrapper, PortalTargetsystemO3emailcontactWrapper, PortalTargetsystemO3emailuser, PortalTargetsystemO3emailuserInteractive, PortalTargetsystemO3emailuserInteractiveWrapper, PortalTargetsystemO3emailuserWrapper, PortalTargetsystemO3eunifiedgroup, PortalTargetsystemO3eunifiedgroupInteractive, PortalTargetsystemO3eunifiedgroupInteractiveWrapper, PortalTargetsystemO3eunifiedgroupWrapper, TypedClient, V2ApiClientMethodFactory, V2Client };
